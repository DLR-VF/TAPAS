--see all types
SELECT general_type, COUNT(loc_id)
FROM core.berlin_locations_import
GROUP BY general_type
ORDER BY count DESC

--see all categories
SELECT DISTINCT (kategorie || ' - ' || unterkategorie_1 ||' - ' || unterkategorie_2) AS kategorien
FROM core.global_bosserhof_mapping
ORDER BY kategorien

--update (kills all other entries
WITH v AS 
(SELECT * FROM (
	VALUES 
-- insert values from mapping.sql
	) AS q (type,cat,ucat1,ucat2)
)
UPDATE core.berlin_locations_import SET
	general_name = (
		SELECT cat ||'-'||ucat1||'-'||ucat2 FROM v WHERE general_type = v.type)
-- WARNING: This sql-statement kills all old data! 

--test it
SELECT typ,general_type,general_name from core.berlin_locations_import 
WHERE general_name NOTNULL


--get additional 
SELECT typ, COUNT(*) FROM
core.berlin_locations_import
WHERE general_name ISNULL
GROUP BY typ

--now run detail_abfragen.sql for null types