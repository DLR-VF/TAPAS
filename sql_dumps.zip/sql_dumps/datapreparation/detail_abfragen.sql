--Discount 256
UPDATE
core.berlin_locations_import
SET general_name='Einkauf-Lebensmittel-Discounter'
WHERE 
	(name ~* 'aldi' OR
	name ~* 'lidl' OR
	name ~* 'penny' OR
	name ~* 'norma' OR
	name ~* 'plus' OR
	name ~* 'netto' )
	AND general_type = 'Supermarkt';

--vollsortiment 241	
UPDATE
core.berlin_locations_import
SET general_name='Einkauf-Lebensmittel-Vollsortiment'
WHERE 
	(name ~* 'edeka' OR
	name ~* 'rewe' OR
	name ~* 'kaiser' OR
	name ~* 'spar')
	AND general_type = 'Supermarkt';
	
--SB-Warenhaus
UPDATE
core.berlin_locations_import
SET general_name='Einkauf-Lebensmittel-SB-Warenhaus'
WHERE 
	(name ~* 'kaufland' OR
	name ~* 'metro' OR
	name ~* 'real')
	AND general_type = 'Supermarkt';
	

--religion ~85
UPDATE--69
core.berlin_locations_import
SET general_name='Freizeit-Religion-Christentum'
WHERE 
	(name ~* 'kirch' OR name ~* 'dom' OR name ~* 'heil' OR name ~* 'jesu' OR name ~* 'sankt' or name ~* 'evangel' or name ~* 'kathol' or name ~* 'kapell' or name ~* 'tabor')
	AND general_type = 'PLACE OF WORSHIP';
UPDATE--9
core.berlin_locations_import
SET general_name='Freizeit-Religion-Judentum'
WHERE 
	(name ~* 'synagog' or name ~* 'j�d')
	AND general_type = 'PLACE OF WORSHIP';
UPDATE--1
core.berlin_locations_import
SET general_name='Freizeit-Religion-Islam'
WHERE 
	(name ~* 'moschee')
	AND general_type = 'PLACE OF WORSHIP';
UPDATE--rest
core.berlin_locations_import
SET general_name='Freizeit-Religion-'
WHERE 
	NOT (name ~* 'kirch' OR name ~* 'dom' OR name ~* 'heil' OR name ~* 'jesu' OR name ~* 'sankt' or name ~* 'evangel' or name ~* 'kathol' or name ~* 'kapell' or name ~* 'tabor')
	AND NOT (name ~* 'synagog' or name ~* 'j�d')
	AND NOT (name ~* 'moschee')
	AND general_type = 'PLACE OF WORSHIP';
	
--WEITERE
UPDATE--1072
core.berlin_locations_import
SET general_name='Freizeit-Erholung-Freiluft'
WHERE name = 'Kleingarten';

UPDATE
core.berlin_locations_import
SET general_name='Einkauf-Lebensmittel-Vollsortiment'
WHERE general_name ISNULL AND 
	(name ~* 'edeka' OR
	name ~* 'rewe' OR
	name ~* 'reichelt' OR
	name ~* 'ullrich'
);

UPDATE
core.berlin_locations_import
SET general_name='Einkauf-Lebensmittel-Discounter'
WHERE general_name ISNULL AND 
	(name ~* 'nahkauf' OR
	name ~* 'mini' OR
	name ~* 'nah' OR name ~* 'np'
	);

UPDATE
core.berlin_locations_import
SET general_name='Einkauf-Fachhandel-Lebensmittel'
WHERE general_name ISNULL AND 
	(name ~* 'bio' OR name ~* 'asia' OR name ~* 'asien' OR name ~* 'tchibo' OR name ~* 'getr�nk' OR name ~* 'reform' or name~* 'kost' or name ~* 'natur');
	
UPDATE core.berlin_locations_import
SET general_name='Einkauf-Fachhandel-Sp�tkauf'
WHERE general_name ISNULL AND 
	(name ~* 'kiosk');

UPDATE
core.berlin_locations_import
SET general_name='Einkauf-Fachhandel-Hobby'
WHERE general_name ISNULL AND 
	(name ~* 'fressnapf' OR name ~* 'zoo');

UPDATE
core.berlin_locations_import
SET general_name='Einkauf-Fachhandel-Gesundheit'
WHERE general_name ISNULL AND 
	(name ~* 'schlecker' OR name ~* 'drogerie' or name ~* 'ihr platz' or name ~* 'drospa');
	
UPDATE
core.berlin_locations_import
SET general_name='Einkauf-Fachhandel-Sp�tkauf'
WHERE general_name ISNULL AND 
	(name ~* 'sp�t' OR name ~* '24');

--update bibliothek nach normalem Mapping!
UPDATE core.berlin_locations_import
SET general_name='Bildung-Sonstiges-Bibliothek'
WHERE general_type = 'Bibliothek' AND 
	(name ~* 'uni' OR name ~* 'staat' or name ~* 'land');

--kindergarten
UPDATE core.berlin_locations_import
SET general_name='Bildung-Sonstiges-Kindergarten'
WHERE typ = 'Kindergarten';

--gr�nfl�che
UPDATE core.berlin_locations_import
SET general_name='Freizeit-Erholung-Freiluft'
WHERE typ = 'Gr�nfl�che';

--Shopping-Center
UPDATE core.berlin_locations_import
SET general_name='Einkauf-Mall-'
WHERE typ = 'Shopping-Center';

--Hausrat
UPDATE core.berlin_locations_import
SET general_name='Einkauf-Fachhandel-Hausrat'
WHERE name ~* 'woolworth' OR name ~* 'geiz' or name ~* 'strauss innovation' or name ~* '1 EURO' or name ~* 'tedi'


--kinos
UPDATE core.berlin_locations_import
SET general_name='Freizeit-Event-Cineplex'
WHERE general_type = 'Kino' AND 
NOT (name ~* 'freiluft' or name ~* 'open' OR name ~* 'park' OR name ~* 'natur') AND
(capacity_value > 750 OR name ~* 'cinestar');

UPDATE core.berlin_locations_import
SET general_name='Freizeit-Event-Programmkino'
WHERE general_type = 'Kino' AND 
NOT (name ~* 'freiluft' or name ~* 'open' OR name ~* 'park' OR name ~* 'natur') AND
(capacity_value >= 750 OR name ~* 'cinestar');

UPDATE core.berlin_locations_import
SET general_name='Freizeit-Event-Freiluftkino'
WHERE general_type = 'Kino' AND 
(name ~* 'freiluft' or name ~* 'open' OR name ~* 'park' or name ~* 'natur')

---Rest Einkauf
UPDATE core.berlin_locations_import
SET general_name='Einkauf-Fachhandel-Sp�tkauf'
WHERE general_name ISNULL 
AND typ = 'Einkauf';
