--unsicher

--extra bearbeiten
('Nachbarschaftsladen',,,), --schlecht getagged!!
('PLACE OF WORSHIP','Freizeit','Religion',NULL),
('Bauhandwerk',,,),





--sicher
('Berufskolleg','Bildung','Terti�r','Ausbildung'),
('Gesamtschule','Bildung','Sekund�r','Gesamtschule'),
('Integrierte Sekundarschule','Bildung','Sekund�r','Gesamtschule'),
('Realschule','Bildung','Sekund�r','Realschule'),
('Gymnasium','Bildung','Sekund�r','Gymnasium'),
('Hauptschule','Bildung','Sekund�r','Hauptschule'),
('F�rderschwerpunkt Lernen','Bildung','Sekund�r','Sonderschule'),
('F�rderschwerpunkt Geistige Entwicklung','Bildung','Sonstiges','Nachhilfe'),
('Grundschule','Bildung','Prim�r','Grundschule'),
('VHS','Bildung','Sonstige','Volkshochschule'),
('Uni/FH','Bildung','Terti�r','Hochschule'),
('Fahrschule','Bildung','Sonstiges','Fahrschule'),
('Musikschule','Bildung','Sonstiges','Musikschule'),

('Bekleidungsgesch�ft','Einkauf','Fachhandel','Textil'),
('Second Hand Shops','Einkauf','Fachhandel','Textil'),
('Schuhgeschaeft','Einkauf','Fachhandel','Textil'),
('Stoffe Einzelhandel','Einkauf','Fachhandel','Textil'),
('Tuche und Stoffe Einzelhandel','Einkauf','Fachhandel','Textil'),
('Bekleidung, Leder und Textil Handwerk','Einkauf','Fachhandel','Textil'),

('Mobiltelefone Einzelhandel','Einkauf','Fachhandel','Elektronik'),
('Computerfachh�ndler','Einkauf','Fachhandel','Elektronik'),
('Elektronik-Markt','Einkauf','Fachhandel','Elektronik'),

('Glas, Keramik, Steine und Erden Handwerk','Einkauf','Fachhandel','Hobby'),
('Zoologischer Bedarf Einzelhandel','Einkauf','Fachhandel','Hobby'),
('Kunstgewerbe Einzelhandel','Einkauf','Fachhandel','Hobby'),

('Buchhandlung','Einkauf','Fachhandel','B�cher/Neue Medien'),
('B�cher Einzelhandel','Einkauf','Fachhandel','B�cher/Neue Medien'),
('Kiosk','Einkauf','Fachhandel','B�cher/Neue Medien'),
('Fotokopier- und Vervielf�ltigungsbetriebe','Einkauf','Fachhandel','Schreibwaren'),

('Fahrradgeschaeft','Einkauf','Fachhandel','Sport'),

('M�bel Handwerk','Einkauf','Fachhandel','Haus und Garten'),
('M�belhaus','Einkauf','Fachhandel','Haus und Garten'),
('Baumarkt','Einkauf','Fachhandel','Haus und Garten'),
('Gardinen und Dekostoffe Einzelhandel','Einkauf','Fachhandel','Haus und Garten'),
('Gartencenter','Einkauf','Fachhandel','Haus und Garten'),
('Eisen und Metall Handwerk','Einkauf','Fachhandel','Haus und Garten'),
('Holz Handwerk','Einkauf','Fachhandel','Haus und Garten'),

('Apotheke','Einkauf','Fachhandel','Gesundheit'),
('Drogerie','Einkauf','Fachhandel','Gesundheit'),
('Optiker','Einkauf','Fachhandel','Gesundheit'),

('Bioladen','Einkauf','Fachhandel','Lebensmittel'),
('Baeckerei','Einkauf','Fachhandel','Lebensmittel'),
('Metzgerei','Einkauf','Fachhandel','Lebensmittel'),
('Getraenkemarkt','Einkauf','Fachhandel','Lebensmittel'),

('Schmuck und Uhren Einzelhandel','Einkauf','Fachhandel','Uhren/Schmuck/Foto'),
('Fotografen und Fotostudios','Einkauf','Fachhandel','Uhren/Schmuck/Foto'),
('Spielwaren Einzelhandel','Einkauf','Fachhandel','Spielwaren'),
('AUTOMOBILE DEALERSHP','Einkauf','Fachhandel','Auto'),
('Blumenladen','Einkauf','Fachhandel','Blumen'),
('Tankstelle','Einkauf','Fachhandel','Tankstelle'),

('Amt','private Erledigung','Amtsgang',''),
('Arbeitsvermittlungen','private Erledigung','Amtsgang',''),
('Polizei','private Erledigung','Amtsgang',''),
('Gericht','private Erledigung','Amtsgang',''),
('JobCenter','private Erledigung','Amtsgang',''),
('Botschaft','private Erledigungen','Amtsgang',''),

('Krankenhaus','private Erledigung','Gesundheit','Krankenhaus'),
('Psychotherapeuten','private Erledigung','Gesundheit','Arzt'),
('Radiologen','private Erledigung','Gesundheit','Arzt'),
('Zahnarzt','private Erledigung','Gesundheit','Arzt'),
('Nerven�rzte','private Erledigung','Gesundheit','Arzt'),
('Orthop�den','private Erledigung','Gesundheit','Arzt'),
('Urologen','private Erledigung','Gesundheit','Arzt'),
('Haus�rzte','private Erledigung','Gesundheit','Arzt'),
('Haut�rzte','private Erledigung','Gesundheit','Arzt'),
('Chirurgen','private Erledigung','Gesundheit','Arzt'),
('Kinder�rzte','private Erledigung','Gesundheit','Arzt'),
('Frauen�rzte','private Erledigung','Gesundheit','Arzt'),
('HNO-�rzte','private Erledigung','Gesundheit','Arzt'),
('Tier�rzte','private Erledigung','Gesundheit','Arzt'),
('Augen�rzte','private Erledigung','Gesundheit','Arzt'),
('Fach�rztlich t�tige Internisten','private Erledigung','Gesundheit','Arzt'),

('Rechtsanw�lte und Notare','private Erledigung','Dienstleistung','Recht'),
('Friseursalons','private Erledigung','Dienstleistung','Beauty'),
('Manik�rsalons','private Erledigung','Dienstleistung','Beauty'),
('Reiseb�ros und Reiseveranstalter','private Erledigung','Dienstleistung','Reisen'),
('Post','private Erledigung','Dienstleistung','Post'),
('Versicherungsagenturen und Versicherungsvermittler','private Erledigung','Dienstleistung','Versicherungen'),
('Bank','private Erledigung','Dienstleistung','Bank'),
('Waschsalons mit Selbstbedienung','private Erledigung','Dienstleistung','Waschsalon'),
('Autovermietung','private Erledigung','Dienstleistung','Autovermietung'),
('Bauhandwerk','private Erledigung','Dienstleistung','Handwerk'),
('Bibliothek','private Erledigung','Bibliothek',''),


('fast_food','Freizeit','Essen/Trinken','Fast-Food'),
('ice_cream','Freizeit','Essen/Trinken','Fast-Food'),
('bar','Freizeit','Essen/Trinken','Bar'),
('biergarten','Freizeit','Essen/Trinken','Biergarten'),
('pub','Freizeit','Essen/Trinken','Bar'),
('restaurant','Freizeit','Essen/Trinken','Restaurant'),
('cafe','Freizeit','Essen/Trinken','Cafe'),

('Clubs/ Discos','Freizeit','Event','Musik'),
('Theater','Freizeit','Event','Kultur'),
('Museum','Freizeit','Erholung','Besichtigung'),
('Zoo','Freizeit','Erholung','Besichtigung'),
('Spielplatz','Freizeit','Erholung','Freiluft'),
('Wald','Freizeit','Erholung','Freiluft'),


('Fitnesscenter','Freizeit','Sport','Konzentriert'),
('Tanzschulen','Freizeit','Sport','Weitl�ufig'),


('Hotel','Schlafen','','')