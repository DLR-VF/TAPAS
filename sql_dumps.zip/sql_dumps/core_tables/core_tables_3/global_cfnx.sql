create table core.global_cfnx
(
    "CURRENT_TAZ_SETTLEMENT_CODE_TAPAS" integer                      not null,
    value                               double precision             not null,
    key                                 text default 'default'::text not null,
    constraint cnfx_pkey
        primary key ("CURRENT_TAZ_SETTLEMENT_CODE_TAPAS", key)
);

alter table core.global_cfnx
    owner to %DBUSER%;

grant select on core.global_cfnx to tapas_user_group;
grant insert, select, update, delete, truncate, references, trigger on core.global_cfnx to tapas_admin_group;

create trigger cnfx_trigger
    before insert or update
    on core.global_cfnx
    for each row
execute procedure core.current_taz_settlement_code_tapas_exists_func();

INSERT INTO core.global_cfnx ("CURRENT_TAZ_SETTLEMENT_CODE_TAPAS", value, key) VALUES (1, 1, 'default');
INSERT INTO core.global_cfnx ("CURRENT_TAZ_SETTLEMENT_CODE_TAPAS", value, key) VALUES (5, 0.5, 'default');
INSERT INTO core.global_cfnx ("CURRENT_TAZ_SETTLEMENT_CODE_TAPAS", value, key) VALUES (3, 0.5, 'default');
INSERT INTO core.global_cfnx ("CURRENT_TAZ_SETTLEMENT_CODE_TAPAS", value, key) VALUES (4, 0.75, 'default');
INSERT INTO core.global_cfnx ("CURRENT_TAZ_SETTLEMENT_CODE_TAPAS", value, key) VALUES (2, 1, 'default');
INSERT INTO core.global_cfnx ("CURRENT_TAZ_SETTLEMENT_CODE_TAPAS", value, key) VALUES (1, 1, 'FIF');
INSERT INTO core.global_cfnx ("CURRENT_TAZ_SETTLEMENT_CODE_TAPAS", value, key) VALUES (2, 1, 'FIF');
INSERT INTO core.global_cfnx ("CURRENT_TAZ_SETTLEMENT_CODE_TAPAS", value, key) VALUES (3, 1, 'FIF');
INSERT INTO core.global_cfnx ("CURRENT_TAZ_SETTLEMENT_CODE_TAPAS", value, key) VALUES (4, 1, 'FIF');
INSERT INTO core.global_cfnx ("CURRENT_TAZ_SETTLEMENT_CODE_TAPAS", value, key) VALUES (5, 1, 'FIF');