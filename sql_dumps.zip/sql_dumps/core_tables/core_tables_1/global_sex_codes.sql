create table core.global_sex_codes
(
    name        varchar not null
        constraint sexcodes_pkey
            primary key,
    description varchar,
    class       varchar,
    name_sex    varchar,
    code_sex    integer
        constraint sexcode_unique
            unique
);

alter table core.global_sex_codes
    owner to %DBUSER%;

grant select on core.global_sex_codes to tapas_user_group;
grant insert, select, update, delete, truncate, references, trigger on core.global_sex_codes to tapas_admin_group;

INSERT INTO core.global_sex_codes (name, description, class, name_sex, code_sex) VALUES ('MALE', 'male', 'de.dlr.ivf.tapas.constants.TPS_Sex', 'MALE', 1);
INSERT INTO core.global_sex_codes (name, description, class, name_sex, code_sex) VALUES ('FEMALE', 'female', 'de.dlr.ivf.tapas.constants.TPS_Sex', 'FEMALE', 2);
INSERT INTO core.global_sex_codes (name, description, class, name_sex, code_sex) VALUES ('NON_RELEVANT', 'nonRelevant', 'de.dlr.ivf.tapas.constants.TPS_Sex', 'NON_RELEVANT', 0);