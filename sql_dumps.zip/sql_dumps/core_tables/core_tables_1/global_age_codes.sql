create table core.global_age_codes
(
    id             integer not null
        constraint agecodes_pkey
            primary key,
    description    varchar,
    class          varchar,
    name_stba      varchar,
    code_stba      integer
        constraint age_codes_code_stba_key
            unique,
    type_stba      varchar,
    name_persgroup varchar,
    code_persgroup integer,
    type_persgroup varchar,
    min            integer,
    max            integer
);

alter table core.global_age_codes
    owner to %DBUSER%;

grant select on core.global_age_codes to tapas_user_group;
grant insert, select, update, delete, truncate, references, trigger on core.global_age_codes to tapas_admin_group;


INSERT INTO core.global_age_codes (id, description, class, name_stba, code_stba, type_stba, name_persgroup, code_persgroup, type_persgroup, min, max) VALUES (1, 'nonRelevant', 'de.dlr.ivf.tapas.constants.TPS_AgeClass', 'nonRelevant', -1, 'STBA', 'nonRelevant', 1, 'PersGroup', 0, 2147483647);
INSERT INTO core.global_age_codes (id, description, class, name_stba, code_stba, type_stba, name_persgroup, code_persgroup, type_persgroup, min, max) VALUES (2, 'under 6', 'de.dlr.ivf.tapas.constants.TPS_AgeClass', 'under 6', 0, 'STBA', 'under 6', 2, 'PersGroup', 0, 5);
INSERT INTO core.global_age_codes (id, description, class, name_stba, code_stba, type_stba, name_persgroup, code_persgroup, type_persgroup, min, max) VALUES (3, 'under 10', 'de.dlr.ivf.tapas.constants.TPS_AgeClass', 'under 10', 1, 'STBA', 'nonRelevant', 1, 'PersGroup', 6, 9);
INSERT INTO core.global_age_codes (id, description, class, name_stba, code_stba, type_stba, name_persgroup, code_persgroup, type_persgroup, min, max) VALUES (4, 'under 15', 'de.dlr.ivf.tapas.constants.TPS_AgeClass', 'under 15', 2, 'STBA', 'nonRelevant', 1, 'PersGroup', 10, 14);
INSERT INTO core.global_age_codes (id, description, class, name_stba, code_stba, type_stba, name_persgroup, code_persgroup, type_persgroup, min, max) VALUES (5, 'under 18', 'de.dlr.ivf.tapas.constants.TPS_AgeClass', 'under 18', 3, 'STBA', 'nonRelevant', 1, 'PersGroup', 15, 17);
INSERT INTO core.global_age_codes (id, description, class, name_stba, code_stba, type_stba, name_persgroup, code_persgroup, type_persgroup, min, max) VALUES (9, 'under 35', 'de.dlr.ivf.tapas.constants.TPS_AgeClass', 'under 35', 7, 'STBA', 'under 45', 4, 'PersGroup', 30, 34);
INSERT INTO core.global_age_codes (id, description, class, name_stba, code_stba, type_stba, name_persgroup, code_persgroup, type_persgroup, min, max) VALUES (10, 'under 40', 'de.dlr.ivf.tapas.constants.TPS_AgeClass', 'under 40', 8, 'STBA', 'under 45', 4, 'PersGroup', 35, 39);
INSERT INTO core.global_age_codes (id, description, class, name_stba, code_stba, type_stba, name_persgroup, code_persgroup, type_persgroup, min, max) VALUES (11, 'under 45', 'de.dlr.ivf.tapas.constants.TPS_AgeClass', 'under 45', 9, 'STBA', 'under 45', 4, 'PersGroup', 40, 44);
INSERT INTO core.global_age_codes (id, description, class, name_stba, code_stba, type_stba, name_persgroup, code_persgroup, type_persgroup, min, max) VALUES (13, 'under 65', 'de.dlr.ivf.tapas.constants.TPS_AgeClass', 'under 65', 11, 'STBA', 'under 65', 5, 'PersGroup', 60, 64);
INSERT INTO core.global_age_codes (id, description, class, name_stba, code_stba, type_stba, name_persgroup, code_persgroup, type_persgroup, min, max) VALUES (14, 'under 75', 'de.dlr.ivf.tapas.constants.TPS_AgeClass', 'under 75', 12, 'STBA', 'under 75', 6, 'PersGroup', 65, 74);
INSERT INTO core.global_age_codes (id, description, class, name_stba, code_stba, type_stba, name_persgroup, code_persgroup, type_persgroup, min, max) VALUES (15, 'older 75', 'de.dlr.ivf.tapas.constants.TPS_AgeClass', 'older 75', 13, 'STBA', 'older 75', 7, 'PersGroup', 75, 2147483647);
INSERT INTO core.global_age_codes (id, description, class, name_stba, code_stba, type_stba, name_persgroup, code_persgroup, type_persgroup, min, max) VALUES (7, 'under 24', 'de.dlr.ivf.tapas.constants.TPS_AgeClass', 'under 24', 5, 'STBA', 'under 24', 3, 'PersGroup', 21, 23);
INSERT INTO core.global_age_codes (id, description, class, name_stba, code_stba, type_stba, name_persgroup, code_persgroup, type_persgroup, min, max) VALUES (8, 'under 30', 'de.dlr.ivf.tapas.constants.TPS_AgeClass', 'under 30', 6, 'STBA', 'under 45', 4, 'PersGroup', 24, 29);
INSERT INTO core.global_age_codes (id, description, class, name_stba, code_stba, type_stba, name_persgroup, code_persgroup, type_persgroup, min, max) VALUES (6, 'under 21', 'de.dlr.ivf.tapas.constants.TPS_AgeClass', 'under 21', 4, 'STBA', 'under 21', 3, 'PersGroup', 18, 20);
INSERT INTO core.global_age_codes (id, description, class, name_stba, code_stba, type_stba, name_persgroup, code_persgroup, type_persgroup, min, max) VALUES (12, 'under 60', 'de.dlr.ivf.tapas.constants.TPS_AgeClass', 'under 60', 10, 'STBA', 'under 65', 5, 'PersGroup', 45, 59);