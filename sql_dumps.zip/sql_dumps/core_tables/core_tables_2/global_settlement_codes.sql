create table core.global_settlement_codes
(
    id          integer not null
        constraint settlementcodes_pkey
            primary key,
    description varchar,
    class       varchar,
    name_fordcp varchar,
    code_fordcp integer,
    type_fordcp varchar,
    name_tapas  varchar,
    code_tapas  integer,
    type_tapas  varchar
);

alter table core.global_settlement_codes
    owner to %DBUSER%;

grant select on core.global_settlement_codes to tapas_user_group;
grant insert, select, update, delete, truncate, references, trigger on core.global_settlement_codes to tapas_admin_group;

INSERT INTO core.global_settlement_codes (id, description, class, name_fordcp, code_fordcp, type_fordcp, name_tapas, code_tapas, type_tapas) VALUES (1, 'BBR17_BBR5', 'de.dlr.ivf.tapas.constants.TPS_SettlementSystem', 'R1, K1, Kernstadt > 500000', 1, 'FORDCP', 'Agglomeration', 1, 'TAPAS');
INSERT INTO core.global_settlement_codes (id, description, class, name_fordcp, code_fordcp, type_fordcp, name_tapas, code_tapas, type_tapas) VALUES (2, 'BBR17_BBR5', 'de.dlr.ivf.tapas.constants.TPS_SettlementSystem', 'R1, K1, Kernstadt < 500000', 2, 'FORDCP', 'Agglomeration', 1, 'TAPAS');
INSERT INTO core.global_settlement_codes (id, description, class, name_fordcp, code_fordcp, type_fordcp, name_tapas, code_tapas, type_tapas) VALUES (3, 'BBR17_BBR5', 'de.dlr.ivf.tapas.constants.TPS_SettlementSystem', 'R1, K2, Zentrum', 3, 'FORDCP', 'Agglomeration', 1, 'TAPAS');
INSERT INTO core.global_settlement_codes (id, description, class, name_fordcp, code_fordcp, type_fordcp, name_tapas, code_tapas, type_tapas) VALUES (4, 'BBR17_BBR5', 'de.dlr.ivf.tapas.constants.TPS_SettlementSystem', 'R1, K2, Sonstiges', 4, 'FORDCP', 'Agglomeration', 1, 'TAPAS');
INSERT INTO core.global_settlement_codes (id, description, class, name_fordcp, code_fordcp, type_fordcp, name_tapas, code_tapas, type_tapas) VALUES (5, 'BBR17_BBR5', 'de.dlr.ivf.tapas.constants.TPS_SettlementSystem', 'R1, K3, Zentrum', 5, 'FORDCP', 'Agglomeration', 1, 'TAPAS');
INSERT INTO core.global_settlement_codes (id, description, class, name_fordcp, code_fordcp, type_fordcp, name_tapas, code_tapas, type_tapas) VALUES (6, 'BBR17_BBR5', 'de.dlr.ivf.tapas.constants.TPS_SettlementSystem', 'R1, K3, Sonstiges', 6, 'FORDCP', 'staedtisch', 2, 'TAPAS');
INSERT INTO core.global_settlement_codes (id, description, class, name_fordcp, code_fordcp, type_fordcp, name_tapas, code_tapas, type_tapas) VALUES (7, 'BBR17_BBR5', 'de.dlr.ivf.tapas.constants.TPS_SettlementSystem', 'R1, K4, Zentrum', 7, 'FORDCP', 'staedtisch', 2, 'TAPAS');
INSERT INTO core.global_settlement_codes (id, description, class, name_fordcp, code_fordcp, type_fordcp, name_tapas, code_tapas, type_tapas) VALUES (8, 'BBR17_BBR5', 'de.dlr.ivf.tapas.constants.TPS_SettlementSystem', 'R1, K4, Sonstiges', 8, 'FORDCP', 'staedtisch', 2, 'TAPAS');
INSERT INTO core.global_settlement_codes (id, description, class, name_fordcp, code_fordcp, type_fordcp, name_tapas, code_tapas, type_tapas) VALUES (9, 'BBR17_BBR5', 'de.dlr.ivf.tapas.constants.TPS_SettlementSystem', 'R2, K5, Kernstadt', 9, 'FORDCP', 'staedtisch', 2, 'TAPAS');
INSERT INTO core.global_settlement_codes (id, description, class, name_fordcp, code_fordcp, type_fordcp, name_tapas, code_tapas, type_tapas) VALUES (10, 'BBR17_BBR5', 'de.dlr.ivf.tapas.constants.TPS_SettlementSystem', 'R2, K6, Zentrum', 10, 'FORDCP', 'staedtisch', 2, 'TAPAS');
INSERT INTO core.global_settlement_codes (id, description, class, name_fordcp, code_fordcp, type_fordcp, name_tapas, code_tapas, type_tapas) VALUES (11, 'BBR17_BBR5', 'de.dlr.ivf.tapas.constants.TPS_SettlementSystem', 'R2, K6, Sonstiges', 11, 'FORDCP', 'verstaedtert', 3, 'TAPAS');
INSERT INTO core.global_settlement_codes (id, description, class, name_fordcp, code_fordcp, type_fordcp, name_tapas, code_tapas, type_tapas) VALUES (12, 'BBR17_BBR5', 'de.dlr.ivf.tapas.constants.TPS_SettlementSystem', 'R2, K7, Zentrum', 12, 'FORDCP', 'laendlich', 4, 'TAPAS');
INSERT INTO core.global_settlement_codes (id, description, class, name_fordcp, code_fordcp, type_fordcp, name_tapas, code_tapas, type_tapas) VALUES (13, 'BBR17_BBR5', 'de.dlr.ivf.tapas.constants.TPS_SettlementSystem', 'R2, K7, Sonstiges', 13, 'FORDCP', 'laendlich', 4, 'TAPAS');
INSERT INTO core.global_settlement_codes (id, description, class, name_fordcp, code_fordcp, type_fordcp, name_tapas, code_tapas, type_tapas) VALUES (14, 'BBR17_BBR5', 'de.dlr.ivf.tapas.constants.TPS_SettlementSystem', 'R3, K8, Zentrum', 14, 'FORDCP', 'laendlich', 4, 'TAPAS');
INSERT INTO core.global_settlement_codes (id, description, class, name_fordcp, code_fordcp, type_fordcp, name_tapas, code_tapas, type_tapas) VALUES (15, 'BBR17_BBR5', 'de.dlr.ivf.tapas.constants.TPS_SettlementSystem', 'R3, K8, Sonstiges', 15, 'FORDCP', 'sehr laendlich', 5, 'TAPAS');
INSERT INTO core.global_settlement_codes (id, description, class, name_fordcp, code_fordcp, type_fordcp, name_tapas, code_tapas, type_tapas) VALUES (16, 'BBR17_BBR5', 'de.dlr.ivf.tapas.constants.TPS_SettlementSystem', 'R3, K9, Zentrum', 16, 'FORDCP', 'laendlich', 4, 'TAPAS');
INSERT INTO core.global_settlement_codes (id, description, class, name_fordcp, code_fordcp, type_fordcp, name_tapas, code_tapas, type_tapas) VALUES (17, 'BBR17_BBR5', 'de.dlr.ivf.tapas.constants.TPS_SettlementSystem', 'R3, K9, Sonstiges', 17, 'FORDCP', 'sehr laendlich', 5, 'TAPAS');