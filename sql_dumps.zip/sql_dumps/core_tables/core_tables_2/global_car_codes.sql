create table core.global_car_codes
(
    name        varchar not null
        constraint carcodes_pkey
            primary key,
    description varchar,
    class       varchar,
    name_cars   varchar,
    code_cars   integer
        constraint carcode_unique
            unique
);

alter table core.global_car_codes
    owner to %DBUSER%;

INSERT INTO core.global_car_codes (name, description, class, name_cars, code_cars) VALUES ('NO', 'no', 'de.dlr.ivf.tapas.constants.TPS_CarCode', 'NO', 2);
INSERT INTO core.global_car_codes (name, description, class, name_cars, code_cars) VALUES ('YES', 'yes', 'de.dlr.ivf.tapas.constants.TPS_CarCode', 'YES', 1);
INSERT INTO core.global_car_codes (name, description, class, name_cars, code_cars) VALUES ('NON_RELEVANT', 'nonRelevant', 'de.dlr.ivf.tapas.constants.TPS_CarCode', 'NON_RELEVANT', 0);