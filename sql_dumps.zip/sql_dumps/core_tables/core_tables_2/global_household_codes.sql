create table core.global_household_codes
(
    id              integer not null
        constraint household_codes_pkey
            primary key,
    description     varchar,
    class           varchar not null,
    name_household  varchar not null,
    code_household  integer not null
        constraint household_codes_code_household_key
            unique,
    number_adults   integer not null,
    number_children integer not null,
    age_code_stba   integer not null
        constraint household_codes_ageclass_fkey
            references core.global_age_codes (code_stba)
            deferrable initially deferred,
    sex_code        integer not null
        constraint household_codes_sexcode_fkey
            references core.global_sex_codes (code_sex)
            deferrable initially deferred
);

alter table core.global_household_codes
    owner to %DBUSER%;

INSERT INTO core.global_household_codes (id, description, class, name_household, code_household, number_adults, number_children, age_code_stba, sex_code) VALUES (1, '2 Personenhaushalt (1A, 1C)', 'de.dlr.ivf.tapas.constants.TPS_HouseholdCode', '2P11nn', 1, 1, 1, -1, 0);
INSERT INTO core.global_household_codes (id, description, class, name_household, code_household, number_adults, number_children, age_code_stba, sex_code) VALUES (2, '3 Personenhaushalt (2A, 1C)', 'de.dlr.ivf.tapas.constants.TPS_HouseholdCode', '3P21nn', 2, 2, 1, -1, 0);
INSERT INTO core.global_household_codes (id, description, class, name_household, code_household, number_adults, number_children, age_code_stba, sex_code) VALUES (3, '3 Personenhaushalt (1A, 2C)', 'de.dlr.ivf.tapas.constants.TPS_HouseholdCode', '3P12nn', 3, 1, 2, -1, 0);
INSERT INTO core.global_household_codes (id, description, class, name_household, code_household, number_adults, number_children, age_code_stba, sex_code) VALUES (4, '4 Personenhaushalt (2A, 2C)', 'de.dlr.ivf.tapas.constants.TPS_HouseholdCode', '4P22nn', 4, 2, 2, -1, 0);
INSERT INTO core.global_household_codes (id, description, class, name_household, code_household, number_adults, number_children, age_code_stba, sex_code) VALUES (5, '4 Personenhaushalt (1A, 3C)', 'de.dlr.ivf.tapas.constants.TPS_HouseholdCode', '4P13nn', 5, 1, 3, -1, 0);
INSERT INTO core.global_household_codes (id, description, class, name_household, code_household, number_adults, number_children, age_code_stba, sex_code) VALUES (6, '5 Personenhaushalt (2A, 3C)', 'de.dlr.ivf.tapas.constants.TPS_HouseholdCode', '5P23nn', 6, 2, 3, -1, 0);
INSERT INTO core.global_household_codes (id, description, class, name_household, code_household, number_adults, number_children, age_code_stba, sex_code) VALUES (7, '2 Personenhaushalt (2A)', 'de.dlr.ivf.tapas.constants.TPS_HouseholdCode', '2P20nn', 7, 2, 0, -1, 0);
INSERT INTO core.global_household_codes (id, description, class, name_household, code_household, number_adults, number_children, age_code_stba, sex_code) VALUES (8, '3 Personenhaushalt (3A)', 'de.dlr.ivf.tapas.constants.TPS_HouseholdCode', '3P30nn', 10, 3, 0, -1, 0);
INSERT INTO core.global_household_codes (id, description, class, name_household, code_household, number_adults, number_children, age_code_stba, sex_code) VALUES (9, '1 Personenhaushalt (25m)', 'de.dlr.ivf.tapas.constants.TPS_HouseholdCode', '1P1031', 81, 1, 0, 3, 1);
INSERT INTO core.global_household_codes (id, description, class, name_household, code_household, number_adults, number_children, age_code_stba, sex_code) VALUES (10, '1 Personenhaushalt (45m)', 'de.dlr.ivf.tapas.constants.TPS_HouseholdCode', '1P1041', 82, 1, 0, 4, 1);
INSERT INTO core.global_household_codes (id, description, class, name_household, code_household, number_adults, number_children, age_code_stba, sex_code) VALUES (11, '1 Personenhaushalt (65m)', 'de.dlr.ivf.tapas.constants.TPS_HouseholdCode', '1P1051', 83, 1, 0, 5, 1);
INSERT INTO core.global_household_codes (id, description, class, name_household, code_household, number_adults, number_children, age_code_stba, sex_code) VALUES (12, '1 Personenhaushalt (75m)', 'de.dlr.ivf.tapas.constants.TPS_HouseholdCode', '1P1061', 84, 1, 0, 6, 1);
INSERT INTO core.global_household_codes (id, description, class, name_household, code_household, number_adults, number_children, age_code_stba, sex_code) VALUES (13, '1 Personenhaushalt (75pm)', 'de.dlr.ivf.tapas.constants.TPS_HouseholdCode', '1P1071', 85, 1, 0, 7, 1);
INSERT INTO core.global_household_codes (id, description, class, name_household, code_household, number_adults, number_children, age_code_stba, sex_code) VALUES (14, '1 Personenhaushalt (25w)', 'de.dlr.ivf.tapas.constants.TPS_HouseholdCode', '1P1032', 91, 1, 0, 3, 2);
INSERT INTO core.global_household_codes (id, description, class, name_household, code_household, number_adults, number_children, age_code_stba, sex_code) VALUES (15, '1 Personenhaushalt (45w)', 'de.dlr.ivf.tapas.constants.TPS_HouseholdCode', '1P1042', 92, 1, 0, 4, 2);
INSERT INTO core.global_household_codes (id, description, class, name_household, code_household, number_adults, number_children, age_code_stba, sex_code) VALUES (16, '1 Personenhaushalt (65w)', 'de.dlr.ivf.tapas.constants.TPS_HouseholdCode', '1P1052', 93, 1, 0, 5, 2);
INSERT INTO core.global_household_codes (id, description, class, name_household, code_household, number_adults, number_children, age_code_stba, sex_code) VALUES (17, '1 Personenhaushalt (75w)', 'de.dlr.ivf.tapas.constants.TPS_HouseholdCode', '1P1062', 94, 1, 0, 6, 2);
INSERT INTO core.global_household_codes (id, description, class, name_household, code_household, number_adults, number_children, age_code_stba, sex_code) VALUES (18, '1 Personenhaushalt (75pw)', 'de.dlr.ivf.tapas.constants.TPS_HouseholdCode', '1P1072', 95, 1, 0, 7, 2);