create table core.global_mode_codes
(
    name        varchar not null
        constraint modecodes_pkey
            primary key,
    description varchar,
    class       varchar,
    name_mct    varchar,
    code_mct    integer,
    type_mct    varchar,
    name_vot    varchar,
    code_vot    integer,
    type_vot    varchar,
    isfix       boolean
);

alter table core.global_mode_codes
    owner to %DBUSER%;

grant select on core.global_mode_codes to tapas_user_group;
grant insert, select, update, delete, truncate, references, trigger on core.global_mode_codes to tapas_admin_group;

INSERT INTO core.global_mode_codes (name, description, class, name_mct, code_mct, type_mct, name_vot, code_vot, type_vot, isfix) VALUES ('WALK', 'null', 'de.dlr.ivf.tapas.mode.TPS_NonMotorisedMode', 'WALK', 0, 'MCT', 'default', 3, 'VOT', false);
INSERT INTO core.global_mode_codes (name, description, class, name_mct, code_mct, type_mct, name_vot, code_vot, type_vot, isfix) VALUES ('BIKE', 'null', 'de.dlr.ivf.tapas.mode.TPS_NonMotorisedMode', 'BIKE', 1, 'MCT', 'default', 3, 'VOT', true);
INSERT INTO core.global_mode_codes (name, description, class, name_mct, code_mct, type_mct, name_vot, code_vot, type_vot, isfix) VALUES ('MIT', 'null', 'de.dlr.ivf.tapas.mode.TPS_IndividualTransportMode', 'MIT', 2, 'MCT', 'MIT', 1, 'VOT', true);
INSERT INTO core.global_mode_codes (name, description, class, name_mct, code_mct, type_mct, name_vot, code_vot, type_vot, isfix) VALUES ('MIT_PASS', 'null', 'de.dlr.ivf.tapas.mode.TPS_IndividualTransportMode', 'MIT_PASS', 3, 'MCT', 'default', 3, 'VOT', false);
INSERT INTO core.global_mode_codes (name, description, class, name_mct, code_mct, type_mct, name_vot, code_vot, type_vot, isfix) VALUES ('TAXI', 'null', 'de.dlr.ivf.tapas.mode.TPS_IndividualTransportMode', 'TAXI', 4, 'MCT', 'default', 3, 'VOT', false);
INSERT INTO core.global_mode_codes (name, description, class, name_mct, code_mct, type_mct, name_vot, code_vot, type_vot, isfix) VALUES ('PT', 'null', 'de.dlr.ivf.tapas.mode.TPS_MassTransportMode', 'PT', 5, 'MCT', 'PT', 2, 'VOT', false);
INSERT INTO core.global_mode_codes (name, description, class, name_mct, code_mct, type_mct, name_vot, code_vot, type_vot, isfix) VALUES ('CAR_SHARING', 'null', 'de.dlr.ivf.tapas.mode.TPS_MassTransportMode', 'CAR_SHARING', 6, 'MCT', 'default', 3, 'VOT', false);