CREATE TABLE core.global_person_codes (
    code integer,
    description character varying,
    code_cars integer,
    code_sex integer,
    person_type character varying,
    has_child text,
    key text,
    min_age integer,
    max_age integer,
    work_status text
);

alter table core.global_person_codes
    owner to %DBUSER%;

grant select on core.global_person_codes to tapas_user_group;
grant insert, select, update, delete, truncate, references, trigger on core.global_person_codes to tapas_admin_group;

INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (2, 'Studenten', 0, 0, 'STUDENT', 'NON_RELEVANT', 'TAPAS', 0, 200, 'NON_RELEVANT');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (0, 'Kleinkinder', 0, 0, 'CHILD', 'NON_RELEVANT', 'TAPAS', 0, 200, 'NON_RELEVANT');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (30, 'R75+oP M', 2, 1, 'RETIREE', 'NON_RELEVANT', 'TAPAS', 75, 200, 'NON_RELEVANT');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (27, 'R75mP W', 1, 2, 'RETIREE', 'NON_RELEVANT', 'TAPAS', 0, 74, 'NON_RELEVANT');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (26, 'R75oP M', 2, 1, 'RETIREE', 'NON_RELEVANT', 'TAPAS', 0, 74, 'NON_RELEVANT');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (28, 'R75oP W', 2, 2, 'RETIREE', 'NON_RELEVANT', 'TAPAS', 0, 74, 'NON_RELEVANT');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (31, 'R75+mP W', 1, 2, 'RETIREE', 'NON_RELEVANT', 'TAPAS', 75, 200, 'NON_RELEVANT');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (32, 'R75+oP W', 2, 2, 'RETIREE', 'NON_RELEVANT', 'TAPAS', 75, 200, 'NON_RELEVANT');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (25, 'R75mP M', 1, 1, 'RETIREE', 'NON_RELEVANT', 'TAPAS', 0, 74, 'NON_RELEVANT');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (29, 'R75+mP M', 1, 1, 'RETIREE', 'NON_RELEVANT', 'TAPAS', 75, 200, 'NON_RELEVANT');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (1, 'Schüler', 0, 0, 'PUPIL', 'NON_RELEVANT', 'TAPAS', 0, 200, 'NON_RELEVANT');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (18, 'EWT65oP M', 2, 1, 'WORKING_ADULT', 'NON_RELEVANT', 'TAPAS', 45, 200, 'WORKING');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (12, 'EWT45oP W', 2, 2, 'WORKING_ADULT', 'NON_RELEVANT', 'TAPAS', 25, 44, 'WORKING');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (33, 'Auszubildende', 0, 0, 'TRAINEE', 'NON_RELEVANT', 'TAPAS', 0, 200, 'PART_TIME');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (13, 'NEW45mP M', 1, 1, 'NON_WORKING_ADULT', 'NON_RELEVANT', 'TAPAS', 25, 44, 'NON_WORKING');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (15, 'NEW45mP W', 1, 2, 'NON_WORKING_ADULT', 'NON_RELEVANT', 'TAPAS', 25, 44, 'NON_WORKING');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (19, 'EWT65mP W', 1, 2, 'WORKING_ADULT', 'NON_RELEVANT', 'TAPAS', 45, 200, 'WORKING');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (5, 'EWT25mP W', 1, 2, 'WORKING_ADULT', 'NON_RELEVANT', 'TAPAS', 0, 24, 'WORKING');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (17, 'EWT65mP M', 1, 1, 'WORKING_ADULT', 'NON_RELEVANT', 'TAPAS', 45, 200, 'WORKING');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (24, 'NEW65oP W', 2, 2, 'NON_WORKING_ADULT', 'NON_RELEVANT', 'TAPAS', 45, 200, 'NON_WORKING');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (11, 'EWT45mP W', 1, 2, 'WORKING_ADULT', 'NON_RELEVANT', 'TAPAS', 25, 44, 'WORKING');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (7, 'NEW25oP', 2, 0, 'NON_WORKING_ADULT', 'NON_RELEVANT', 'TAPAS', 0, 24, 'NON_WORKING');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (21, 'NEW65mP M', 1, 1, 'NON_WORKING_ADULT', 'NON_RELEVANT', 'TAPAS', 45, 200, 'NON_WORKING');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (8, 'NEW25mP W', 1, 2, 'NON_WORKING_ADULT', 'NON_RELEVANT', 'TAPAS', 0, 24, 'NON_WORKING');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (3, 'EWT25mP M', 1, 1, 'WORKING_ADULT', 'NON_RELEVANT', 'TAPAS', 0, 24, 'WORKING');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (9, 'EWT45mP M', 1, 1, 'WORKING_ADULT', 'NON_RELEVANT', 'TAPAS', 25, 44, 'WORKING');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (10, 'EWT45oP M', 2, 1, 'WORKING_ADULT', 'NON_RELEVANT', 'TAPAS', 25, 44, 'WORKING');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (23, 'NEW65mP W', 1, 2, 'NON_WORKING_ADULT', 'NON_RELEVANT', 'TAPAS', 45, 200, 'NON_WORKING');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (16, 'NEW45oP W', 2, 2, 'NON_WORKING_ADULT', 'NON_RELEVANT', 'TAPAS', 25, 44, 'NON_WORKING');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (14, 'NEW45oP M', 2, 1, 'NON_WORKING_ADULT', 'NON_RELEVANT', 'TAPAS', 25, 44, 'NON_WORKING');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (6, 'NEW25mP M', 1, 1, 'NON_WORKING_ADULT', 'NON_RELEVANT', 'TAPAS', 0, 24, 'NON_WORKING');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (22, 'NEW65oP M', 2, 1, 'NON_WORKING_ADULT', 'NON_RELEVANT', 'TAPAS', 45, 200, 'NON_WORKING');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (20, 'EWT65oP W', 2, 2, 'WORKING_ADULT', 'NON_RELEVANT', 'TAPAS', 45, 200, 'WORKING');
INSERT INTO core.global_person_codes (code, description, code_cars, code_sex, person_type, has_child, key, min_age, max_age, work_status) VALUES (4, 'EWT25oP', 2, 0, 'WORKING_ADULT', 'NON_RELEVANT', 'TAPAS', 0, 24, 'WORKING');
