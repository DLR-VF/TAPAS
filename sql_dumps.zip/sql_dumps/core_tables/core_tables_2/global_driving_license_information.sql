create table core.global_driving_license_information
(
    name        varchar not null
        constraint drivinglicenseinformation_pkey
            primary key,
    description varchar,
    class       varchar,
    name_dli    varchar,
    code_dli    integer
);

alter table core.global_driving_license_information
    owner to %DBUSER%;

grant select on core.global_driving_license_information to tapas_user_group;
grant insert, select, update, delete, truncate, references, trigger on core.global_driving_license_information to tapas_admin_group;

INSERT INTO core.global_driving_license_information (name, description, class, name_dli, code_dli) VALUES ('UNKNOWN', '--', 'de.dlr.ivf.tapas.constants.TPS_DrivingLicenseInformation', 'unknown', -1);
INSERT INTO core.global_driving_license_information (name, description, class, name_dli, code_dli) VALUES ('NO_DRIVING_LICENSE', '--', 'de.dlr.ivf.tapas.constants.TPS_DrivingLicenseInformation', 'no', 2);
INSERT INTO core.global_driving_license_information (name, description, class, name_dli, code_dli) VALUES ('CAR', '--', 'de.dlr.ivf.tapas.constants.TPS_DrivingLicenseInformation', 'car', 1);