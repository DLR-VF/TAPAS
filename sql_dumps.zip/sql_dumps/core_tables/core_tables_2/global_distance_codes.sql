create table core.global_distance_codes
(
    id          integer not null
        constraint distancecodes_pkey
            primary key,
    description varchar,
    class       varchar,
    name_vot    varchar,
    code_vot    integer,
    type_vot    varchar,
    name_mct    varchar,
    code_mct    integer,
    type_mct    varchar,
    max         integer
);

alter table core.global_distance_codes
    owner to %DBUSER%;

grant select on core.global_distance_codes to tapas_user_group;
grant insert, select, update, delete, truncate, references, trigger on core.global_distance_codes to tapas_admin_group;

INSERT INTO core.global_distance_codes (id, description, class, name_vot, code_vot, type_vot, name_mct, code_mct, type_mct, max) VALUES (1, 'under 200', 'de.dlr.ivf.tapas.constants.TPS_Distance', 'under 5k', 1, 'VOT', 'under 200', 200, 'MCT', 200);
INSERT INTO core.global_distance_codes (id, description, class, name_vot, code_vot, type_vot, name_mct, code_mct, type_mct, max) VALUES (2, 'under 500', 'de.dlr.ivf.tapas.constants.TPS_Distance', 'under 5k', 1, 'VOT', 'under 500', 500, 'MCT', 500);
INSERT INTO core.global_distance_codes (id, description, class, name_vot, code_vot, type_vot, name_mct, code_mct, type_mct, max) VALUES (3, 'under 1k', 'de.dlr.ivf.tapas.constants.TPS_Distance', 'under 5k', 1, 'VOT', 'under 1k', 1000, 'MCT', 1000);
INSERT INTO core.global_distance_codes (id, description, class, name_vot, code_vot, type_vot, name_mct, code_mct, type_mct, max) VALUES (4, 'under 2k', 'de.dlr.ivf.tapas.constants.TPS_Distance', 'under 5k', 1, 'VOT', 'under 2k', 2000, 'MCT', 2000);
INSERT INTO core.global_distance_codes (id, description, class, name_vot, code_vot, type_vot, name_mct, code_mct, type_mct, max) VALUES (5, 'under 5k', 'de.dlr.ivf.tapas.constants.TPS_Distance', 'under 5k', 1, 'VOT', 'under 5k', 5000, 'MCT', 5000);
INSERT INTO core.global_distance_codes (id, description, class, name_vot, code_vot, type_vot, name_mct, code_mct, type_mct, max) VALUES (6, 'under 7k', 'de.dlr.ivf.tapas.constants.TPS_Distance', 'under 10k', 2, 'VOT', 'under 7k', 7000, 'MCT', 7000);
INSERT INTO core.global_distance_codes (id, description, class, name_vot, code_vot, type_vot, name_mct, code_mct, type_mct, max) VALUES (7, 'under 10k', 'de.dlr.ivf.tapas.constants.TPS_Distance', 'under 10k', 2, 'VOT', 'under 10k', 10000, 'MCT', 10000);
INSERT INTO core.global_distance_codes (id, description, class, name_vot, code_vot, type_vot, name_mct, code_mct, type_mct, max) VALUES (8, 'under 15k', 'de.dlr.ivf.tapas.constants.TPS_Distance', 'under 30k', 3, 'VOT', 'under 15k', 15000, 'MCT', 15000);
INSERT INTO core.global_distance_codes (id, description, class, name_vot, code_vot, type_vot, name_mct, code_mct, type_mct, max) VALUES (9, 'under 20k', 'de.dlr.ivf.tapas.constants.TPS_Distance', 'under 30k', 3, 'VOT', 'under 20k', 20000, 'MCT', 20000);
INSERT INTO core.global_distance_codes (id, description, class, name_vot, code_vot, type_vot, name_mct, code_mct, type_mct, max) VALUES (10, 'under 30k', 'de.dlr.ivf.tapas.constants.TPS_Distance', 'under 30k', 3, 'VOT', 'under 30k', 30000, 'MCT', 30000);
INSERT INTO core.global_distance_codes (id, description, class, name_vot, code_vot, type_vot, name_mct, code_mct, type_mct, max) VALUES (11, 'under 50k', 'de.dlr.ivf.tapas.constants.TPS_Distance', 'under 50k', 4, 'VOT', 'under 50k', 50000, 'MCT', 50000);
INSERT INTO core.global_distance_codes (id, description, class, name_vot, code_vot, type_vot, name_mct, code_mct, type_mct, max) VALUES (12, 'under 100k', 'de.dlr.ivf.tapas.constants.TPS_Distance', 'under 100k', 5, 'VOT', 'under 100k', 100000, 'MCT', 100000);
INSERT INTO core.global_distance_codes (id, description, class, name_vot, code_vot, type_vot, name_mct, code_mct, type_mct, max) VALUES (13, 'over 100k', 'de.dlr.ivf.tapas.constants.TPS_Distance', 'over 100k', 5, 'VOT', 'over 100k', 1000000, 'MCT', 2147483647);