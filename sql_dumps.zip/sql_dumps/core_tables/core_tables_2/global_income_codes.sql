create table core.global_income_codes
(
    id          integer not null
        constraint incomecodes_pkey
            primary key,
    description varchar,
    class       varchar,
    name_income varchar,
    code_income integer,
    max         integer
);

alter table core.global_income_codes
    owner to %DBUSER%;

INSERT INTO core.global_income_codes (id, description, class, name_income, code_income, max) VALUES (1, 'under 900', 'de.dlr.ivf.tapas.constants.TPS_Income', 'under 900', 1, 900);
INSERT INTO core.global_income_codes (id, description, class, name_income, code_income, max) VALUES (2, 'under 1500', 'de.dlr.ivf.tapas.constants.TPS_Income', 'under 1500', 2, 1500);
INSERT INTO core.global_income_codes (id, description, class, name_income, code_income, max) VALUES (3, 'under 2000', 'de.dlr.ivf.tapas.constants.TPS_Income', 'under 2000', 3, 2000);
INSERT INTO core.global_income_codes (id, description, class, name_income, code_income, max) VALUES (4, 'under 2600', 'de.dlr.ivf.tapas.constants.TPS_Income', 'under 2600', 4, 2600);
INSERT INTO core.global_income_codes (id, description, class, name_income, code_income, max) VALUES (5, 'under 3600', 'de.dlr.ivf.tapas.constants.TPS_Income', 'under 3600', 5, 3600);
INSERT INTO core.global_income_codes (id, description, class, name_income, code_income, max) VALUES (6, 'over 3600', 'de.dlr.ivf.tapas.constants.TPS_Income', 'over 3600', 6, 2147483647);