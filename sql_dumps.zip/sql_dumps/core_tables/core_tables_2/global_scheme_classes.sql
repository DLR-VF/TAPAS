create table core.global_scheme_classes
(
    scheme_class_id integer not null
        constraint scheme_classes_pkey_mid
            primary key,
    avg_travel_time double precision,
    proz_std_dev    double precision
);

alter table core.global_scheme_classes
    owner to %DBUSER%;

INSERT INTO core.global_scheme_classes (scheme_class_id, avg_travel_time, proz_std_dev) VALUES (1, 85.226109, 0.95016);
INSERT INTO core.global_scheme_classes (scheme_class_id, avg_travel_time, proz_std_dev) VALUES (2, 109.3708, 0.891078);
INSERT INTO core.global_scheme_classes (scheme_class_id, avg_travel_time, proz_std_dev) VALUES (3, 110.144598, 0.83753);
INSERT INTO core.global_scheme_classes (scheme_class_id, avg_travel_time, proz_std_dev) VALUES (4, 94.259176, 0.849238);
INSERT INTO core.global_scheme_classes (scheme_class_id, avg_travel_time, proz_std_dev) VALUES (5, 118.644362, 0.866702);
INSERT INTO core.global_scheme_classes (scheme_class_id, avg_travel_time, proz_std_dev) VALUES (6, 53.736961, 0.873016);
INSERT INTO core.global_scheme_classes (scheme_class_id, avg_travel_time, proz_std_dev) VALUES (7, 101.205521, 0.785276);
INSERT INTO core.global_scheme_classes (scheme_class_id, avg_travel_time, proz_std_dev) VALUES (8, 97.923977, 0.762183);
INSERT INTO core.global_scheme_classes (scheme_class_id, avg_travel_time, proz_std_dev) VALUES (9, 83.729032, 0.780645);
INSERT INTO core.global_scheme_classes (scheme_class_id, avg_travel_time, proz_std_dev) VALUES (10, 111.947939, 0.841649);
INSERT INTO core.global_scheme_classes (scheme_class_id, avg_travel_time, proz_std_dev) VALUES (11, 124.761589, 0.730684);
INSERT INTO core.global_scheme_classes (scheme_class_id, avg_travel_time, proz_std_dev) VALUES (12, 82.321039, 0.879842);
INSERT INTO core.global_scheme_classes (scheme_class_id, avg_travel_time, proz_std_dev) VALUES (13, 49.712349, 0.894578);
INSERT INTO core.global_scheme_classes (scheme_class_id, avg_travel_time, proz_std_dev) VALUES (14, 105.86793, 0.812876);
INSERT INTO core.global_scheme_classes (scheme_class_id, avg_travel_time, proz_std_dev) VALUES (15, 104.387919, 0.903728);
INSERT INTO core.global_scheme_classes (scheme_class_id, avg_travel_time, proz_std_dev) VALUES (16, 105.487141, 0.91528);
INSERT INTO core.global_scheme_classes (scheme_class_id, avg_travel_time, proz_std_dev) VALUES (17, 101.430831, 0.855124);
INSERT INTO core.global_scheme_classes (scheme_class_id, avg_travel_time, proz_std_dev) VALUES (18, 88.531865, 0.909127);
INSERT INTO core.global_scheme_classes (scheme_class_id, avg_travel_time, proz_std_dev) VALUES (19, 88.540458, 0.894656);
INSERT INTO core.global_scheme_classes (scheme_class_id, avg_travel_time, proz_std_dev) VALUES (20, 83.106052, 0.877193);
INSERT INTO core.global_scheme_classes (scheme_class_id, avg_travel_time, proz_std_dev) VALUES (21, 149.715183, 0.904151);
INSERT INTO core.global_scheme_classes (scheme_class_id, avg_travel_time, proz_std_dev) VALUES (22, 117.042785, 0.89576);
INSERT INTO core.global_scheme_classes (scheme_class_id, avg_travel_time, proz_std_dev) VALUES (23, 146.16619, 0.913448);
INSERT INTO core.global_scheme_classes (scheme_class_id, avg_travel_time, proz_std_dev) VALUES (90, 56.559148, 0.922116);