-- Function: core.load_episodes(character varying)

-- DROP FUNCTION core.load_episodes(character varying);

CREATE OR REPLACE FUNCTION core.load_episodes(file_episodes character varying)
  RETURNS boolean AS
$BODY$BEGIN
CREATE TEMPORARY TABLE episodes_temp (
	id integer, id2 integer, iddg integer, b_start integer, b_duration integer, code integer, home integer, changes integer,
	b_start_e double precision, alpha_e double precision, b_start_l double precision, alpha_l double precision,
	b_duration_s double precision, beta_s double precision, b_duration_l double precision, beta_l double precision, 
	tournumber integer, fhome integer, workchain integer, homework integer, fak integer, PRIMARY KEY (id));

EXECUTE 'COPY episodes_temp FROM ''' || file_episodes || ''' WITH CSV HEADER';

EXECUTE 'SELECT core.delete_rows(''core.global_episodes'','''','''',-1)';
EXECUTE 'SELECT core.delete_rows(''core.global_schemes'','''','''',-1)';
DELETE FROM core.global_scheme_classes WHERE core.global_scheme_classes.scheme_class_id IN (SELECT DISTINCT iddg FROM episodes_temp);

INSERT INTO core.global_scheme_classes (SELECT DISTINCT iddg FROM episodes_temp);
INSERT INTO core.global_schemes (SELECT DISTINCT ON (id2) id2, iddg, homework = 1 FROM episodes_temp);
INSERT INTO core.global_episodes (SELECT id2, b_start, b_duration, code, fhome = 1, b_start_e, alpha_e, b_start_l, alpha_l, 
				  b_duration_s, beta_s, b_duration_l, beta_l, tournumber, workchain = 1 FROM episodes_temp);

DROP TABLE episodes_temp;
RETURN TRUE;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.load_episodes(character varying) OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.load_episodes(character varying) TO public;

