-- Function: core.load_next_pt_stop(character varying, character varying, character varying)

-- DROP FUNCTION core.load_next_pt_stop(character varying, character varying, character varying);

CREATE OR REPLACE FUNCTION core.load_next_pt_stop(filename character varying, next_pt_stop_name character varying, tablename character varying)
  RETURNS boolean AS
$BODY$BEGIN
CREATE TEMPORARY TABLE next_pt_temp(id integer, next_pt double precision, PRIMARY KEY (id));
EXECUTE 'COPY next_pt_temp  FROM ''' || filename || ''' WITH CSV HEADER';
EXECUTE 'SELECT core.delete_rows(''' || tablename || ''', ''next_pt_stop_name'', ''' || next_pt_stop_name || ''', 0)';
EXECUTE 'INSERT INTO ' || tablename || ' (SELECT id, next_pt, ''' || next_pt_stop_name || ''' FROM next_pt_temp)';
DROP TABLE next_pt_temp;
RETURN TRUE;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.load_next_pt_stop(character varying, character varying, character varying) OWNER TO %DBUSER%;
