-- Function: core.load_mode_choice_tree(character varying, character varying)

-- DROP FUNCTION core.load_mode_choice_tree(character varying, character varying);

CREATE OR REPLACE FUNCTION core.load_mode_choice_tree(filename character varying, "name" character varying)
  RETURNS boolean AS
$BODY$BEGIN
CREATE TEMPORARY TABLE mode_choice_trees_temp(
	id integer, level integer, size integer, idParent integer, attVal integer[], splitVar character varying, distribution double precision[], PRIMARY KEY (id));
EXECUTE 'COPY mode_choice_trees_temp FROM ''' || filename || ''' WITH CSV HEADER';
EXECUTE 'SELECT core.delete_rows(''core.global_mode_choice_trees'', ''name'', ''' || name || ''', 0)';
EXECUTE 'INSERT INTO core.global_mode_choice_trees (SELECT '''||name||''', id, idParent, attVal, splitVar, distribution FROM mode_choice_trees_temp)';
DROP TABLE mode_choice_trees_temp;
RETURN TRUE;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.load_mode_choice_tree(character varying, character varying) OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.load_mode_choice_tree(character varying, character varying) TO public;
GRANT EXECUTE ON FUNCTION core.load_mode_choice_tree(character varying, character varying) TO tapas_user_group;

