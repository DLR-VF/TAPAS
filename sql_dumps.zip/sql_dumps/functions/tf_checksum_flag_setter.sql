-- Function: public.checksum_flag_setter()

-- DROP FUNCTION public.checksum_flag_setter();

CREATE OR REPLACE FUNCTION public.checksum_flag_setter()
  RETURNS trigger AS
$BODY$
DECLARE
rec record;



BEGIN
  IF TG_OP = 'INSERT' OR TG_OP = 'DELETE' THEN
    WITH all_hashes AS (
      SELECT ROW_NUMBER() OVER(ORDER BY COUNT(sha512) DESC) as dominance, COUNT(sha512) as cnt, sha512
      FROM public.server_processes
      WHERE sha512 IS NOT null AND sha512 != '' AND sha512 != 'DEBUG' AND end_time IS NULL
      GROUP BY sha512),
    dominant_hash AS (
      SELECT * FROM all_hashes
      WHERE dominance = 1),
    second_dominant_hash AS (
      SELECT * FROM all_hashes
      WHERE dominance = 2
    )
SELECT dominant_hash.cnt as dom_cnt, dominant_hash.sha512 as dom_hash, (SELECT cnt FROM second_dominant_hash) as sec_cnt INTO rec FROM dominant_hash;

IF rec.dom_cnt = rec.sec_cnt THEN
UPDATE public.server_processes SET sha512_status = 0 WHERE sha512 != 'DEBUG' AND end_time IS NULL;
ELSE
UPDATE public.server_processes SET sha512_status = 1 WHERE sha512 = rec.dom_hash AND sha512 != 'DEBUG' AND end_time IS NULL;
UPDATE public.server_processes SET sha512_status = 0 WHERE sha512 != rec.dom_hash AND sha512 != 'DEBUG' AND end_time IS NULL;
END IF;

UPDATE public.server_processes SET sha512_status = 2 WHERE sha512 = 'DEBUG' AND end_time IS NULL;
UPDATE public.server_processes SET sha512_status = -1 WHERE (sha512 IS NULL OR sha512 = '') AND end_time IS NULL;
END IF;


RETURN NEW;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION public.checksum_flag_setter OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION public.checksum_flag_setter() TO tapas_admin_group;
GRANT EXECUTE ON FUNCTION public.checksum_flag_setter() TO tapas_user_group;
