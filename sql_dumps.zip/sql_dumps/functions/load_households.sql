-- Function: core.load_households(character varying, character varying, character varying)

-- DROP FUNCTION core.load_households(character varying, character varying, character varying);

CREATE OR REPLACE FUNCTION core.load_households(hh_file character varying, hh_table character varying, hh_key character varying)
  RETURNS boolean AS
$BODY$BEGIN
CREATE TEMPORARY TABLE tmp_hh (
	idhh integer, bez_id integer, tvz integer, homex text, homey text, phh integer, carshh integer, hh_eink integer, PRIMARY KEY (idhh));
EXECUTE 'COPY tmp_hh FROM ''' ||  hh_file || ''' WITH CSV HEADER DELIMITER E''\t'' NULL as '';''';

-- delete option
-- EXECUTE 'SELECT core.delete_rows(''' ||  hh_table || ''', ''hh_year'', ''' || year || ''', 1)';
-- EXECUTE 'INSERT INTO ' ||  hh_table || ' ( SELECT tp.idhh, -1, tp.phh, tp.carshh, tp.hh_eink, tp.tvz, 
--	       GeometryFromText(''POINT(''|| tp.homex || '' '' || tp.homey || '')'', 4326), ' || year || ' FROM tmp_hh tp)';

-- insert or update option
EXECUTE 'UPDATE ' || hh_table || ' SET 
(hh_id, hh_type, hh_persons, hh_cars, hh_income, hh_taz_id, hh_key, hh_coordinate) = 
(tp.idhh, -1, tp.phh, tp.carshh, tp.hh_eink, tp.tvz, ''' || hh_key || ''', GeometryFromText(''POINT(''|| tp.homex || '' '' || tp.homey || '')'', 4326))
FROM tmp_hh tp
WHERE tp.idhh = hh_id AND ''' || hh_key || ''' = hh_key';

EXECUTE 'INSERT INTO ' || hh_table || ' (
	SELECT tp.idhh, -1, tp.phh, tp.carshh, ''{1}'',tp.hh_eink, tp.tvz, 
	''' || hh_key || ''', false,-1,GeometryFromText(''POINT(''|| tp.homex || '' '' || tp.homey || '')'', 4326) 
	FROM tmp_hh tp WHERE tp.idhh IN (SELECT idhh FROM tmp_hh EXCEPT SELECT hh_id FROM ' || hh_table || ' WHERE hh_key = ''' || hh_key || '''))';

DROP TABLE tmp_hh;
RETURN TRUE;
END$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION core.load_households(character varying, character varying, character varying)
  OWNER TO %DBUSER%;