-- Function: core.mobility_calculator_function(character varying, character varying)

-- DROP FUNCTION core.mobility_calculator_function( 						hh_id integer, hh_type integer, hh_persons integer, hh_cars integer, hh_income integer, 
--																															loc_x double precision, loc_y double precision, 
--																															pri_loc_x double precision, pri_loc_y double precision,hh_has_child boolean, 
--																															p_id integer, p_group integer, p_sex integer, p_age integer, p_age_stba integer, p_working double precision,
--																															p_abo integer, p_budget_pt double precision, p_budget_it double precision, p_budget_it_fi double precision,
--																															p_driver_license integer, p_has_bike boolean);
--DROP type trip CASCADE;
--create type trip as (	p_id integer, p_group integer, p_age_category integer, p_age integer, p_sex integer, p_has_season_ticket TEXT, p_has_licence TEXT, 
--											hh_id integer, hh_members integer, hh_has_child TEXT, hh_cars integer, hh_income double precision, scheme_id integer, 
--											score_combined double precision, score_finance double precision, score_time double precision, taz_id_start integer, block_id_start integer, 
--											loc_id_start integer, loc_coord_x_start double precision, loc_coord_y_start double precision, taz_bbr_type_start integer, 
--											taz_has_toll_start TEXT, taz_id_end integer, block_id_end integer, loc_id_end integer, loc_coord_x_end double precision,
--											loc_coord_y_end double precision, taz_bbr_type_end integer, taz_has_toll_end TEXT, start_time_min integer, travel_time_sec double precision, mode integer,
--											car_type integer, distance_bl_m double precision, distance_real_m double precision, activity integer, is_home TEXT,
--											activity_start_min integer, activity_duration_min integer,emission_type integer,is_restricted TEXT
--);

CREATE OR REPLACE FUNCTION core.mobility_calculator_function(	hh_id integer, hh_type integer, hh_persons integer, hh_cars integer, hh_income integer, 
																															loc_x double precision, loc_y double precision, 
																															pri_loc_x double precision, pri_loc_y double precision, hh_has_child boolean, 
																															p_id integer, p_group integer, p_sex integer, p_age integer, p_age_stba integer, p_working double precision,
																															p_abo integer, p_budget_pt double precision, p_budget_it double precision, p_budget_it_fi double precision,
																															p_driver_license integer, p_has_bike boolean)
  RETURNS boolean AS
$BODY$
DECLARE table_key TEXT;
DECLARE	command TEXT;
DECLARE	table_taz TEXT;
DECLARE	table_cars TEXT;
DECLARE	table_household TEXT;
DECLARE	table_persons TEXT;
DECLARE	p_hh_key TEXT;
DECLARE	schemaname TEXT;
DECLARE	tempschemaname TEXT;
DECLARE	region TEXT;
DECLARE	table_household_tmp TEXT;
DECLARE	table_locations TEXT;
DECLARE	table_trips TEXT;		
DECLARE	taz integer;
DECLARE pri_loc_id integer;
DECLARE count integer;
DECLARE loop_count integer;
DECLARE valuePre integer;
DECLARE valuePost integer;
DECLARE loc_x_gen double precision;
DECLARE loc_y_gen double precision;
begin
	--get the table key
	command ='SELECT sim_key FROM simulation_parameters where param_key = ''DB_HOUSEHOLD_AND_PERSON_KEY'' and param_value = ''ONE_HOUSEHOLD_Y2008'' ORDER BY sim_key LIMIT 1';
	EXECUTE command INTO table_key;
	IF(table_key IS NULL) THEN
		RETURN FALSE;
	END IF;
	--get some preference data
	command = 'SELECT param_value FROM simulation_parameters WHERE param_key = ''DB_SCHEMA_CORE'' and sim_key = '''||table_key||'''';
	EXECUTE command INTO schemaname;
	command = 'SELECT param_value FROM simulation_parameters WHERE param_key = ''DB_REGION'' and sim_key = '''||table_key||'''';
	EXECUTE command INTO region;
	command = 'SELECT param_value FROM simulation_parameters WHERE param_key = ''DB_SCHEMA_TEMP'' and sim_key = '''||table_key||'''';
	EXECUTE command INTO tempschemaname;
	table_household_tmp= tempschemaname||'households_'||table_key;
	table_household_tmp= tempschemaname||'households_'||table_key;
	command = 'SELECT param_value FROM simulation_parameters WHERE param_key = ''DB_TABLE_TRIPS'' and sim_key = '''||table_key||'''';
	EXECUTE command INTO table_trips;
	table_trips = table_trips||'_'||table_key;
	command = 'SELECT param_value FROM simulation_parameters WHERE param_key = ''DB_TABLE_HOUSEHOLD'' and sim_key = '''||table_key||'''';
	EXECUTE command INTO table_household;
	table_household = schemaname||table_household;
	command = 'SELECT param_value FROM simulation_parameters WHERE param_key = ''DB_TABLE_LOCATION'' and sim_key = '''||table_key||'''';
	EXECUTE command INTO table_locations;
	table_locations = schemaname||table_locations;
	command = 'SELECT param_value FROM simulation_parameters WHERE param_key = ''DB_TABLE_PERSON'' and sim_key = '''||table_key||'''';
	EXECUTE command INTO table_persons;
	table_persons = schemaname||table_persons;
	command = 'SELECT param_value FROM simulation_parameters WHERE param_key = ''DB_HOUSEHOLD_AND_PERSON_KEY'' and sim_key = '''||table_key||'''';
	EXECUTE command INTO p_hh_key;
	command = 'SELECT param_value FROM simulation_parameters WHERE param_key = ''DB_TABLE_TAZ'' and sim_key = '''||table_key||'''';
	EXECUTE command INTO table_taz;
	table_taz = schemaname||table_taz;
	command = 'SELECT param_value FROM simulation_parameters WHERE param_key = ''DB_TABLE_CARS'' and sim_key = '''||table_key||'''';
	EXECUTE command INTO table_cars;
	table_cars = schemaname||table_cars;
	

	IF abs(loc_x)<=180 AND abs(loc_y)<=180 THEN
		loc_x_gen = loc_x;
		loc_y_gen = loc_y;
		--get taz id
		command = 'select taz_id FROM '||table_taz||' ORDER BY distance(taz_coordinate, setsrid(makepoint('||loc_x||','||loc_y||'),4326)) LIMIT 1';
		EXECUTE command INTO taz;
	ELSE
		--get house coordinates if not given!	
		command = 'select taz_id FROM '||table_taz||' WHERE taz_id = random()*(SELECT taz_id FROM '||table_taz||' ORDER BY taz_id DESC LIMIT 1) LIMIT 1';
		EXECUTE command INTO taz;
		command = 'select X(taz_coordinate) FROM '||table_taz||' WHERE taz_id = '||taz;
		EXECUTE command INTO loc_x_gen;
		command = 'select Y(taz_coordinate) FROM '||table_taz||' WHERE taz_id = '||taz;
		EXECUTE command INTO loc_y_gen;
	END IF;
	-- get primary location, if set
	IF abs(pri_loc_x)<=180 AND abs(pri_loc_y)<=180 THEN
		-- select according to person group: 1: pupil ->schools 2: Student ->university others: work
		IF p_group = 1 THEN --pupil
			command = 'select loc_id FROM '||table_locations||' WHERE loc_code = 8 ORDER BY distance(loc_coordinate, setsrid(makepoint('||pri_loc_x||','||pri_loc_y||'),4326)) LIMIT 1';
		ELSE
			IF p_group = 2 THEN --student
				command = 'select loc_id FROM '||table_locations||' WHERE loc_code = 9 ORDER BY distance(loc_coordinate, setsrid(makepoint('||pri_loc_x||','||pri_loc_y||'),4326)) LIMIT 1';
			ELSE --worker
				command = 'select loc_id FROM '||table_locations||' WHERE loc_code = 4 ORDER BY distance(loc_coordinate, setsrid(makepoint('||pri_loc_x||','||pri_loc_y||'),4326)) LIMIT 1';
			END IF;
		END IF;		
		EXECUTE command INTO pri_loc_id;
	ELSE
		pri_loc_id = -1;
	END IF;
	--update household
	command = 'UPDATE '||table_household||' SET hh_type='||hh_type||', hh_persons='||hh_persons||', hh_cars='||hh_cars||
						', hh_income ='||hh_income||', hh_has_child='||hh_has_child||', hh_coordinate= setsrid(makepoint('||loc_x_gen||','||loc_y_gen||'),4326), hh_taz_id = '||taz||
						', hh_car_ids = ARRAY(SELECT car_id FROM '||table_cars||' WHERE car_key='''||p_hh_key||''' LIMIT '||hh_cars||') '||
						' WHERE hh_id = '||hh_id ||' AND hh_key = '''||p_hh_key||'''';
	EXECUTE command;
	
	--update main person
	command = 'UPDATE '||table_persons||' SET p_group='||p_group||', p_sex='||p_sex||', p_age='||p_age||', p_work_id='||pri_loc_id||
						', p_age_stba ='||p_age_stba||', p_working='||p_working||', p_abo= '||p_abo||', p_budget_pt = '||p_budget_pt||
						', p_budget_it ='||p_budget_it||', p_budget_it_fi='||p_budget_it_fi||', p_driver_license= '||p_driver_license||', p_has_bike = '||p_has_bike||
						' WHERE p_id = '||p_id ||' AND p_hh_id= '||hh_id||' AND p_key = '''||p_hh_key||'''';
	EXECUTE command;
	
	-- delete other persons
	command = 'DELETE FROM '||table_persons||' WHERE p_key = '''||p_hh_key||''' AND NOT p_id = '''||p_id ||'''';
	EXECUTE command;
	count =1;
	
	IF hh_has_child THEN
		--add a child
		command = 'INSERT INTO '||table_persons||' VALUES ( '|| (p_id+count) ||','||hh_id||', 0, 1, 3, 1, -1, 0, 0, 99999,99999,371.94, '''||p_hh_key||''' ,0, TRUE)';
		EXECUTE command;
		count = count+1;
	END IF;
	
	WHILE count < hh_persons LOOP
		--add a dummy person
		command = 'INSERT INTO '||table_persons||' VALUES ( '|| (p_id+count) ||','||hh_id||', 11, 2, 28, 10, -1, 1, 1, 99999,99999,371.94, '''||p_hh_key||''' ,1, TRUE)';
		EXECUTE command;
		count = count+1;	
	END LOOP;
	
	--delete household from triptable
  command = 'SELECT core.deletehhfromtrip('''||table_trips||''',''ARRAY['||hh_id||']'')';
  EXECUTE command;
  command = 'SELECT count(hh_id) FROM '||table_household_tmp||' WHERE hh_finished=TRUE';
  EXECUTE command INTO valuePre;
  --reset household from joblist
  command = 'SELECT core.sethhfalse('''||table_household_tmp||''',''ARRAY['||hh_id||']'')';
  EXECUTE command;
  command = 'SELECT count(hh_id) FROM '||table_household_tmp||' WHERE hh_finished=TRUE';
  EXECUTE command INTO valuePost;
	valuePre = valuePre - valuePost; -- difference
	IF valuePre>0 THEN
  --reset progress bar
  command = 'SELECT core.decrProgress('''||table_key||''','||valuePre||')';
  EXECUTE command;
	--restart simulation
	command = 'UPDATE simulations SET sim_ready = true, sim_started = true, sim_finished = false WHERE sim_key = '''||table_key ||'''';
	EXECUTE command;
	END IF;
	
RETURN true;
end;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION core.mobility_calculator_function(			 				hh_id integer, hh_type integer, hh_persons integer, hh_cars integer, hh_income integer, 
																															loc_x double precision, loc_y double precision, 
																															pri_loc_x double precision, pri_loc_y double precision, hh_has_child boolean, 
																															p_id integer, p_group integer, p_sex integer, p_age integer, p_age_stba integer, p_working double precision,
																															p_abo integer, p_budget_pt double precision, p_budget_it double precision, p_budget_it_fi double precision,
																															p_driver_license integer, p_has_bike boolean)
  OWNER TO %DBUSER%;

--get function

-- DROP FUNCTION core.mobility_calculator_function_get(				hh_id integer, p_id integer);


				
CREATE OR REPLACE FUNCTION core.mobility_calculator_function_get(	hh_id integer, p_id integer)
  RETURNS SETOF public.trip AS
$BODY$
DECLARE table_key TEXT;
DECLARE	command TEXT;
DECLARE	p_hh_key TEXT;
DECLARE	schemaname TEXT;
DECLARE	region TEXT;
DECLARE	table_trips TEXT;		
DECLARE count integer;
DECLARE loop_count integer;
begin
	--get the table key
	command ='SELECT sim_key FROM simulation_parameters where param_key = ''DB_HOUSEHOLD_AND_PERSON_KEY'' and param_value = ''ONE_HOUSEHOLD_Y2008'' ORDER BY sim_key LIMIT 1';
	EXECUTE command INTO table_key;
	--get some preference data
	command = 'SELECT param_value FROM simulation_parameters WHERE param_key = ''DB_SCHEMA_CORE'' and sim_key = '''||table_key||'''';
	EXECUTE command INTO schemaname;
	command = 'SELECT param_value FROM simulation_parameters WHERE param_key = ''DB_REGION'' and sim_key = '''||table_key||'''';
	EXECUTE command INTO region;
	command = 'SELECT param_value FROM simulation_parameters WHERE param_key = ''DB_TABLE_TRIPS'' and sim_key = '''||table_key||'''';
	EXECUTE command INTO table_trips;
	table_trips = table_trips||'_'||table_key;
	command = 'SELECT param_value FROM simulation_parameters WHERE param_key = ''DB_HOUSEHOLD_AND_PERSON_KEY'' and sim_key = '''||table_key||'''';
	EXECUTE command INTO p_hh_key;
	
	
	
	--wait for simulation ot finish
	loop_count =0;
	LOOP
    command = 'SELECT count(hh_id) FROM '||table_trips ||' WHERE hh_id = '||hh_id;
    EXECUTE command INTO count;
	--wait max for household computed or max 5 min = 5*6*10seconds
    EXIT WHEN count > 0 OR loop_count >= 30 ;  
    loop_count = loop_count+1;
    --sleep for 10 seconds
    PERFORM pg_sleep(10);
	END LOOP;

	command = '
SELECT ' ||
-- Person attributes from $region_persons ps
'ps.p_id, 
ps.p_group, 
ps.p_age_stba as p_age_category, 
ps.p_age,
ps.p_sex, 
CASE WHEN ps.p_abo = 1 THEN ''true'' ELSE ''false'' END as p_has_season_ticket, 
CASE WHEN ps.p_driver_license = 1 THEN ''true'' ELSE ''false'' END as p_has_licence, ' ||
-- Household attributes from $region_households hs
'hs.hh_id, 
hs.hh_persons as hh_members,
CASE WHEN hs.hh_has_child THEN ''true'' ELSE ''false'' END as hh_has_child, 
hs.hh_cars, 
hs.hh_income, ' ||
-- Plan attributes from trip table $tablename ts
'ts.scheme_id, 
ts.score_combined, 
ts.score_finance, 
ts.score_time, ' ||
-- Location attributes for departure
'ts.taz_id_start, 
ts.block_id_start, 
ts.loc_id_start, 
CASE WHEN lss.loc_coordinate IS NULL THEN X(hs.hh_coordinate) ELSE X(lss.loc_coordinate) END as loc_coord_x_start, 
CASE WHEN lss.loc_coordinate IS NULL THEN Y(hs.hh_coordinate) ELSE Y(lss.loc_coordinate) END as loc_coord_y_start, 
tss.taz_bbr_type as taz_bbr_type_start, 
CASE WHEN ts.taz_has_toll_start THEN ''true'' ELSE ''false'' END as taz_has_toll_start, ' ||
-- Location attributes for arrival
'ts.taz_id_end, 
ts.block_id_end, 
ts.loc_id_end,
CASE WHEN lse.loc_coordinate IS NULL THEN X(hs.hh_coordinate) ELSE X(lse.loc_coordinate) END as loc_coord_x_end, 
CASE WHEN lse.loc_coordinate IS NULL THEN Y(hs.hh_coordinate) ELSE Y(lse.loc_coordinate) END as loc_coord_y_end, 
tse.taz_bbr_type as taz_bbr_type_end, 
CASE WHEN ts.taz_has_toll_end THEN ''true'' ELSE ''false'' END as taz_has_toll_end,  ' ||
-- Additional trip attributes
'ts.start_time_min, 
ts.travel_time_sec, 
ts.mode, 
-1 as car_type, 
ts.distance_bl_m, 
ts.distance_real_m, 
ts.activity, 
CASE WHEN ts.is_home THEN ''true'' ELSE ''false'' END as is_home,
ts.activity_start_min,
ts.activity_duration_min,
ts.emission_type,
CASE WHEN ts.is_restricted THEN ''true'' ELSE ''false'' END as is_restricted ' ||
-- FROM CLAUSE WITH JOINS
'FROM ' || table_trips || ' ts ' ||
-- inner joins for person and household tables: notice the ON clause with the p_hh_key because of the compound primary keys and the additional where clause
'INNER      JOIN ' || schemaname ||  region || '_persons ps    ON ts.p_id  = ps.p_id  AND ''' || p_hh_key || ''' = ps.p_key ' ||
'INNER      JOIN ' || schemaname ||  region || '_households hs ON ts.hh_id = hs.hh_id AND ''' || p_hh_key || ''' = hs.hh_key ' ||
-- left outer joins for the location tables: this joins is needed, because the households don't have a location in the location table
-- Therefore the coordinate is null in lines where the trip starts or ends at home. Normally these lines are deleted, but with a left outer join
-- they are just filled with null values. These values leads to the CASE clause for the coordinates above
'LEFT OUTER JOIN ' || schemaname ||  region || '_locations lss ON ts.loc_id_start = lss.loc_id ' ||
'LEFT OUTER JOIN ' || schemaname ||  region || '_locations lse ON ts.loc_id_end   = lse.loc_id ' ||
-- inner joins for the taz attributes
'INNER      JOIN ' || schemaname ||  region || '_taz tss       ON ts.taz_id_start = tss.taz_id ' ||
'INNER      JOIN ' || schemaname ||  region || '_taz tse       ON ts.taz_id_end   = tse.taz_id ' ||
-- WHERE CLAUSE
-- This clause is needed because the primary key of a person consits of three parts. Two of them are already checked in the inner join's on clause and here the last
'WHERE hs.hh_id = ps.p_hh_id  AND hs.hh_id =' ||hh_id|| ' AND ps.p_id = '||p_id||' '|| 
-- ORDER CLAUSE
'ORDER BY hs.hh_id, ps.p_id, ts.start_time_min';
	-- RAISE NOTICE 'return (%)',command;

RETURN QUERY EXECUTE command;
--funny he? The above line does not actually return from this function but appends the result to the returning set. A final return ends this function!
RETURN;
end;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION core.mobility_calculator_function_get(	hh_id integer, p_id integer)
  OWNER TO %DBUSER%;
			

-- Function: core.mobility_calculator_scheme_class_distribution(integer, integer)

-- DROP FUNCTION core.mobility_calculator_scheme_class_distribution(integer, integer);

-- DROP type scheme_class_distribution CASCADE;

--create type scheme_class_distribution as (	sc_probability double precision, diaries_in_sc integer
--);


CREATE OR REPLACE FUNCTION core.mobility_calculator_scheme_class_distribution(pg_id integer, sc_id integer)
  RETURNS SETOF public.scheme_class_distribution AS
$BODY$
DECLARE	command TEXT;
DECLARE scheme_class_name TEXT;
DECLARE table_key TEXT;
begin
	--get the table key
	command = 'SELECT sim_key FROM simulation_parameters where param_key = ''DB_HOUSEHOLD_AND_PERSON_KEY'' and param_value = ''ONE_HOUSEHOLD_Y2008'' ORDER BY sim_key LIMIT 1';
	--RAISE NOTICE 'return (%)',command;
	EXECUTE command INTO table_key;
	
	command = 'SELECT param_value FROM simulation_parameters WHERE param_key = ''DB_NAME_SCHEME_CLASS_DISTRIBUTION'' and sim_key = '''||table_key||'''';
	--RAISE NOTICE 'return (%)',command;
	EXECUTE command INTO scheme_class_name;	
	
	command ='SELECT sc.probability as sc_probability , count(s.scheme_id)::integer as diaries_in_sc 
							FROM core.global_schemes as s 
									JOIN core.global_scheme_class_distributions as sc ON sc.scheme_class_id=s.scheme_class_id 
							 WHERE sc.name = '''||scheme_class_name||''' AND sc.person_group='||pg_id||' and sc.scheme_class_id= (SELECT foo.scheme_class_id FROM core.global_schemes as foo WHERE foo.scheme_id='||sc_id||') GROUP BY sc.probability';
	--RAISE NOTICE 'return (%)',command;
	RETURN QUERY EXECUTE command;
	--funny he? The above line does not actually return from this function but appends the result to the returning set. A final return ends this function!
RETURN;
end;
$BODY$
  LANGUAGE plpgsql VOLATILE
  ROWS 1000
  COST 100;
ALTER FUNCTION core.mobility_calculator_scheme_class_distribution(integer, integer)
  OWNER TO %DBUSER%;



-- Function: core.mobility_calculator_person_group_statistic(integer)

-- DROP FUNCTION core.mobility_calculator_person_group_statistic(integer, text,text);

-- DROP type person_group_data CASCADE;

-- create type person_group_data as (	mode integer, pg_count integer, total_count bigint, num_trips integer, total_length double precision, total_duration bigint, mid_count bigint);


CREATE OR REPLACE FUNCTION core.mobility_calculator_person_group_statistic(pg_id integer, simulation text, region text)
  RETURNS SETOF public.person_group_data AS
$BODY$
DECLARE	command TEXT;
--DECLARE region TEXT;
--DECLARE table_key TEXT;
begin
	--get the table key
	--command = 'SELECT sim_key FROM simulation_parameters where param_key = ''DB_HOUSEHOLD_AND_PERSON_KEY'' and param_value = ''MID2008_Y2008'' ORDER BY sim_key LIMIT 1';
	--RAISE NOTICE 'return (%)',command;
	--EXECUTE command INTO table_key;
	
	--command = 'SELECT param_value FROM simulation_parameters WHERE param_key = ''DB_REGION'' and sim_key = '''||table_key||'''';
	--RAISE NOTICE 'return (%)',command;
	--EXECUTE command INTO region;	
	
	command ='SELECT cr_mode as mode, cr_p_group_count as pg_count, cr_whole_population as total_count, cr_num_trips as num_trips, cr_average_length as total_length, cr_average_duration as total_duration, mid_count as mid_count
							FROM mobility_calculator_results 
									
							WHERE cr_key = '''||simulation||''' AND cr_p_group='||pg_id||' and cr_region = '''||region||'''';
	--RAISE NOTICE 'return (%)',command;
	RETURN QUERY EXECUTE command;
	--funny he? The above line does not actually return from this function but appends the result to the returning set. A final return ends this function!
RETURN;
end;
$BODY$
  LANGUAGE plpgsql VOLATILE
  ROWS 1000
  COST 100;
ALTER FUNCTION core.mobility_calculator_person_group_statistic(integer, text, text)
  OWNER TO %DBUSER%;
