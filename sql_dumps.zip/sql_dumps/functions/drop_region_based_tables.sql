-- Function: core.drop_region_based_tables(character varying, character varying)

-- DROP FUNCTION core.drop_region_based_tables(character varying, character varying);

CREATE OR REPLACE FUNCTION core.drop_region_based_tables(region character varying, schemaname character varying)
  RETURNS boolean AS
$BODY$DECLARE tablename character varying;

BEGIN

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- PERSONS
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_persons';
IF core.exist_table(schemaname, tablename) IS TRUE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'DROP TABLE ' || schemaname || '.' || tablename;
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- HOUSEHOLDS
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_households';
IF core.exist_table(schemaname, tablename) IS TRUE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'DROP TABLE ' || schemaname || '.' || tablename;
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- ACT 2 LOC CODES
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_act_2_loc_code';
IF core.exist_table(schemaname, tablename) IS TRUE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'DROP TABLE ' || schemaname || '.' || tablename;
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- CFN4 Ind
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_cfn4_ind';
IF core.exist_table(schemaname, tablename) IS TRUE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'DROP TABLE ' || schemaname || '.' || tablename;
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- CFN4
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_cfn4';
IF core.exist_table(schemaname, tablename) IS TRUE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'DROP TABLE ' || schemaname || '.' || tablename;
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- MATRICES
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_matrices';
IF core.exist_table(schemaname, tablename) IS TRUE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'DROP TABLE ' || schemaname || '.' || tablename;
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- LOC
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_locations';
IF core.exist_table(schemaname, tablename) IS TRUE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'DROP TABLE ' || schemaname || '.' || tablename;
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- BLK NEXT PT STOP
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_block_next_pt_stop';
IF core.exist_table(schemaname, tablename) IS TRUE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'DROP TABLE ' || schemaname || '.' || tablename;
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- BLK SCORES
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_block_scores';
IF core.exist_table(schemaname, tablename) IS TRUE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'DROP TABLE ' || schemaname || '.' || tablename;
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- BLK
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_blocks';
IF core.exist_table(schemaname, tablename) IS TRUE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'DROP TABLE ' || schemaname || '.' || tablename;
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- TAZ SCORES
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_taz_scores';
IF core.exist_table(schemaname, tablename) IS TRUE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'DROP TABLE ' || schemaname || '.' || tablename;
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- TAZ FEES AND TOLLS
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_taz_fees_tolls';
IF core.exist_table(schemaname, tablename) IS TRUE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'DROP TABLE ' || schemaname || '.' || tablename;
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- TAZ INFOS MIT
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_taz_intra_mit_infos';
IF core.exist_table(schemaname, tablename) IS TRUE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'DROP TABLE ' || schemaname || '.' || tablename;
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- TAZ INFOS PT
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_taz_intra_pt_infos';
IF core.exist_table(schemaname, tablename) IS TRUE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'DROP TABLE ' || schemaname || '.' || tablename;
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- TAZ
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_taz';
IF core.exist_table(schemaname, tablename) IS TRUE THEN
--
-- DROP TABLE
--
EXECUTE 'DROP TABLE ' || schemaname || '.' || tablename;
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- END
--
RETURN TRUE;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.drop_region_based_tables(character varying, character varying) OWNER TO %DBUSER%;
