-- Function: core.finish_hh(character varying, integer)

-- DROP FUNCTION core.finish_hh(character varying, integer);

CREATE OR REPLACE FUNCTION core.finish_hh(temp_table_hh character varying, sim character varying, hh_id integer)
  RETURNS boolean AS
$BODY$
declare update_count integer;
DECLARE finished boolean;
DECLARE command character varying;
BEGIN
--EXECUTE 'LOCK TABLE ' || temp_table_hh || ' IN EXCLUSIVE MODE';

EXECUTE 'UPDATE ' || temp_table_hh || ' SET hh_finished = true WHERE hh_started and not hh_finished AND hh_id = ' || hh_id;
command = 'SELECT count(*) FROM ' || temp_table_hh || ' WHERE hh_finished';

EXECUTE command into update_count;

--GET DIAGNOSTICS update_count = ROW_COUNT;
--raise notice '% updated %', sim, update_count;
UPDATE simulations SET sim_progress = update_count WHERE sim_key = sim;
command = 'SELECT sim_progress = sim_total FROM simulations WHERE sim_key = '''||sim||'''';
EXECUTE command INTO finished;
IF (finished = TRUE) THEN
	UPDATE simulations SET sim_finished = true, timestamp_finished = now() WHERE sim_key = sim;
END IF;
	
RETURN TRUE;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.finish_hh(character varying,character varying, integer) OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.finish_hh(character varying,character varying, integer) TO public;
GRANT EXECUTE ON FUNCTION core.finish_hh(character varying,character varying, integer) TO tapas_user_group;


-- Function: core.finish_hh(character varying, character varying)
--DROP FUNCTION core.finish_hh(character varying, character varying);

CREATE OR REPLACE FUNCTION core.finish_hh(temp_table_hh character varying, sim character varying, server_ip inet)
  RETURNS boolean AS
$BODY$
declare update_count integer;
DECLARE finished boolean;
DECLARE command character varying; 
BEGIN
--EXECUTE 'LOCK TABLE ' || temp_table_hh || ' IN EXCLUSIVE MODE';

EXECUTE 'UPDATE ' || temp_table_hh || ' SET hh_finished = true WHERE hh_started and not hh_finished AND server_ip = ''' || server_ip || '''';
command = 'SELECT count(*) FROM ' || temp_table_hh || ' WHERE hh_finished';

EXECUTE command into update_count;

--GET DIAGNOSTICS update_count = ROW_COUNT;
--raise notice '% updated %', sim, update_count;
UPDATE simulations SET sim_progress = update_count WHERE sim_key = sim;
command = 'SELECT sim_progress = sim_total FROM simulations WHERE sim_key = '''||sim||'''';
EXECUTE command INTO finished;
IF (finished = TRUE) THEN
	UPDATE simulations SET sim_finished = true, timestamp_finished = now() WHERE sim_key = sim;
END IF;


--GET DIAGNOSTICS update_count = ROW_COUNT;
--raise notice '% updated %', sim,update_count;
--UPDATE simulations SET sim_progress = sim_progress + update_count WHERE sim_key = sim;
--FOR finished IN SELECT sim_progress = sim_total FROM simulations WHERE sim_key = sim LOOP END LOOP;
--IF (finished = TRUE) THEN
--	UPDATE simulations SET sim_finished = true, timestamp_finished = now() WHERE sim_key = sim;
--END IF;


RETURN TRUE;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.finish_hh(character varying, character varying,inet) OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.finish_hh(character varying,character varying, inet) TO public;
GRANT EXECUTE ON FUNCTION core.finish_hh(character varying,character varying, inet) TO tapas_user_group;

