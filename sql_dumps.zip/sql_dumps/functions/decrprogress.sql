-- Function: core.decrprogress(character varying, integer)

-- DROP FUNCTION core.decrprogress(character varying, integer);

CREATE OR REPLACE FUNCTION core.decrprogress(key character varying, count integer)
  RETURNS boolean AS
$BODY$
declare
	command TEXT;
begin
	command = 'UPDATE  public.simulations 
	SET sim_progress = sim_progress - ' || count || ', sim_started = FALSE, sim_finished = FALSE
		WHERE sim_key = ' || quote_literal(key) ;	
	EXECUTE command;
RETURN true;
end;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION core.decrprogress(character varying, integer) OWNER TO %DBUSER%;
