-- Function: core.move_indices(character varying)

-- DROP FUNCTION core.move_indices(character varying);

CREATE OR REPLACE FUNCTION core.move_indices(schemaname character varying)
  RETURNS boolean AS
$BODY$DECLARE command TEXT;
DECLARE rec TEXT;

BEGIN

command = 'SELECT 
	  ''ALTER INDEX "'' || schemaname || ''"."'' || indexname || ''" SET TABLESPACE index;'' 
	  FROM pg_indexes WHERE schemaname = ''' || schemaname || '''';

FOR rec IN EXECUTE command LOOP
	EXECUTE rec;
END LOOP;

RETURN TRUE;

END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.move_indices(character varying) OWNER TO %DBUSER%;
