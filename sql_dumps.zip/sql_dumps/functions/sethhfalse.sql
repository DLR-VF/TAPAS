-- Function: core.sethhfalse(character varying, character varying)

-- DROP FUNCTION core.sethhfalse(character varying, character varying);

CREATE OR REPLACE FUNCTION core.sethhfalse(the_table character varying, hh_id character varying)
  RETURNS integer AS
$BODY$
declare
	command TEXT;
	returnVal integer;
begin
	returnVal =0;
	--command = 'LOCK TABLE ' || the_table || ' IN EXCLUSIVE MODE';
	--EXECUTE command; 
	command = 'UPDATE  ' || the_table || ' 
	SET hh_started = FALSE, hh_finished = FALSE, server_ip = null
		WHERE hh_id = ANY (' || hh_id || ')' ;
	EXECUTE command;
	
	IF FOUND THEN
    GET DIAGNOSTICS returnVal = ROW_COUNT;
	END IF;

RETURN returnVal;
end;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION core.sethhfalse(character varying, character varying)
  OWNER TO %DBUSER%;
