-- Function: core.getlocidsfromperson_trip(character varying, character varying)

-- DROP FUNCTION core.getlocidsfromperson_trip(character varying, character varying);

CREATE OR REPLACE FUNCTION core.getlocidsfromperson_trip(the_table character varying, the_id character varying)
  RETURNS SETOF integer AS
$BODY$
declare
	res record;
	command TEXT;
begin
	--command = 'LOCK TABLE ' || the_table || ' IN EXCLUSIVE MODE';
	--EXECUTE command; 
	command = 'SELECT loc_id_end FROM ' || the_table || ' 
		WHERE p_id = ANY(' || the_id || ')' ;
	FOR res IN EXECUTE command LOOP

		return next res.loc_id_end;
	end loop;
end;
$BODY$
  LANGUAGE plpgsql VOLATILE
  ROWS 1000
  COST 100;
ALTER FUNCTION core.getlocidsfromperson_trip(character varying, character varying)
  OWNER TO %DBUSER%;
