-- Function: core.get_progress(character varying)

-- DROP FUNCTION core.get_progress(character varying);

CREATE OR REPLACE FUNCTION core.get_progress(temp_hh_table character varying)
  RETURNS double precision AS
$BODY$DECLARE progress double precision;
BEGIN
FOR progress IN EXECUTE 'SELECT CAST(count(*) AS double precision)/(SELECT count(*) FROM ' || temp_hh_table || ') FROM ' || temp_hh_table || ' WHERE finished = true' LOOP END LOOP;
RETURN progress;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.get_progress(character varying) OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.get_progress(character varying) TO public;

