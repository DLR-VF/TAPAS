-- Function: core.create_car(num_persons integer, num_cars integer, hh_income double precision)

-- DROP FUNCTION core.create_car(num_persons integer, num_cars integer, hh_income double precision);

CREATE OR REPLACE FUNCTION core.create_car( 
	num_persons integer, 
	num_cars integer, 
	hh_income double precision)
  RETURNS SETOF RECORD AS
$BODY$
DECLARE query text;
DECLARE incomeClass integer;
DECLARE rec RECORD;
BEGIN

IF    hh_income< 500 THEN incomeClass= 1;
ELSIF hh_income< 900 THEN incomeClass= 2;
ELSIF hh_income<1500 THEN incomeClass= 3;
ELSIF hh_income<2000 THEN incomeClass= 4;
ELSIF hh_income<2600 THEN incomeClass= 5;
ELSIF hh_income<3000 THEN incomeClass= 6;
ELSIF hh_income<3600 THEN incomeClass= 7;
ELSIF hh_income<4000 THEN incomeClass= 8;
ELSIF hh_income<4600 THEN incomeClass= 9;
ELSIF hh_income<5000 THEN incomeClass=10;
ELSIF hh_income<5600 THEN incomeClass=11;
ELSIF hh_income<6000 THEN incomeClass=12;
ELSIF hh_income<6600 THEN incomeClass=13;
ELSIF hh_income<7000 THEN incomeClass=14;
ELSE                      incomeClass=15;
END IF;

query = 'SELECT m.seg_kba AS kba, m.h048-1 AS diesel, m.kw, m.h0412 AS baujahr, greatest(0,6-round((2015-h0412)/4.4::float)::integer) AS abgasnorm, (m.h046!=1)::integer AS dienstwagen 
				FROM core.global_mid_cars m WHERE m.hhid = (SELECT hhid FROM (SELECT DISTINCT hhid,random() FROM core.global_mid_cars WHERE
					h0412<=2008 
					AND h02='||num_persons||'
					AND h04_3='||num_cars||'
					AND hheink='||incomeClass||'
				ORDER BY random LIMIT 1) foo)';
FOR rec IN EXECUTE query LOOP
  RETURN NEXT rec;
END LOOP;

RETURN;
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION core.create_car(integer, integer, double precision)
  OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.create_car(integer, integer, double precision) TO tapas_user_group;






---- 1. Teil: Nur einmalig auszuführen
--
--drop table if exists core.global_mid_cars_reduced;
--create table core.global_mid_cars_reduced as (
--select hhid,vmid,a_gew,hheink,seg_kba as kba,kw,h048-1 as diesel,h02 as anzpers,h04_3 as anzautos,h0412 as
--baujahr,greatest(0,6-round((2015-h0412)/4.4::float)::integer) as
--abgasnorm,(h046!=1)::integer as dienstwagen,0::integer as hheink2 from core.global_mid_cars
--);
--
--ALTER TABLE core.global_mid_cars_reduced ADD CONSTRAINT global_mid_cars_reduced_pkey PRIMARY KEY (hhid,vmid);
--
--
--
--
---- Index: core.global_mid_cars_reduced_anzpers
--
---- DROP INDEX core.global_mid_cars_reduced_anzpers;
--
--CREATE INDEX global_mid_cars_reduced_anzpers
--  ON core.global_mid_cars_reduced
--  USING btree
--  (anzpers )
--;
--
---- Index: core.global_mid_cars_reduced_baujahr
--
---- DROP INDEX core.global_mid_cars_reduced_baujahr;
--
--CREATE INDEX global_mid_cars_reduced_baujahr
--  ON core.global_mid_cars_reduced
--  USING btree
--  (baujahr )
--;
--
---- Index: core.global_mid_cars_reduced_anzautos
--
---- DROP INDEX core.global_mid_cars_reduced_anzautos;
--
--CREATE INDEX global_mid_cars_reduced_anzautos
--  ON core.global_mid_cars_reduced
--  USING btree
--  (anzautos )
--;
--
---- Index: core.global_mid_cars_reduced_hheink
--
---- DROP INDEX core.global_mid_cars_reduced_hheink;
--
--CREATE INDEX global_mid_cars_reduced_hheink
--  ON core.global_mid_cars_reduced
--  USING btree
--  (hheink )
--;
--
---- Index: core.global_mid_cars_reduced_hhid
--
---- DROP INDEX core.global_mid_cars_reduced_hhid;
--
--CREATE INDEX global_mid_cars_reduced_hhid
--  ON core.global_mid_cars_reduced
--  USING btree
--  (hhid )
--;
--
--
--
--
--
--delete from core.global_mid_cars_reduced where hhid in (
--select hhid from core.global_mid_cars_reduced where
--hheink>15
--or kba>11
--or kw>368
--or baujahr>2009
--or diesel>1
--);
--
--update core.global_mid_cars_reduced set hheink2=250 where hheink=1;
--update core.global_mid_cars_reduced set hheink2=700 where hheink=2;
--update core.global_mid_cars_reduced set hheink2=1200 where hheink=3;
--update core.global_mid_cars_reduced set hheink2=1750 where hheink=4;
--update core.global_mid_cars_reduced set hheink2=2300+(hheink-5)*500 where hheink>=5 and hheink <=14;
--update core.global_mid_cars_reduced set hheink2=7100 where hheink=15;