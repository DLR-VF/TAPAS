-- Function: core.export_trip_table(character varying, character varying, character varying, character varying, character varying, character varying)

-- DROP FUNCTION core.export_trip_table(character varying, character varying, character varying, character varying, character varying, character varying);

CREATE OR REPLACE FUNCTION core.export_trip_table(tablename character varying, schemaname character varying, region character varying, identifier character varying, p_hh_key character varying, filename character varying)
  RETURNS boolean AS
$BODY$
DECLARE command text;
DECLARE table_persons text;
DECLARE table_household text;
DECLARE table_locations text;
DECLARE table_taz text;

BEGIN

	--first load all infos from the parameter table
command = 'SELECT param_value FROM simulation_parameters WHERE param_key = ''DB_SCHEMA_CORE'' and sim_key = '''||identifier||'''';
EXECUTE command INTO schemaname;
command = 'SELECT param_value FROM simulation_parameters WHERE param_key = ''DB_REGION'' and sim_key = '''||identifier||'''';
EXECUTE command INTO region;
command = 'SELECT param_value FROM simulation_parameters WHERE param_key = ''DB_TABLE_TRIPS'' and sim_key = '''||identifier||'''';
EXECUTE command INTO tablename;
tablename = tablename||'_'||identifier;
command = 'SELECT param_value FROM simulation_parameters WHERE param_key = ''DB_TABLE_HOUSEHOLD'' and sim_key = '''||identifier||'''';
EXECUTE command INTO table_household;
table_household = schemaname||table_household;
command = 'SELECT param_value FROM simulation_parameters WHERE param_key = ''DB_TABLE_LOCATION'' and sim_key = '''||identifier||'''';
EXECUTE command INTO table_locations;
table_locations = schemaname||table_locations;
command = 'SELECT param_value FROM simulation_parameters WHERE param_key = ''DB_TABLE_PERSON'' and sim_key = '''||identifier||'''';
EXECUTE command INTO table_persons;
table_persons = schemaname||table_persons;
command = 'SELECT param_value FROM simulation_parameters WHERE param_key = ''DB_HOUSEHOLD_AND_PERSON_KEY'' and sim_key = '''||identifier||'''';
EXECUTE command INTO p_hh_key;
command = 'SELECT param_value FROM simulation_parameters WHERE param_key = ''DB_TABLE_TAZ'' and sim_key = '''||identifier||'''';
EXECUTE command INTO table_taz;
table_taz = schemaname||table_taz;

	
	
	
	
	
	
command = '
SELECT ' ||
-- Person attributes from $region_persons ps
'ps.p_id, 
ps.p_group, 
ps.p_age_stba as p_age_category, 
ps.p_age,
ps.p_sex, 
CASE WHEN ps.p_abo = 1 THEN ''true'' ELSE ''false'' END as p_has_season_ticket, 
CASE WHEN ps.p_driver_license = 1 THEN ''true'' ELSE ''false'' END as p_has_licence, ' ||
-- Household attributes from $region_households hs
'hs.hh_id, 
hs.hh_persons as hh_members,
CASE WHEN hs.hh_has_child THEN ''true'' ELSE ''false'' END as hh_has_child, 
hs.hh_cars, 
hs.hh_income, ' ||
-- Plan attributes from trip table $tablename ts
'ts.scheme_id, 
ts.score_combined, 
ts.score_finance, 
ts.score_time, ' ||
-- Location attributes for departure
'ts.taz_id_start, 
ts.block_id_start, 
ts.loc_id_start, 
CASE WHEN lss.loc_coordinate IS NULL THEN ST_X(hs.hh_coordinate) ELSE ST_X(lss
.loc_coordinate) END as loc_coord_x_start,
CASE WHEN lss.loc_coordinate IS NULL THEN ST_Y(hs.hh_coordinate) ELSE ST_Y(lss
.loc_coordinate) END as loc_coord_y_start,
tss.taz_bbr_type as taz_bbr_type_start, 
CASE WHEN ts.taz_has_toll_start THEN ''true'' ELSE ''false'' END as taz_has_toll_start, ' ||
-- Location attributes for arrival
'ts.taz_id_end, 
ts.block_id_end, 
ts.loc_id_end,
CASE WHEN lse.loc_coordinate IS NULL THEN ST_X(hs.hh_coordinate) ELSE ST_X(lse.loc_coordinate) END as loc_coord_x_end,
CASE WHEN lse.loc_coordinate IS NULL THEN ST_Y(hs.hh_coordinate) ELSE ST_Y(lse.loc_coordinate) END as loc_coord_y_end,
tse.taz_bbr_type as taz_bbr_type_end, 
CASE WHEN ts.taz_has_toll_end THEN ''true'' ELSE ''false'' END as taz_has_toll_end,  ' ||
-- Additional trip attributes
'ts.start_time_min, 
ts.travel_time_sec, 
ts.mode, 
-1 as car_type, 
ts.distance_bl_m, 
ts.distance_real_m, 
ts.activity, 
CASE WHEN ts.is_home THEN ''true'' ELSE ''false'' END as is_home,
ts.activity_start_min,
ts.activity_duration_min,
ts.emission_type,
CASE WHEN ts.is_restricted THEN ''true'' ELSE ''false'' END as is_restricted ' ||
-- FROM CLAUSE WITH JOINS
'FROM ' || tablename || ' ts ' ||
-- inner joins for person and household tables: notice the ON clause with the p_hh_key because of the compound primary keys and the additional where clause
'INNER      JOIN ' || table_persons || ' ps    ON ts.p_id  = ps.p_id  AND ''' || p_hh_key || ''' = ps.p_key ' ||
'INNER      JOIN ' || table_household || ' hs ON ts.hh_id = hs.hh_id AND ''' || p_hh_key || ''' = hs.hh_key ' ||
-- left outer joins for the location tables: this joins is needed, because the households don't have a location in the location table
-- Therefore the coordinate is null in lines where the trip starts or ends at home. Normally these lines are deleted, but with a left outer join
-- they are just filled with null values. These values leads to the CASE clause for the coordinates above
'LEFT OUTER JOIN ' || table_locations || ' lss ON ts.loc_id_start = lss.loc_id ' ||
'LEFT OUTER JOIN ' || table_locations || ' lse ON ts.loc_id_end   = lse.loc_id ' ||
-- inner joins for the taz attributes
'INNER      JOIN ' || table_taz || ' tss       ON ts.taz_id_start = tss.taz_id ' ||
'INNER      JOIN ' || table_taz || ' tse       ON ts.taz_id_end   = tse.taz_id ' ||
-- WHERE CLAUSE
-- This clause is needed because the primary key of a person consits of three parts. Two of them are already checked in the inner join's on clause and here the last
'WHERE hs.hh_id = ps.p_hh_id ' || 
-- ORDER CLAUSE
'ORDER BY hs.hh_id, ps.p_id, ts.start_time_min';

EXECUTE 'COPY (' || command || ') TO ''' || filename || ''' WITH CSV HEADER';

RETURN TRUE;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;




-- Function: core.export_trip_table(character varying, character varying)

-- DROP FUNCTION core.export_trip_table(character varying, character varying);

CREATE OR REPLACE FUNCTION core.export_trip_table(tablename character varying, filename character varying)
  RETURNS boolean AS
$BODY$
DECLARE simkey character varying;
DECLARE simregion character varying;
DECLARE sim_p_hh_key character varying;
DECLARE simpar character varying[];
BEGIN
simkey = split_part(tablename, 'trips_', 2);
SELECT param_value INTO simregion FROM simulations where sim_key = simkey and param_key = 'DB_REGION';
SELECT param_value INTO sim_p_hh_key FROM simulations where sim_key = simkey and param_key = 'DB_HOUSEHOLD_AND_PERSON_KEY';
RETURN core.export_trip_table(tablename, 'core', simregion, simkey, sim_p_hh_key, filename);
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;

