-- Function: core.load_scheme_class_distributions(character varying, character varying)

-- DROP FUNCTION core.load_scheme_class_distributions(character varying, character varying);

CREATE OR REPLACE FUNCTION core.load_scheme_class_distributions(file_scheme_class_distributions character varying, name_scheme_class_distributions character varying)
  RETURNS boolean AS
$BODY$DECLARE bool boolean;
DECLARE line text;
DECLARE text_array text[];
DECLARE header_array text[];
DECLARE i integer;

BEGIN

--create temporary table
CREATE TEMPORARY TABLE scd_temp (i_line text);

--fill temp table
EXECUTE 'COPY scd_temp FROM ''' || file_scheme_class_distributions || '''';

EXECUTE 'SELECT core.delete_rows(''core.global_scheme_class_distributions'',''name'',''' || name_scheme_class_distributions || ''',0)';

bool = true;
FOR line IN EXECUTE 'SELECT * FROM scd_temp' LOOP
	IF bool THEN
		bool = false;
		header_array = string_to_array(line, ',');
	ELSE
		text_array =  string_to_array(line, ',');
		FOR i IN 2 .. array_upper(text_array, 1) LOOP
			EXECUTE 'INSERT INTO core.global_scheme_class_distributions VALUES (
					''' || name_scheme_class_distributions || ''', 
					CAST(' || header_array[i]|| ' AS integer),
					CAST(' || text_array[1] || ' AS integer),
					CAST(' || text_array[i] ||' AS double precision))';
		END LOOP;
	END IF;
END LOOP;

DROP TABLE scd_temp;

RETURN TRUE;

END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.load_scheme_class_distributions(character varying, character varying) OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.load_scheme_class_distributions(character varying, character varying) TO public;

