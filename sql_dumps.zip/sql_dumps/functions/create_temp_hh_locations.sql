-- Function: core.create_temp_hh_locations(character varying, character varying, character varying)

-- DROP FUNCTION core.create_temp_hh_locations(character varying, character varying, character varying);

CREATE OR REPLACE FUNCTION core.create_temp_hh_locations(temp_table_loc character varying, temp_table_hh character varying, table_hh character varying)
  RETURNS boolean AS
$BODY$BEGIN
--Insert all households into temporary location table
EXECUTE 'INSERT INTO ' || temp_table_loc || ' (
		SELECT 	-1*hh.hh_id, 
			-1,
			hh.hh_taz_id,
			(SELECT code_tapas FROM core.locationcodes WHERE id = 1), 
			''home'', 
			0, 
			true, 
			hh.hh_coordinate, 
			0, 
			0, 
			0 
		FROM ' || temp_table_hh || ' hht, ' || table_hh || ' hh 
		WHERE hht.hh_id = hh.hh_id AND hht.hh_key = hh.hh_key
	)';
RETURN true;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.create_temp_hh_locations(character varying, character varying, character varying) OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.create_temp_hh_locations(character varying, character varying, character varying) TO public;

COMMENT ON FUNCTION core.create_temp_hh_locations(character varying, character varying, character varying) IS 'This method adds all households to the location table with the households negative id, the location code for at home and a fix capacity of zero.';
