-- Function: core.resetBrokenJobs(text)

-- DROP FUNCTION core.resetBrokenJobs(text);

CREATE OR REPLACE FUNCTION core.resetBrokenJobs(sim text)
  RETURNS integer AS
$BODY$
DECLARE command TEXT;
DECLARE sim_region character varying;
DECLARE rec RECORD;
DECLARE rowsUpdated integer;
DECLARE currCount integer;
BEGIN


--fetch the sim region
select param_value into sim_region from public.simulation_parameters where sim_key = sim and param_key = 'DB_REGION';

currCount = 0;
--  fetch unfinished hhs
command = 'SELECT hh_id FROM temp.households_' || sim || ' WHERE hh_started = true AND hh_finished = false AND server_ip = ANY(SELECT server_ip FROM SERVERS WHERE server_online = false) ORDER BY hh_id ';
FOR rec IN EXECUTE command LOOP
  --reset unfinished hh
	command = 'UPDATE temp.households_' || sim || ' SET hh_started = false, hh_finished = false, server_ip = NULL WHERE hh_id = ' || rec.hh_id;
	EXECUTE command;
	GET DIAGNOSTICS rowsUpdated = ROW_COUNT;
	currCount = currCount +rowsUpdated;
	-- remove trips for the unfinished hhs
	command = 'DELETE FROM ' || sim_region || '_trips_' || sim ||' WHERE hh_id = ' || rec.hh_id;
	EXECUTE command;
END LOOP;

RETURN currCount;


END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.resetBrokenJobs(text) OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.resetBrokenJobs(text) TO public;
GRANT EXECUTE ON FUNCTION core.resetBrokenJobs(text) TO tapas_user_group;
