-- Function: core.create_hh_sample(character varying, character varying, character varying, character varying, double precision, double precision)

-- DROP FUNCTION core.create_hh_sample(character varying, character varying, character varying, character varying, double precision, double precision);

CREATE OR REPLACE FUNCTION core.create_hh_sample(
    src_hh_table character varying,
    dst_hh_table character varying,
    p_table character varying,
    hh_key character varying,
    seed double precision,
    sample double precision)
  RETURNS void AS
$BODY$
--DECLARE taz_id integer;
--DECLARE phh integer;
--DECLARE count integer;
DECLARE id integer;
DECLARE command character varying;
DECLARE rec RECORD;
DECLARE contains boolean;
DECLARE sum_array bigint[];
DECLARE pkey CHARACTER VARYING;
BEGIN
/*
 * First opportunity to create a sample -> VERY SLOW:
 * You shuffle all households and store them in a temporary table. Then you iterate over the traffic analysis zones and the household
 * sizes and draw the sample size out of this portion.
 *
 * EXECUTE 'CREATE TEMPORARY TABLE create_hh_sample_temp_table (id integer, phh integer, taz_id integer)';
 * EXECUTE 'INSERT INTO create_hh_sample_temp_table (
 * 		SELECT id, phh, taz_id FROM ' || tablename || ' WHERE years=' || years || ' ORDER BY random())';
 * command = 'SELECT DISTINCT taz_id FROM create_hh_sample_temp_table LIMIT 3;';
 * FOR taz_id IN EXECUTE command LOOP
 *	command = 'SELECT DISTINCT phh FROM create_hh_sample_temp_table WHERE taz_id=' || taz_id;
 *	FOR phh IN EXECUTE command LOOP
 *		command = 'SELECT count(id) FROM create_hh_sample_temp_table WHERE phh=' || phh || ' AND taz_id=' || taz_id;
 *		FOR count IN EXECUTE command LOOP END LOOP;
 *		count = CAST(count * sample / 100 AS integer);
 *		command = 'SELECT id FROM create_hh_sample_temp_table WHERE phh=' || phh || ' AND taz_id=' || taz_id || ' LIMIT ' || count;
 *		FOR id IN EXECUTE command LOOP RETURN NEXT id; END LOOP;
 *	END LOOP;
 * END LOOP;
 * TRUNCATE TABLE create_hh_sample_temp_table;
 * DROP TABLE create_hh_sample_temp_table;
 */

/*
 * Second opportunity to create a sample:
 * To make the method deterministic you can set the seed value for the pseudo random numbers. Then you create the temporary table for the 
 * household sample. Then you have a three times nested sql statement. First of all you group the traffic analysis zones ids and the amount of 
 * persons in a household. With this subtable you select the sample households and finally add them into the temporary table.
 */
IF seed > 0 THEN
	PERFORM setseed(seed);
END IF;

pkey = split_part(dst_hh_table, '.', 2);
EXECUTE 'CREATE TABLE ' || dst_hh_table || ' (
	hh_id integer,  	
	prio integer,
	hh_started boolean DEFAULT false, 
	hh_finished boolean DEFAULT false, 
	server_ip inet DEFAULT null, 	
	CONSTRAINT ' || pkey || '_pkey PRIMARY KEY(hh_id))';
--EXECUTE 'CREATE INDEX ' || pkey || '_server_ip ON ' || dst_hh_table || '
--	USING btree  (server_ip NULLS FIRST) ';

EXECUTE 'ALTER TABLE ' || dst_hh_table || ' OWNER TO %DBUSER%';

--command = 'SELECT DISTINCT hh_taz_id, hh_persons 
--	   FROM ' || src_hh_table || ' 
--	   WHERE hh_key=''' || hh_key || ''' 
--	   GROUP BY hh_taz_id, hh_persons';
--command = 'SELECT htable.hh_id 
--	   FROM ' || src_hh_table || ' htable, (' || command || ') AS internal 
--	   WHERE htable.hh_persons = internal.hh_persons AND htable.hh_taz_id = internal.hh_taz_id 
--	   AND htable.hh_key=''' || hh_key || ''' AND random()<' || sample;
command = 'SELECT htable.hh_id, (random()*1000000000)::integer  
	   FROM ' || src_hh_table || ' htable  
	   WHERE htable.hh_key=''' || hh_key || ''' AND random()<' || sample;

EXECUTE 'INSERT INTO ' || dst_hh_table || '(' || command || ')';

--create an index on prio
EXECUTE 'CREATE INDEX ' || pkey || '_prio_key ON ' || dst_hh_table || ' (prio ASC NULLS LAST)';

/*
 * Third opportunity to create a sample -> not implemented yet in postgres:
 * EXECUTE 'SELECT htable.* INTO ' || dst_table || ' FROM ' || src_table || ' htable, (' || command || ') AS internal ' ||
 * 'WHERE htable.hh_persons = internal.hh_persons AND htable.taz_id = internal.taz_id AND years=' || years || ' AND random()<' || sample;
 */

/*
 * Create the viseva statistics:
 * First of all the old entry is deleted. Then the new entry is added with the newly generated statistics. A right outer join is used, 
 * because it is possible that there are no persons of a specific type selected and then it is missing in the array. This join leads 
 * then to a zero at this position.
 */
EXECUTE 'DELETE FROM core.global_viseva_person_groups 
	WHERE hh_table=''' || src_hh_table || ''' AND hh_key=''' || hh_key || ''' AND seed=' || seed || ' AND sample=' || sample;
command = 'SELECT ARRAY(SELECT count(p_id)
	   FROM ' || p_table || ' ptable 
		INNER JOIN ' || dst_hh_table || ' htable ON htable.hh_id = ptable.p_hh_id 
		RIGHT OUTER JOIN core.global_person_codes pcodes ON pcodes.code_tapas = ptable.p_group
	   WHERE pcodes.code_viseva_r > 0 
	   GROUP BY pcodes.code_viseva_r 
	   ORDER BY pcodes.code_viseva_r)';
FOR sum_array IN EXECUTE command LOOP
	EXECUTE 'INSERT INTO core.global_viseva_person_groups 
	   VALUES (
	   ''' || src_hh_table || ''',
	   ''' || hh_key || ''', 
	   ' || sample || ', 
	   ' || seed || ',
	   ' || sum_array[1] || ', 
	   ' || sum_array[2] || ', 
	   ' || sum_array[3] || ',  
	   ' || sum_array[4] || ', 
	   ' || sum_array[5] || ', 
	   ' || sum_array[6] || ', 
	   ' || sum_array[7] || ', 
	   ' || sum_array[8] || ', 
	   ' || sum_array[9] || ', 
	   ' || sum_array[10] || ', 
	   ' || sum_array[11] || ', 
	   ' || sum_array[12] || ', 
	   ' || sum_array[13] || ', 
	   ' || sum_array[14] || ')';
END LOOP;

--EXECUTE 'CREATE TRIGGER ' || split_part(dst_hh_table, '.', 2) || '_trigger_update
--  AFTER UPDATE
--  ON ' || dst_hh_table || '
--  FOR EACH ROW
--  EXECUTE PROCEDURE core.hh_table_func();';

--EXECUTE 'CREATE TRIGGER ' || split_part(dst_hh_table, '.', 2) || '_trigger_delete
--  BEFORE DELETE
--  ON ' || dst_hh_table || '
--  FOR EACH ROW
--  EXECUTE PROCEDURE core.hh_table_func();';


RETURN;
END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION core.create_hh_sample(character varying, character varying, character varying, character varying, double precision, double precision)
  OWNER TO tapas_user_group;
GRANT EXECUTE ON FUNCTION core.create_hh_sample(character varying, character varying, character varying, character varying, double precision, double precision) TO tapas_user_group;
GRANT EXECUTE ON FUNCTION core.create_hh_sample(character varying, character varying, character varying, character varying, double precision, double precision) TO public;

