-- Function: core.create_region_based_tables(character varying, character varying)

-- DROP FUNCTION core.create_region_based_tables(character varying, character varying);

CREATE OR REPLACE FUNCTION core.create_region_based_tables(region character varying, schemaname character varying)
  RETURNS boolean AS
$BODY$DECLARE tablename character varying;

BEGIN

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- TAZ
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_taz';
IF core.exist_table(schemaname, tablename) IS FALSE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'CREATE TABLE ' || schemaname || '.' || tablename || ' (
  taz_id integer NOT NULL,
  taz_bbr_type integer,
  taz_statistical_area integer,
  taz_num_id integer,
  PRIMARY KEY (taz_id))';
--
-- ADD GEOMETRY
--
EXECUTE 'SELECT addgeometrycolumn(''' || schemaname || ''', ''' || tablename || ''', ''taz_coordinate'', 4326, ''POINT'', 2)';
--
-- CREATE INDEX ON GEOMETRY
--
EXECUTE 'CREATE INDEX '|| tablename ||'_taz_coordinate ON '|| schemaname || '.' || tablename ||' USING gist (taz_coordinate)';


--
-- GRANT OPTIONS TO USERS
--	
EXECUTE 'GRANT ALL ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_admin_group';
EXECUTE 'GRANT SELECT ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_user_group';
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- TAZ INFOS PT
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_taz_intra_pt_infos';
IF core.exist_table(schemaname, tablename) IS FALSE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'CREATE TABLE ' || schemaname || '.' || tablename || ' (
  info_taz_id integer NOT NULL,
  average_speed_pt double precision,
  info_name character varying NOT NULL,
  has_intra_traffic_pt boolean DEFAULT true,
  pt_zone integer DEFAULT 1,
  PRIMARY KEY (info_taz_id, info_name))';
--
-- GRANT OPTIONS TO USERS
--	
EXECUTE 'GRANT ALL ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_admin_group';
EXECUTE 'GRANT SELECT ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_user_group';
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- TAZ INFOS MIT
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_taz_intra_mit_infos';
IF core.exist_table(schemaname, tablename) IS FALSE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'CREATE TABLE ' || schemaname || '.' || tablename || ' (
  info_taz_id integer NOT NULL,
  beeline_factor_mit double precision,
  average_speed_mit double precision,
  info_name character varying NOT NULL,
  has_intra_traffic_mit boolean DEFAULT true,
  PRIMARY KEY (info_taz_id, info_name))';
--
-- GRANT OPTIONS TO USERS
--	
EXECUTE 'GRANT ALL ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_admin_group';
EXECUTE 'GRANT SELECT ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_user_group';
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- TAZ FEES AND TOLLS
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_taz_fees_tolls';
IF core.exist_table(schemaname, tablename) IS FALSE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'CREATE TABLE ' || schemaname || '.' || tablename || ' (
  ft_name character varying NOT NULL,
  ft_taz_id integer NOT NULL,
  has_toll_base boolean DEFAULT false,
  toll_type_base integer DEFAULT 0,
  has_fee_base boolean DEFAULT false,
  fee_type_base integer DEFAULT 0,
  has_toll_scen boolean DEFAULT false,
  toll_type_scen integer DEFAULT 0,
  has_fee_scen boolean DEFAULT false,
  fee_type_scen integer DEFAULT 0,
  has_car_sharing boolean DEFAULT false,
  has_car_sharing_base boolean DEFAULT false,
  is_restricted boolean DEFAULT false,
  is_park_and_ride boolean DEFAULT false,
  PRIMARY KEY (ft_name, ft_taz_id))';
--
-- ADD FKs
--
EXECUTE 'ALTER TABLE ' || schemaname || '.' || tablename || ' ADD 
	 FOREIGN KEY (ft_taz_id)
	 REFERENCES ' || schemaname || '.' || region || '_taz (taz_id) 
	 MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY DEFERRED';
--
-- GRANT OPTIONS TO USERS
--
EXECUTE 'GRANT ALL ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_admin_group';
EXECUTE 'GRANT SELECT ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_user_group';
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- TAZ SCORES
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_taz_scores';
IF core.exist_table(schemaname, tablename) IS FALSE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'CREATE TABLE ' || schemaname || '.' || tablename || ' (
  score_taz_id integer NOT NULL,
  score double precision DEFAULT 0,
  score_cat integer DEFAULT 0,
  score_name character varying NOT NULL,
  PRIMARY KEY (score_taz_id, score_name))';
--
-- ADD FKs
--
EXECUTE 'ALTER TABLE ' || schemaname || '.' || tablename || ' ADD 
	 FOREIGN KEY (score_taz_id)
	 REFERENCES ' || schemaname || '.' || region || '_taz (taz_id) 
	 MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY DEFERRED';
--
-- GRANT OPTIONS TO USERS
--
EXECUTE 'GRANT ALL ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_admin_group';
EXECUTE 'GRANT SELECT ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_user_group';
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- BLK
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_blocks';
IF core.exist_table(schemaname, tablename) IS FALSE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'CREATE TABLE ' || schemaname || '.' || tablename || ' (
  blk_id integer NOT NULL,
  blk_taz_id integer NOT NULL,
  PRIMARY KEY (blk_id))';
--
-- ADD GEOMETRY
--
EXECUTE 'SELECT addgeometrycolumn(''' || schemaname || ''', ''' || tablename || ''', ''blk_coordinate'', 4326, ''POINT'', 2)';
--
-- ADD FKs
--
EXECUTE 'ALTER TABLE ' || schemaname || '.' || tablename || ' ADD 
	 FOREIGN KEY (blk_taz_id)
	 REFERENCES ' || schemaname || '.' || region || '_taz (taz_id) 
	 MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY DEFERRED';
--
-- GRANT OPTIONS TO USERS
--	 
EXECUTE 'GRANT ALL ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_admin_group';
EXECUTE 'GRANT SELECT ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_user_group';
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- BLK SCORES
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_block_scores';
IF core.exist_table(schemaname, tablename) IS FALSE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'CREATE TABLE ' || schemaname || '.' || tablename || ' (
  score_blk_id integer NOT NULL,
  score double precision DEFAULT 0,
  score_cat integer DEFAULT 0,
  score_name character varying NOT NULL,
  PRIMARY KEY (score_blk_id, score_name))';
--
-- ADD FKs
--
EXECUTE 'ALTER TABLE ' || schemaname || '.' || tablename || ' ADD 
	 FOREIGN KEY (score_blk_id)
	 REFERENCES ' || schemaname || '.' || region || '_blocks (blk_id) 
	 MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY DEFERRED';
--
-- GRANT OPTIONS TO USERS
--
EXECUTE 'GRANT ALL ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_admin_group';
EXECUTE 'GRANT SELECT ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_user_group';
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- BLK NEXT PT STOP
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_block_next_pt_stop';
IF core.exist_table(schemaname, tablename) IS FALSE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'CREATE TABLE ' || schemaname || '.' || tablename || ' (
  next_pt_stop_blk_id integer NOT NULL,
  next_pt_stop double precision DEFAULT 0,
  next_pt_stop_name character varying NOT NULL,
  PRIMARY KEY (next_pt_stop_blk_id, next_pt_stop_name))';
--
-- ADD FKs
--
EXECUTE 'ALTER TABLE ' || schemaname || '.' || tablename || ' ADD 
	 FOREIGN KEY (next_pt_stop_blk_id)
	 REFERENCES ' || schemaname || '.' || region || '_blocks (blk_id) 
	 MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY DEFERRED';
--
-- GRANT OPTIONS TO USERS
--
EXECUTE 'GRANT ALL ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_admin_group';
EXECUTE 'GRANT SELECT ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_user_group';
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- LOC
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_locations';
IF core.exist_table(schemaname, tablename) IS FALSE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'CREATE TABLE ' || schemaname || '.' || tablename || ' (
  loc_id integer NOT NULL,
  loc_blk_id integer,
  loc_taz_id integer NOT NULL,
  loc_code integer NOT NULL,
  loc_enterprise character varying(25),
  loc_capacity integer,
  loc_has_fix_capacity boolean NOT NULL DEFAULT false,
  loc_group_id integer NOT NULL DEFAULT (-1),
  loc_type text,
  loc_unit text,
  PRIMARY KEY (loc_id))';
--
-- ADD GEOMETRY
--
EXECUTE 'SELECT addgeometrycolumn(''' || schemaname || ''', ''' || tablename || ''', ''loc_coordinate'', 4326, ''POINT'', 2)';
--
-- CREATE INDEX ON GEOMETRY
--
EXECUTE 'CREATE INDEX '|| tablename ||'_loc_coordinate ON '|| schemaname || '.' || tablename ||' USING gist (loc_coordinate)';


--
-- ADD FKs
--
EXECUTE 'ALTER TABLE ' || schemaname || '.' || tablename || ' ADD 
	 FOREIGN KEY (loc_taz_id)
	 REFERENCES ' || schemaname || '.' || region || '_taz (taz_id) 
	 MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY DEFERRED';
--
-- GRANT OPTIONS TO USERS
--	 
EXECUTE 'GRANT ALL ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_admin_group';
EXECUTE 'GRANT SELECT ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_user_group';
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- MATRICES
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_matrices';
IF core.exist_table(schemaname, tablename) IS FALSE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'CREATE TABLE ' || schemaname || '.' || tablename || ' (
  matrix_name character varying NOT NULL,
  matrix_values integer[] NOT NULL,
  PRIMARY KEY (matrix_name))';
--
-- GRANT OPTIONS TO USERS
--	 
EXECUTE 'GRANT ALL ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_admin_group';
EXECUTE 'GRANT SELECT ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_user_group';
END IF;


--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- MATRIXMAPS
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_matrixmap';
IF core.exist_table(schemaname, tablename) IS FALSE THEN

EXECUTE 'CREATE TABLE ' || schemaname || '.' || tablename || ' (
  "matrixMap_name" character varying NOT NULL,
  "matrixMap_num" integer DEFAULT 0,
  "matrixMap_matrixNames" character varying[],
  "matrixMap_distribution" double precision[],
  PRIMARY KEY ("matrixMap_name"))';
  
--
-- GRANT OPTIONS TO USERS
--	 
EXECUTE 'GRANT ALL ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_admin_group';
EXECUTE 'GRANT SELECT ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_user_group';
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- CFN4
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_cfn4';
IF core.exist_table(schemaname, tablename) IS FALSE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'CREATE TABLE ' || schemaname || '.' || tablename || ' (
  "CURRENT_EPISODE_ACTIVITY_CODE_TAPAS" integer NOT NULL,
  "CURRENT_TAZ_SETTLEMENT_CODE_TAPAS" integer NOT NULL,
  "value" double precision NOT NULL,
  comment text,
  raumtyp text,
  key text NOT NULL DEFAULT ''default''::text, 
  PRIMARY KEY ("CURRENT_EPISODE_ACTIVITY_CODE_TAPAS", "CURRENT_TAZ_SETTLEMENT_CODE_TAPAS",key))';
--
-- GRANT OPTIONS TO USERS
--	 
EXECUTE 'GRANT ALL ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_admin_group';
EXECUTE 'GRANT SELECT ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_user_group';
--
-- CREATE TRIGGER
--	
--EXECUTE 'CREATE TRIGGER ' || region || '_cfn4_act_trigger
--  BEFORE INSERT OR UPDATE
--  ON ' || schemaname || '.' || tablename || '
--  FOR EACH ROW
--  EXECUTE PROCEDURE ' || schemaname || '.current_episode_activity_code_tapas_exists_func();';
--EXECUTE 'CREATE TRIGGER ' || region || '_cfn4_taz_trigger
--  BEFORE INSERT OR UPDATE
--  ON ' || schemaname || '.' || tablename || '
--  FOR EACH ROW
--  EXECUTE PROCEDURE ' || schemaname || '.current_taz_settlement_code_tapas_exists_func();';
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- CFN4 Ind
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_cfn4_ind';
IF core.exist_table(schemaname, tablename) IS FALSE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'CREATE TABLE ' || schemaname || '.' || tablename || ' (
  "name" character varying NOT NULL,
  "CURRENT_TAZ_SETTLEMENT_CODE_TAPAS" integer NOT NULL,
  "value" double precision,
  comment text,
  raumtyp text,
  PRIMARY KEY (name, "CURRENT_TAZ_SETTLEMENT_CODE_TAPAS"))';
--
-- GRANT OPTIONS TO USERS
--	 
EXECUTE 'GRANT ALL ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_admin_group';
EXECUTE 'GRANT SELECT ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_user_group';
--
-- CREATE TRIGGER
--	
--EXECUTE 'CREATE TRIGGER ' || region || '_cfn4_ind_taz_trigger
--  BEFORE INSERT OR UPDATE
--  ON ' || schemaname || '.' || tablename || '
--  FOR EACH ROW
--  EXECUTE PROCEDURE ' || schemaname || '.current_taz_settlement_code_tapas_exists_func();';
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- ACT 2 LOC CODES
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_act_2_loc_code';
IF core.exist_table(schemaname, tablename) IS FALSE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'CREATE TABLE ' || schemaname || '.' || tablename || ' (
  act_code integer NOT NULL,
  loc_code integer NOT NULL,
  loc_capa_percentage double precision,
  comment text,
  PRIMARY KEY (act_code, loc_code))';
--
-- ADD FKs
--
EXECUTE 'ALTER TABLE ' || schemaname || '.' || tablename || ' ADD 
	 FOREIGN KEY (act_code)
	 REFERENCES ' || schemaname || '.global_activity_codes (code_zbe) 
	 MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY DEFERRED';
EXECUTE 'ALTER TABLE ' || schemaname || '.' || tablename || ' ADD 
	 FOREIGN KEY (loc_code)
	 REFERENCES ' || schemaname || '.global_location_codes (code_tapas) 
	 MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY DEFERRED';
--
-- GRANT OPTIONS TO USERS
--	 
EXECUTE 'GRANT ALL ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_admin_group';
EXECUTE 'GRANT SELECT ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_user_group';
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- HOUSEHOLDS
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_households';
IF core.exist_table(schemaname, tablename) IS FALSE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'CREATE TABLE ' || schemaname || '.' || tablename || ' (
  hh_id integer NOT NULL,
  hh_type integer,
  hh_persons integer NOT NULL,
  hh_cars integer NOT NULL,
  hh_car_ids integer[],
  hh_income double precision NOT NULL,
  hh_taz_id integer NOT NULL,
  hh_key character varying NOT NULL,
  hh_has_child boolean NOT NULL DEFAULT false,
  block integer,
  PRIMARY KEY (hh_id, hh_key))';
--
-- ADD GEOMETRY
--
EXECUTE 'SELECT addgeometrycolumn(''' || schemaname || ''', ''' || tablename || ''', ''hh_coordinate'', 4326, ''POINT'', 2)';
--
-- GRANT OPTIONS TO USERS
--	 
EXECUTE 'GRANT ALL ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_admin_group';
EXECUTE 'GRANT SELECT ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_user_group';
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- PERSONS
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_persons';
IF core.exist_table(schemaname, tablename) IS FALSE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'CREATE TABLE ' || schemaname || '.' || tablename || ' (
  p_id integer NOT NULL,
  p_hh_id integer NOT NULL,
  p_group integer,
  p_sex integer,
  p_age integer,
  p_age_stba integer,
  p_work_id integer,
  p_working integer,
  p_abo integer,
  p_budget_pt integer,
  p_budget_it integer,
  p_budget_it_fi integer,
  p_key character varying NOT NULL,
  p_driver_license integer,
  p_has_bike boolean NOT NULL DEFAULT false,
  p_education integer DEFAULT 0,
  p_professional integer DEFAULT 0,  
  PRIMARY KEY (p_id, p_hh_id, p_key))';

-- add a comment
EXECUTE 'COMMENT ON COLUMN ' || schemaname || '.' || tablename || '.p_education IS ''H�chster allg. Schulabschluss (basiert auf MikroZensus 2010: Spalte ef310k) umkodiert f�r TAPAS in:
0 = ohne Abschluss
1 = Hauptschulabschluss
2 = Mittlerer Schulabschluss (MSA)
3 = Fachhochschulreife
4 = Abitur
5 = sonstiger Abschluss
99 = keine Angaben''';

-- add a comment
EXECUTE 'COMMENT ON COLUMN ' || schemaname || '.' || tablename || '.p_professional IS ''H�chster berufl. Abschluss (basiert auf MikroZensus 2010: Spalte ef312k) umkodiert f�r TAPAS in:

0 = ohne Abschluss
1 = Ausbildung
2 = Meister/Fachschulabschluss
3 = Hochschule (Fachhochschule)
4 = Universit�t
5 = sonstiger Abschluss
99 = keine Angaben''';
  
  --
-- ADD FKs
--
EXECUTE 'ALTER TABLE ' || schemaname || '.' || tablename || ' ADD 
	 FOREIGN KEY (p_hh_id, p_key)
	 REFERENCES ' || schemaname || '.' || region || '_households (hh_id, hh_key) 
	 MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY DEFERRED';
EXECUTE 'ALTER TABLE ' || schemaname || '.' || tablename || ' ADD 
	 FOREIGN KEY (p_group)
	 REFERENCES ' || schemaname || '.global_person_codes (code_tapas) 
	 MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY DEFERRED';
EXECUTE 'ALTER TABLE ' || schemaname || '.' || tablename || ' ADD 
	 FOREIGN KEY (p_sex)
	 REFERENCES ' || schemaname || '.global_sex_codes (code_sex) 
	 MATCH SIMPLE ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY DEFERRED';
--
-- GRANT OPTIONS TO USERS
--	 
EXECUTE 'GRANT ALL ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_admin_group';
EXECUTE 'GRANT SELECT ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_user_group';
END IF;

--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- CARS
--
----------------------
--
-- CHECK TABLE EXISTENCE
--
tablename = region || '_cars';
IF core.exist_table(schemaname, tablename) IS FALSE THEN
--
-- CREATE TABLE AND PK
--
EXECUTE 'CREATE TABLE ' || schemaname || '.' || tablename || ' (
  car_id integer NOT NULL,
  kba_no integer,
  engine_type integer,
  is_company_car boolean DEFAULT false,
  car_key character varying NOT NULL,
  emission_type integer,
  restriction boolean DEFAULT false,
  fix_costs double precision DEFAULT 0,
  automation_level integer DEFAULT 0,
  vtype_id text DEFAULT ''passenger''::text,
  CONSTRAINT '||tablename||'_pkey PRIMARY KEY (car_id, car_key)
)';
EXECUTE 'GRANT ALL ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_admin_group';
EXECUTE 'GRANT SELECT ON TABLE ' || schemaname || '.' || tablename || ' TO tapas_user_group';
END IF;
--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
--
-- END
--
RETURN TRUE;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.create_region_based_tables(character varying, character varying) OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.create_region_based_tables(character varying, character varying) TO public;

