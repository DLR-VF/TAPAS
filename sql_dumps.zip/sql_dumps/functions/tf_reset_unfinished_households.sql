-- Function: core.tf_reset_unfinished_households()

-- DROP FUNCTION core.tf_reset_unfinished_households();

CREATE OR REPLACE FUNCTION core.tf_reset_unfinished_households()
  RETURNS trigger AS
$BODY$BEGIN
IF core.exist_table('temp', 'households_' || OLD.sim_key) THEN
	EXECUTE 'UPDATE temp.households_' || OLD.sim_key || ' SET hh_started = false, server_ip = null 
		WHERE  hh_started = true AND hh_finished = false AND server_ip = ''' || OLD.server_ip || '''';
END IF;
RETURN NEW;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.tf_reset_unfinished_households() OWNER TO %DBUSER%;
