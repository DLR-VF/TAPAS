-- Function: core.delete_rows(character varying, character varying, character varying, integer)

-- DROP FUNCTION core.delete_rows(character varying, character varying, character varying, integer);

CREATE OR REPLACE FUNCTION core.delete_rows(tablename character varying, col character varying, col_value character varying, col_type integer)
  RETURNS boolean AS
$BODY$DECLARE count INTEGER;
DECLARE command TEXT;
DECLARE compare TEXT;
DECLARE temp_tablename TEXT;

BEGIN

-- col_type 0 is character (varying)
IF col_type = -1 THEN
	EXECUTE 'DELETE FROM ' || tablename;
ELSE
	IF col_type = 0 THEN
		compare = '''' || col_value || '''';
	ELSE
		compare = col_value;
	END IF;

	command = 'SELECT count(*) FROM ' || tablename || ' WHERE ' || col || '=' || compare;
	FOR count IN EXECUTE command LOOP END LOOP;

	IF count < 1000 THEN
		EXECUTE 'DELETE FROM ' || tablename || ' WHERE ' || col || '=' || compare;
	ELSE
		temp_tablename = 'temp_' || col || '_' || col_value;
		EXECUTE 'CREATE TEMPORARY TABLE ' || temp_tablename || ' AS 
				SELECT * FROM ' || tablename || ' WHERE ' || col || '<>' || compare;
	--	Truncate table is not possible because of foreign key constraints. But in the case of many inserts a delete from is usable.
	--	The delete from needs aproximatly 5-10% of the insert duration
	--	EXECUTE 'TRUNCATE TABLE ' || tablename;
		EXECUTE 'DELETE FROM ' || tablename;
		EXECUTE 'INSERT INTO ' || tablename || ' (SELECT * FROM ' || temp_tablename || ')';
		EXECUTE 'DROP TABLE ' || temp_tablename;
	END IF;
END IF;

RETURN TRUE;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.delete_rows(character varying, character varying, character varying, integer) OWNER TO %DBUSER%;
