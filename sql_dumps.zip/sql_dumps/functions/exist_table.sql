-- Function: core.exist_table(character varying, character varying)

-- DROP FUNCTION core.exist_table(character varying, character varying);

CREATE OR REPLACE FUNCTION core.exist_table(schemaname character varying, tablename character varying)
  RETURNS boolean AS
$BODY$DECLARE bool boolean;
BEGIN
FOR bool IN EXECUTE 'SELECT count(*) > 0 AS exsits FROM pg_tables 
                     WHERE tablename=''' || tablename || ''' AND schemaname=''' || schemaname || '''' LOOP END LOOP;
RETURN bool;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.exist_table(character varying, character varying) OWNER TO %DBUSER%;






-- Function: core.exist_table(character varying)

-- DROP FUNCTION core.exist_table(character varying);

CREATE OR REPLACE FUNCTION core.exist_table(tablename character varying)
  RETURNS boolean AS
$BODY$
BEGIN
RETURN core.exist_table(split_part(tablename, '.', 1), split_part(tablename, '.', 2));
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.exist_table(character varying, character varying) OWNER TO %DBUSER%;


