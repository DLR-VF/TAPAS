-- Function: core.export_hh_sample(character varying, character varying, character varying, character varying, character varying, integer)

-- DROP FUNCTION core.export_hh_sample(character varying, character varying, character varying, character varying, character varying, integer);

CREATE OR REPLACE FUNCTION core.export_hh_sample(hh_table character varying, hh_sample_table character varying, person_table character varying, hh_file character varying, person_file character varying, years integer)
  RETURNS boolean AS
$BODY$BEGIN


EXECUTE 'COPY 	(SELECT src.hh_id, hh_taz_id, hh_taz_id, X(hh_coordinate), Y(hh_coordinate), hh_persons, hh_cars, hh_income 
		FROM ' || hh_table || ' src, ' || hh_sample_table || ' dst 
		WHERE dst.hh_id = src.hh_id AND src.hh_year = ' || years || ')
	TO ''/mnt/gruppen_lw/VF_Server_neu/Projekte/PJ_laufend/TAPAS/Input/Inputdateien_V9.1/' || hh_file || '''
	WITH CSV HEADER';

EXECUTE 'COPY 	(SELECT p_table.p_id, X(hh_coordinate), Y(hh_coordinate), 0, 0, hh_taz_id, src.hh_id, p_sex, p_age, p_age_stba, 
			hh_taz_id, p_working, p_abo, hh_persons, hh_cars, p_group, -1, p_budget_pt, p_budget_it, p_budget_it_fi
		FROM ' || hh_table || ' src, ' || hh_sample_table || ' dst, ' || person_table || ' p_table  
		WHERE dst.hh_id = src.hh_id 
		  AND p_table.p_hh_id = src.hh_id 
		  AND src.hh_year = ' || years || '
		  AND p_table.p_year = src.hh_year)
	TO ''/mnt/gruppen_lw/VF_Server_neu/Projekte/PJ_laufend/TAPAS/Input/Inputdateien_V9.1/' || person_file || '''
	WITH CSV HEADER';

RETURN true;

END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.export_hh_sample(character varying, character varying, character varying, character varying, character varying, integer) OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.export_hh_sample(character varying, character varying, character varying, character varying, character varying, integer) TO public;






-- Function: core.export_hh_sample(character varying, character varying, integer, numeric, numeric, character varying, character varying)

-- DROP FUNCTION core.export_hh_sample(character varying, character varying, integer, numeric, numeric, character varying, character varying);

CREATE OR REPLACE FUNCTION core.export_hh_sample(hh_table character varying, person_table character varying, years integer, seed numeric, sample numeric, hh_file character varying, person_file character varying)
  RETURNS boolean AS
$BODY$BEGIN

EXECUTE 'SELECT core.create_hh_sample(
		''' || hh_table || ''', 
		''temp.hh_temp'', 
		''' || person_table || ''', 
		' || years || ', 
		' || seed || ', 
		' || sample || ')';

EXECUTE 'SELECT core.export_hh_sample(
		''' || hh_table || ''', 
		''temp.hh_temp'', 
		''' || person_table || ''', 
		''' || hh_file || ''', 
		''' || person_file || ''', 
		' || years ||')';

DROP TABLE temp.hh_temp;

RETURN true;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.export_hh_sample(character varying, character varying, integer, numeric, numeric, character varying, character varying) OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.export_hh_sample(character varying, character varying, integer, numeric, numeric, character varying, character varying) TO public;

