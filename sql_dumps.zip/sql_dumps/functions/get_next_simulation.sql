-- Function: core.get_next_simulation()

-- DROP FUNCTION core.get_next_simulation();

CREATE OR REPLACE FUNCTION core.get_next_simulation()
  RETURNS character varying AS
$BODY$
DECLARE sim CHARACTER VARYING;
DECLARE started_hh integer;
BEGIN
sim = NULL;

-- loop until we find a simulation to do something
FOR sim IN SELECT sim_key FROM simulations WHERE sim_ready = TRUE AND sim_started = TRUE AND sim_finished = false ORDER BY timestamp_insert LOOP 
	-- look if this is the first fetch for this sim
	EXECUTE 'SELECT hh_id FROM temp.households_' || sim || ' WHERE hh_started =true  LIMIT 1' INTO started_hh;
	GET DIAGNOSTICS started_hh = ROW_COUNT;
	IF (started_hh = 0) THEN
		-- set started timestamp
		EXECUTE 'UPDATE simulations SET timestamp_started = now() WHERE sim_key = ''' || sim || '''';
	END IF;
	
	-- look if there are more households to process
	EXECUTE 'SELECT hh_id FROM temp.households_' || sim || ' WHERE hh_started =false LIMIT 1' INTO started_hh;
	GET DIAGNOSTICS started_hh = ROW_COUNT;
	IF (started_hh = 0 ) THEN
		-- nothing more to do here!
		sim = NULL;
	END IF;
	-- exit on the first sim  with jobs to do we found
	EXIT WHEN (sim IS NOT NULL) ;
END LOOP;

RETURN sim;
END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION core.get_next_simulation()
  OWNER TO %DBUSER%;
