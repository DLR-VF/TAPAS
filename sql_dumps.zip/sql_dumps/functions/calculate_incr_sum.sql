-- Function: core.calculate_incr_sum(character varying, integer, integer)

-- DROP FUNCTION core.calculate_incr_sum(character varying, integer, integer);

CREATE OR REPLACE FUNCTION core.calculate_incr_sum(temp_location_table character varying, taz_id integer, loc_code integer)
  RETURNS boolean AS
$BODY$DECLARE command character varying;
DECLARE sum double precision;
DECLARE act integer;
DECLARE rec RECORD;
BEGIN
	/*
	 * In the first part the incremental sums of all locations in the temporary location table which are inside 
	 * the traffic analysis zone (taz_id) and have the location code (loc_code) are updated.
	 */
	sum = 0;
	command = 'SELECT loc_id, loc_weight FROM ' || temp_location_table || ' 
		   WHERE loc_taz_id=' || taz_id || ' AND loc_code=' || loc_code || ' ORDER BY loc_id';

	FOR rec IN EXECUTE command LOOP
		sum = sum + rec.loc_weight;
		EXECUTE 'UPDATE ' || temp_location_table || ' SET loc_incr_weight=' || sum || ' 
			WHERE loc_id=' || rec.loc_id;
	END LOOP;

	/*
	 * In the second part the location sum and the incremental sums of all locations sets in the temporary 
	 * location set table which are inside the traffic analysis zone (taz_id) and have the location code (loc_code) are updated.
	 */
	EXECUTE 'UPDATE ' || temp_location_table || '_set SET set_loc_sum_weight=' || sum || ' 
		WHERE set_taz_id=' || taz_id || ' AND loc_code=' || loc_code;

	act = -1;
	command = 'SELECT act_code, loc_code, set_loc_sum_weight FROM ' || temp_location_table || '_set 
		   WHERE set_taz_id=' || taz_id || ' ORDER BY act_code, loc_code';

	FOR rec IN EXECUTE command LOOP
		IF act <> rec.act_code THEN
			act = rec.act_code;
			sum = 0;
		END IF;
		sum = sum + rec.set_loc_sum_weight;
		EXECUTE 'UPDATE ' || temp_location_table || '_set SET set_incr_weight=' || sum || ' 
			WHERE set_taz_id=' || taz_id || ' AND loc_code=' || rec.loc_code || ' AND act_code=' || rec.act_code;
	END LOOP;

	/*
	 * Does not work because the update is not immediate. The values are written bach after the statement
	 * EXECUTE 'UPDATE ' || temp_location_table || ' t SET incr_sum = (
	 *			SELECT sum(weight)
	 *			FROM ' || temp_location_table || ' 
	 *			WHERE taz_id=' || taz_id || ' AND loc_code=' || loc_code || ' AND loc_id <= t.loc_id)
	 *		   WHERE t.taz_id=' || taz_id || ' AND t.loc_code=' || loc_code;
	 */
	RETURN TRUE;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.calculate_incr_sum(character varying, integer, integer) OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.calculate_incr_sum(character varying, integer, integer) TO public;
GRANT EXECUTE ON FUNCTION core.calculate_incr_sum(character varying, integer, integer) TO tapas_user_group;

COMMENT ON FUNCTION core.calculate_incr_sum(character varying, integer, integer) IS 'This method calculates all necessary incremental sums in the temporary location and locations set  tables depending on the current taz_id and loc_code.';
