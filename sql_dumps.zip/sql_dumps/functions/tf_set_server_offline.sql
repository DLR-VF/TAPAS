-- Function: public.set_server_offline()

-- DROP FUNCTION public.set_server_offline();

CREATE OR REPLACE FUNCTION public.set_server_offline()
  RETURNS trigger AS
$BODY$BEGIN
UPDATE public.servers
SET server_online = FALSE,
    server_usage = 0
WHERE server_name = OLD.host;
RETURN NEW;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION public.set_server_offline OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION public.set_server_offline() TO tapas_admin_group;
GRANT EXECUTE ON FUNCTION public.set_server_offline() TO tapas_user_group;
