-- Function: core.load_taz(character varying, character varying)

-- DROP FUNCTION core.load_taz(character varying, character varying);

CREATE OR REPLACE FUNCTION core.load_taz(filename character varying, tablename character varying)
  RETURNS boolean AS
$BODY$BEGIN

CREATE TEMPORARY TABLE taz_temp(
	taz_id integer,
	coord_x double precision,
	coord_y double precision,
	bbr_type integer,
	PRIMARY KEY (taz_id));

EXECUTE 'COPY taz_temp FROM ''' || filename || ''' WITH CSV HEADER';
EXECUTE 'SELECT core.delete_rows(''' || tablename || ''','''','''',-1)';
EXECUTE 'INSERT INTO ' || tablename || ' (
		SELECT taz_id, bbr_type, NULL, NULL,  GeometryFromText(''POINT(''||coord_x||'' ''||coord_y||'')'', 4326) FROM taz_temp)';

DROP TABLE taz_temp;
RETURN TRUE;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.load_taz(character varying, character varying) OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.load_taz(character varying, character varying) TO public;

