-- Function: core.get_avg_dist_next_stop(character varying, character varying)

-- DROP FUNCTION core.get_avg_dist_next_stop(character varying, character varying);

CREATE OR REPLACE FUNCTION core.get_avg_dist_next_stop(block_next_pt_stop_table character varying, block_next_pt_stop_name character varying)
  RETURNS double precision AS
$BODY$DECLARE average double precision;
BEGIN
FOR average IN EXECUTE 'SELECT avg(next_pt_stop) FROM ' || block_next_pt_stop_table || ' WHERE next_pt_stop_name=''' || block_next_pt_stop_name || '''' LOOP END LOOP;
RETURN average;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.get_avg_dist_next_stop(character varying, character varying) OWNER TO %DBUSER%;
