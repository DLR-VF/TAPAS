-- Function: core.getpersonidsfromhh_trip(character varying, character varying, character varying)

-- DROP FUNCTION core.getpersonidsfromhh_trip(character varying, character varying, character varying);

CREATE OR REPLACE FUNCTION core.getpersonidsfromhh_trip(the_table character varying, the_id character varying, the_key character varying)
  RETURNS SETOF integer AS
$BODY$
declare
	res record;
	command TEXT;
begin
	command = 'SELECT p_id from ' || the_table || ' 
		WHERE p_hh_id = ANY(' || the_id ||') AND p_key = ' || quote_literal(the_key) ;
	FOR res IN EXECUTE command LOOP
		RETURN NEXT res.p_id;
	END LOOP;
end;
$BODY$
  LANGUAGE plpgsql VOLATILE
  ROWS 1000
  COST 100;
ALTER FUNCTION core.getpersonidsfromhh_trip(character varying, character varying, character varying)
  OWNER TO %DBUSER%;
