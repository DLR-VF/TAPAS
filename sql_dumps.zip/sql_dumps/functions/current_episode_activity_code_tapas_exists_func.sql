-- Function: core.current_episode_activity_code_tapas_exists_func()

-- DROP FUNCTION core.current_episode_activity_code_tapas_exists_func();

CREATE OR REPLACE FUNCTION core.current_episode_activity_code_tapas_exists_func()
  RETURNS trigger AS
$BODY$DECLARE bool boolean;
DECLARE code integer;

BEGIN

code = NEW."CURRENT_EPISODE_ACTIVITY_CODE_TAPAS";
FOR bool IN EXECUTE 'SELECT EXISTS(SELECT code_tapas 
			    FROM core.global_activity_codes 
			    WHERE code_tapas = ' || code || ')'
	 LOOP
END LOOP;

IF bool = false THEN
	RAISE EXCEPTION 'CURRENT_EPISODE_ACTIVITY_CODE_TAPAS % does not exist in core.global_activity_codes', code;
END IF;

RETURN NEW;

END$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION core.current_episode_activity_code_tapas_exists_func()
  OWNER TO %DBUSER%;