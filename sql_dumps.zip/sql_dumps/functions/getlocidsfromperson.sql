-- Function: core.getlocidsfromperson(character varying, character varying)

-- DROP FUNCTION core.getlocidsfromperson(character varying, character varying);

CREATE OR REPLACE FUNCTION core.getlocidsfromperson(the_table character varying, the_id character varying)
  RETURNS SETOF integer AS
$BODY$
declare
	res record;
	command TEXT;
begin
	command = 'SELECT loc_id_end FROM ' || the_table || ' 
		WHERE p_id = ANY(' || the_id || ')' ;
	RETURN QUERY EXECUTE command;
	--FOR res IN EXECUTE command LOOP
	--	RETURN NEXT res.loc_id_end;
	--END LOOP;
end;
$BODY$
  LANGUAGE plpgsql VOLATILE
  ROWS 1000
  COST 100;
ALTER FUNCTION core.getlocidsfromperson(character varying, character varying)
  OWNER TO %DBUSER%;
