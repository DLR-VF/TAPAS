-- Function: core.reset_unfinished_households()

-- DROP FUNCTION core.reset_unfinished_households(key_val character varying, server_ip character varying);

CREATE OR REPLACE FUNCTION core.reset_unfinished_households(key_val character varying, server_ip character varying)
  RETURNS integer AS
$BODY$
DECLARE command TEXT;
DECLARE sim_region TEXT;
DECLARE count integer;
DECLARE rec RECORD;
BEGIN
IF core.exist_table('temp', 'households_' || key_val) THEN
	-- check for unfinished hhs
	command = 'SELECT hh_id FROM temp.households_' || key_val || ' WHERE hh_started = true AND hh_finished = false AND server_ip = inet ''' || server_ip || ''' LIMIT 1';		
	EXECUTE command INTO count;
	GET DIAGNOSTICS count = ROW_COUNT;
	IF(count > 0) THEN
	  -- get region name
		command = 'SELECT param_value into sim_region FROM simulation_parameters WHERE sim_key = '''||key_val||''' and param_key=''DB_REGION''';
		EXECUTE command INTO sim_region;
    -- lock tables
		EXECUTE 'LOCK TABLE ' || sim_region || '_trips_' || key_val || ' IN EXCLUSIVE MODE';
		EXECUTE 'LOCK TABLE temp.households_' || key_val || ' IN EXCLUSIVE MODE'; 	

		-- remove trips for the unfinished hhs
		EXECUTE 'DELETE FROM ' || sim_region || '_trips_' || key_val ||' WHERE hh_id = ANY(SELECT hh_id FROM temp.households_' || key_val || ' WHERE hh_started = true AND hh_finished = false AND server_ip = inet ''' || server_ip || ''')';

		--command = 'SELECT hh_id FROM temp.households_' || key_val || ' WHERE hh_started = true AND hh_finished = false AND server_ip = inet ''' || server_ip || '''';		
		--FOR rec IN EXECUTE command LOOP
		--	EXECUTE 'DELETE FROM ' || sim_region || '_trips_' || key_val ||' WHERE hh_id = ' || rec.hh_id;
		--END LOOP;		
		-- reset the unfinished hhs
		EXECUTE 'UPDATE temp.households_' || key_val || ' SET hh_started = false, server_ip = null 
			WHERE  hh_started = true AND hh_finished = false AND server_ip = ''' || server_ip || '''';	
		GET DIAGNOSTICS count = ROW_COUNT;
	END IF;	
END IF;
RETURN count;
END$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION core.reset_unfinished_households(key_val character varying, server_ip character varying)
  OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.reset_unfinished_households(key_val character varying, server_ip character varying) TO tapas_user_group;
