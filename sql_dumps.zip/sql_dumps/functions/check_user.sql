-- Function: core.check_user(character varying)

-- DROP FUNCTION core.check_user(character varying);

CREATE OR REPLACE FUNCTION core.check_user(user_name character varying)
  RETURNS boolean AS
$BODY$
DECLARE rec RECORD;
BEGIN
FOR rec IN EXECUTE 'SELECT * FROM pg_authid WHERE rolname = ''' || user_name || '''' LOOP
	RETURN TRUE;
END LOOP;
RETURN FALSE;
END
$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.check_user(character varying) OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.check_user(character varying) TO public;
GRANT EXECUTE ON FUNCTION core.check_user(character varying) TO tapas_user_group;

COMMENT ON FUNCTION core.check_user(character varying) IS 'This method checks whether a user is permitted to use the core schema.';
