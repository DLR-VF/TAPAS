-- Function: core.deletehhfromtrip(character varying, character varying)

-- DROP FUNCTION core.deletehhfromtrip(character varying, character varying);

CREATE OR REPLACE FUNCTION core.deletehhfromtrip(the_table character varying, hh_id character varying)
  RETURNS integer AS
$BODY$
declare
	command TEXT;
	numDeleted integer;
begin
	numDeleted = 0;
	--command = 'LOCK TABLE ' || the_table || ' IN EXCLUSIVE MODE';
	--EXECUTE command; 
	command = 'DELETE FROM ' || the_table || ' 
		WHERE hh_id = ANY (' || hh_id || ')' ;
	EXECUTE command;
	IF FOUND THEN
    GET DIAGNOSTICS numDeleted = ROW_COUNT;
	END IF;

RETURN numDeleted;
end;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION core.deletehhfromtrip(character varying, character varying)
  OWNER TO %DBUSER%;
