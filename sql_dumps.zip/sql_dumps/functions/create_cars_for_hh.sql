-- Function: core.create_cars_for_hh(region character varying)

-- DROP FUNCTION core.create_cars_for_hh(region character varying);

CREATE OR REPLACE FUNCTION core.create_cars_for_hh(region character varying)
  RETURNS void AS
$BODY$
DECLARE command character varying;
DECLARE rec RECORD;
DECLARE num_of_cars INTEGER;
DECLARE car_id INTEGER;
DECLARE car_table CHARACTER VARYING;
DECLARE hh_table CHARACTER VARYING;
BEGIN
car_table = 'core.'||region||'_cars';
hh_table = 'core.'||region||'_households';

car_id = 1;
command = 'SELECT hh_id, hh_cars,hh_key FROM ' ||hh_table;

FOR rec IN EXECUTE command LOOP
	FOR num_of_cars IN 1..rec.hh_cars LOOP
		EXECUTE 'INSERT INTO ' || car_table || ' VALUES ( ' ||car_id|| ', '||rec.hh_id||', 1, 0, FALSE, '''|| rec.hh_key||''')';
		car_id = car_id +1;
	END LOOP;
END LOOP;


END;$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.create_cars_for_hh(character varying) OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.create_cars_for_hh(character varying) TO public;
GRANT EXECUTE ON FUNCTION core.create_cars_for_hh(character varying) TO tapas_user_group;
