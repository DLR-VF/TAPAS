-- Function: core.load_csvfile_to_table(character varying, character varying)

-- DROP FUNCTION core.load_csvfile_to_table(character varying, character varying);

CREATE OR REPLACE FUNCTION core.load_csvfile_to_table(filename character varying, tablename character varying)
  RETURNS void AS
$BODY$BEGIN
EXECUTE 'SET CONSTRAINTS ALL DEFERRED';
EXECUTE 'SELECT core.delete_rows(''' || tablename || ''','''','''',-1)';
EXECUTE 'COPY ' || tablename || ' FROM ''' || filename || ''' WITH CSV HEADER';
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.load_csvfile_to_table(character varying, character varying) OWNER TO %DBUSER%;

