-- Function: core.select_fk_tables(character varying, character varying)

-- DROP FUNCTION core.select_fk_tables(character varying, character varying);

CREATE OR REPLACE FUNCTION core.select_fk_tables(schemaname character varying, tablename character varying)
  RETURNS SETOF text AS
$BODY$DECLARE rec RECORD;
DECLARE command TEXT;

BEGIN

command = 
'SELECT s.nspname || ''.'' || t.relname AS tablename
FROM pg_namespace s, pg_class ft, pg_class t, pg_constraint c
WHERE s.nspname = ''' || schemaname || '''
AND s.oid = ft.relnamespace
AND ft.relkind = ''r''::"char"
AND ft.relname = ''' || tablename ||'''
AND c.contype = ''f''::"char"
AND c.confrelid = ft.oid
AND t.oid = c.conrelid';

FOR rec in EXECUTE command LOOP
	RETURN NEXT rec.tablename;
END LOOP;

RETURN;
END
$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  ROWS 1000
  COST 100;
ALTER FUNCTION core.select_fk_tables(character varying, character varying) OWNER TO %DBUSER%;












-- Function: core.select_fk_tables(character varying)

-- DROP FUNCTION core.select_fk_tables(character varying);

CREATE OR REPLACE FUNCTION core.select_fk_tables(complete_tablename character varying)
  RETURNS SETOF text AS
$BODY$DECLARE schemaname TEXT;
DECLARE tablename TEXT;
DECLARE rec TEXT;

BEGIN
schemaname = split_part(complete_tablename, '.', 1);
tablename = split_part(complete_tablename, '.', 2);

FOR rec IN EXECUTE 'SELECT * FROM core.select_fk_tables(''' || schemaname || ''', ''' || tablename || ''') ' LOOP
	RETURN NEXT rec;
END LOOP;
RETURN;
END
$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  ROWS 1000
  COST 100;
ALTER FUNCTION core.select_fk_tables(character varying) OWNER TO %DBUSER%;

