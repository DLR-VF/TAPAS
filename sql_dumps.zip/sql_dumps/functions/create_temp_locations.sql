-- Function: core.create_temp_locations(character varying, character varying, character varying)

-- DROP FUNCTION core.create_temp_locations(character varying, character varying, character varying);

CREATE OR REPLACE FUNCTION core.create_temp_locations(location_table character varying, temp_location_table character varying, loc_key character varying)
  RETURNS void AS
$BODY$
DECLARE pkey CHARACTER VARYING;
BEGIN
pkey = split_part(temp_location_table, '.', 2);

--create temporary location table
EXECUTE 'CREATE TABLE ' || temp_location_table || ' (
		loc_id integer,
		loc_occupancy integer DEFAULT 0,
		CONSTRAINT ' || pkey || '_pkey PRIMARY KEY(loc_id))';
--set OWNER TO tapas_user_group
EXECUTE 'ALTER TABLE ' || temp_location_table || ' OWNER TO tapas_user_group';

EXECUTE 'INSERT INTO ' || temp_location_table || '( loc_id )
		SELECT lt.loc_id
		FROM ' || location_table || ' lt where loc_capacity > 0 and key='''||loc_key||'''';



END;$BODY$
LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.create_temp_locations(character varying, character varying, character varying) OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.create_temp_locations(character varying, character varying, character varying) TO public;
GRANT EXECUTE ON FUNCTION core.create_temp_locations(character varying, character varying, character varying) TO tapas_user_group;




-- Function: core.create_temp_locations(character varying, character varying)

-- DROP FUNCTION core.create_temp_locations(character varying, character varying);

CREATE OR REPLACE FUNCTION core.create_temp_locations(location_table character varying, temp_location_table character varying)
  RETURNS void AS
$BODY$
BEGIN

--create temporary location table
SELECT core.create_temp_locations(location_table, temp_location_table, 'default');

END;$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.create_temp_locations(character varying, character varying) OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.create_temp_locations(character varying, character varying) TO public;
GRANT EXECUTE ON FUNCTION core.create_temp_locations(character varying, character varying) TO tapas_user_group;
