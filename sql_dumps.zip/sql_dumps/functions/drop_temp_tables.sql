-- Function: core.drop_temp_tables(character varying, character varying)
-- DROP FUNCTION core.drop_temp_tables(character varying, character varying);

CREATE OR REPLACE FUNCTION core.drop_temp_tables(temp_hh_table character varying, temp_loc_table character varying)
  RETURNS boolean AS
$BODY$BEGIN
IF core.exist_table(temp_hh_table) THEN
	EXECUTE 'DROP TABLE ' || temp_hh_table;
END IF;
IF core.exist_table(temp_loc_table) THEN
	EXECUTE 'DROP TABLE ' || temp_loc_table;
END IF;
RETURN TRUE;
END$BODY$
  LANGUAGE 'plpgsql'
  COST 100;
ALTER FUNCTION core.drop_temp_tables(character varying, character varying) OWNER TO %DBUSER%;

GRANT EXECUTE ON FUNCTION core.drop_temp_tables(character varying, character varying) TO tapas_user_group;




-- Function: core.drop_temp_tables(character varying, boolean)
-- DROP FUNCTION core.drop_temp_tables(character varying, boolean);

CREATE OR REPLACE FUNCTION core.drop_temp_tables(sim_key character varying)
  RETURNS boolean AS
$BODY$BEGIN
RETURN core.drop_temp_tables('temp.households_' || sim_key, 'temp.locations_' || sim_key);
END$BODY$
  LANGUAGE 'plpgsql'
  COST 100;
ALTER FUNCTION core.drop_temp_tables(character varying) OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.drop_temp_tables(character varying) TO tapas_user_group;
