-- Function: core.calculate_pt_scores(character varying)

-- DROP FUNCTION core.calculate_pt_scores(character varying);

CREATE OR REPLACE FUNCTION core.calculate_pt_scores(region character varying)
  RETURNS boolean AS
$BODY$DECLARE command character varying;
DECLARE sum double precision;
DECLARE actBlk integer;
DECLARE rec RECORD;
BEGIN
	
	--loop over all blocks
	command = 'SELECT blocknr :: integer FROM core.'||region||'_blocks_multiline';
	FOR actBlk IN EXECUTE command LOOP
		sum = 0;
		command = 'SELECT distTable.name, distTable.numlines, distTable.distance FROM (SELECT name, numlines, distance_sphere(pt_stop_coordinate, (SELECT the_geom FROM core.'||region||'_blocks_multiline WHERE blocknr = '||actBlk||')) as distance FROM core.'||region||'_pt_stops) as distTable WHERE distTable.distance<=1200';
		FOR rec IN EXECUTE command LOOP
			-- select all stops within radius of 600m
			if(rec.distance <=600) THEN
			  -- sum the buslines
				sum = sum +(rec.numlines*0.5);
				-- add One for each s or u stop
				IF rec.name LIKE 'S %' OR rec.name LIKE 'U %' THEN
					sum = sum+1;
				END IF;
				-- add Two for each S+U stop
				IF rec.name LIKE 'S+U %' THEN
					sum = sum+2;
				END IF;
			ELSE		-- select all stops outside 600m and within within radius of 1200m
			  -- sum the buslines
				sum = sum +(rec.numlines*0.2);
				-- add One for each s or u stop
				IF rec.name LIKE 'S %' OR rec.name LIKE 'U %' THEN
					sum = sum+0.8;
				END IF;
				-- add Two for each S+U stop
				IF rec.name LIKE 'S+U %' THEN
					sum = sum+1.6;
				END IF;
			END IF;
		END LOOP;
		
		RAISE NOTICE 'Block: % score: %' , actBlk, sum;

	
	END LOOP;
	


END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.calculate_pt_scores(character varying) OWNER TO %DBUSER%;
