-- Function: core.check_matrix()

-- DROP FUNCTION core.check_matrix();

CREATE OR REPLACE FUNCTION core.check_matrix()
  RETURNS boolean AS
$BODY$DECLARE matrix integer[];
DECLARE x integer;
BEGIN
FOR matrix IN EXECUTE 'SELECT matrix FROM core.braunschweig_matrices' LOOP
	FOR x IN 1..911 LOOP
		IF matrix[x*911+x] = 0 THEN
			RAISE NOTICE '0 found in matrix at position (%,%)', x, x;
		END IF;
	END LOOP;
END LOOP;
RETURN TRUE;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.check_matrix() OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.check_matrix() TO public;

