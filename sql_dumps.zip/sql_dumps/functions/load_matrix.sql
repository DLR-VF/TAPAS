-- Function: core.load_matrix(character varying, character varying, character varying)

-- DROP FUNCTION core.load_matrix(character varying, character varying, character varying);

CREATE OR REPLACE FUNCTION core.load_matrix(matrix_file character varying, matrix_name character varying, matrix_table character varying)
  RETURNS boolean AS
$BODY$DECLARE value_array text[];

BEGIN
CREATE TEMPORARY TABLE temp_matrix_text (line text);
EXECUTE 'COPY temp_matrix_text FROM ''' || matrix_file || ''' WITH CSV';

value_array = null;
FOR value_array IN EXECUTE 'SELECT ARRAY(SELECT line FROM temp_matrix_text)' LOOP END LOOP;

EXECUTE 'SELECT core.delete_rows(''' || matrix_table || ''',''matrix_name'',''' || matrix_name || ''',0)';
EXECUTE 'INSERT INTO ' || matrix_table || ' VALUES (''' || matrix_name || ''', ARRAY[' || array_to_string(value_array, ',') || '])';

DROP TABLE temp_matrix_text;
RETURN TRUE;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.load_matrix(character varying, character varying, character varying) OWNER TO %DBUSER%;
