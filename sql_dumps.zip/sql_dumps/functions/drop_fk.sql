-- Function: core.drop_fk(text, text)

-- DROP FUNCTION core.drop_fk(text, text);

CREATE OR REPLACE FUNCTION core.drop_fk(schemaname text, tablename text)
  RETURNS SETOF text AS
$BODY$DECLARE crec RECORD;
DECLARE arec RECORD;
DECLARE command TEXT;
DECLARE columns TEXT;
DECLARE fcolumns TEXT;

BEGIN

command = 
'SELECT s.nspname AS schemaname, t.relname AS tablename, c.conname AS conname, c.conkey, c.confkey, c.condeferrable, c.condeferred
FROM pg_namespace s, pg_class ft, pg_class t, pg_constraint c
WHERE s.nspname = ''' || schemaname || '''
AND s.oid = ft.relnamespace
AND ft.relkind = ''r''::"char"
AND ft.relname = ''' || tablename ||'''
AND c.contype = ''f''::"char"
AND c.confrelid = ft.oid
AND t.oid = c.conrelid';

FOR crec in EXECUTE command LOOP
	--command = 'SELECT ARRAY[a.attname] FROM pg_namespace s, pg_class t, pg_attribute a
	--	   WHERE s.nspname = ''' || crec.schemaname || ''' AND s.oid = t.relnamespace AND t.relkind = 'r'::"char"
	--		AND t.relname = ''' || crec.tablename || ''' AND a.attnum = ANY(' || crec.conkey || ')	AND a.attrelid = t.oid';
	--FOR arec IN EXECUTE command LOOP
		
	--END LOOP;
		
	--command = 'ALTER TABLE ' || schemaname || '.' || tablename || ' ADD FOREIGN KEY'
END LOOP;

END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  ROWS 1000
  COST 100;
ALTER FUNCTION core.drop_fk(text, text) OWNER TO %DBUSER%;
