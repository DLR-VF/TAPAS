-- Function: core.current_taz_settlement_code_tapas_exists_func()

-- DROP FUNCTION core.current_taz_settlement_code_tapas_exists_func();

CREATE OR REPLACE FUNCTION core.current_taz_settlement_code_tapas_exists_func()
  RETURNS trigger AS
$BODY$DECLARE bool boolean;
DECLARE code integer;

BEGIN

code = NEW."CURRENT_TAZ_SETTLEMENT_CODE_TAPAS";
FOR bool IN EXECUTE 'SELECT EXISTS(SELECT code_tapas 
			    FROM core.global_settlement_codes 
			    WHERE code_tapas = ' || code || ')' 
	 LOOP
END LOOP;

IF bool = false THEN
	RAISE EXCEPTION 'CURRENT_TAZ_SETTLEMENT_CODE_TAPAS % does not exist in core.global_settlement_codes', code;
END IF;


RETURN NEW;

END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.current_taz_settlement_code_tapas_exists_func() OWNER TO %DBUSER%;
