-- Function: core.load_persons(character varying, character varying, character varying)

-- DROP FUNCTION core.load_persons(character varying, character varying, character varying);

CREATE OR REPLACE FUNCTION core.load_persons(persons_file character varying, persons_table character varying, p_key character varying)
  RETURNS void AS
$BODY$DECLARE households_table text;

BEGIN
CREATE TEMPORARY TABLE tmp_persons (
	id integer, homex text, homey text, workx text, worky text, tvz integer, idhh integer, sex integer, age integer, age_stba integer,
	bez_id integer, ewt double precision, abo integer, phh integer, carshh integer,fs integer, tb_grup integer, hhtyp integer,
	budget_oev double precision, budget_iv double precision, budg_iv_fi double precision, PRIMARY KEY (id, idhh));
EXECUTE 'COPY tmp_persons FROM ''' ||  persons_file || ''' WITH CSV HEADER DELIMITER E''\t'' NULL as '';''';

-- delete option
-- EXECUTE 'SELECT core.delete_rows(''' ||  persons_table || ''', ''p_year'', ''' || year || ''', 1)';
-- EXECUTE 'INSERT INTO ' ||  persons_table || ' (SELECT tp.id, tp.idhh, tp.tb_grup, tp.sex, tp.age, tp.age_stba, -1, tp.ewt, tp.abo, 
--	tp.budget_oev, tp.budget_iv, tp.budg_iv_fi, ' || year || ' FROM tmp_persons tp)';

-- insert and update option
EXECUTE 'UPDATE ' || persons_table || ' SET 
(p_id, p_hh_id, p_group, p_sex, p_age, p_age_stba, p_work_id, p_working, p_abo, p_budget_pt, p_budget_it, p_budget_it_fi, p_key, p_driver_license) = 
(tp.id, tp.idhh, tp.tb_grup, tp.sex, tp.age, tp.age_stba, -1, tp.ewt, tp.abo, tp.budget_oev, tp.budget_iv, tp.budg_iv_fi,''' || p_key || ''', tp.fs)
FROM tmp_persons tp
WHERE tp.id = p_id AND tp.idhh = p_hh_id AND ''' || p_key || ''' = p_key';

EXECUTE 'INSERT INTO ' || persons_table || ' (
	SELECT tp.id, tp.idhh, tp.tb_grup, tp.sex, tp.age, tp.age_stba, -1, tp.ewt, tp.abo, tp.budget_oev, tp.budget_iv, tp.budg_iv_fi, ''' || p_key || ''', tp.fs 
	FROM tmp_persons tp WHERE tp.id IN (SELECT id FROM tmp_persons EXCEPT SELECT p_id FROM ' || persons_table || ' WHERE p_key = ''' || p_key || '''))';

DROP TABLE tmp_persons;

households_table = replace(persons_table, 'persons', 'households');
EXECUTE 'UPDATE ' || households_table || ' 
SET hh_has_child = TRUE 
FROM   (SELECT ips.p_hh_id, count(*)>0 as has_child 
	FROM ' || persons_table || ' ips LEFT OUTER JOIN core.global_person_codes pc ON ips.p_group = pc.code_tapas
	WHERE pc.pers_type=''CHILD'' AND ips.p_key=''' || p_key || ''' GROUP BY ips.p_hh_id) AS it
WHERE hh_id = it.p_hh_id AND hh_key = ''' || p_key || '''';


END$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION core.load_persons(character varying, character varying, character varying)
  OWNER TO %DBUSER%;
