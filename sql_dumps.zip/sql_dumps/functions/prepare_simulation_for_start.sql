-- Function: core.prepare_simulation_for_start(character varying)

-- DROP FUNCTION core.prepare_simulation_for_start(character varying);

CREATE OR REPLACE FUNCTION core.prepare_simulation_for_start(key_to_start character varying)
  RETURNS character varying AS
$BODY$
DECLARE sim CHARACTER VARYING;
DECLARE par CHARACTER VARYING[];
DECLARE schemaName CHARACTER VARYING;
DECLARE tempName CHARACTER VARYING;
DECLARE p_table CHARACTER VARYING;
DECLARE hh_table CHARACTER VARYING;
DECLARE hh_key CHARACTER VARYING;
DECLARE loc_table CHARACTER VARYING;
DECLARE loc_key CHARACTER VARYING;
DECLARE temp_loc_table CHARACTER VARYING;
DECLARE temp_hh_table CHARACTER VARYING;
DECLARE trip_table CHARACTER VARYING;
DECLARE sample_size CHARACTER VARYING;
DECLARE random_seed CHARACTER VARYING;
DECLARE region CHARACTER VARYING;

DECLARE c integer;
DECLARE exist BOOLEAN;
DECLARE pkey CHARACTER VARYING;
DECLARE command CHARACTER VARYING;
BEGIN
sim = NULL;
command = 'SELECT sim_key FROM simulations WHERE sim_key = ''' || key_to_start || ''' AND sim_ready = FALSE';
FOR sim IN EXECUTE command LOOP END LOOP;

IF (sim IS NOT NULL) THEN


	FOR par IN SELECT sim_par FROM simulations WHERE sim_key = sim LOOP END LOOP;

	FOR schemaName IN SELECT param_value FROM simulation_parameters WHERE sim_key = sim and param_key = 'DB_SCHEMA_CORE' LOOP END LOOP;
	FOR tempName IN SELECT param_value FROM simulation_parameters WHERE sim_key = sim and param_key = 'DB_SCHEMA_TEMP' LOOP END LOOP;
	FOR p_table IN SELECT param_value FROM simulation_parameters WHERE sim_key = sim and param_key = 'DB_TABLE_PERSON' LOOP END LOOP;
	FOR hh_table IN SELECT param_value FROM simulation_parameters WHERE sim_key = sim and param_key = 'DB_TABLE_HOUSEHOLD' LOOP END LOOP;
	FOR loc_table IN SELECT param_value FROM simulation_parameters WHERE sim_key = sim and param_key = 'DB_TABLE_LOCATION' LOOP END LOOP;
	FOR hh_key IN SELECT param_value FROM simulation_parameters WHERE sim_key = sim and param_key = 'DB_HOUSEHOLD_AND_PERSON_KEY' LOOP END LOOP;
    FOR sample_size IN SELECT param_value FROM simulation_parameters WHERE sim_key = sim and param_key = 'DB_HH_SAMPLE_SIZE' LOOP END LOOP;
    FOR loc_key IN SELECT param_value FROM simulation_parameters WHERE sim_key = sim and param_key = 'DB_LOCATION_KEY' LOOP END LOOP;
	FOR region IN SELECT param_value FROM simulation_parameters WHERE sim_key = sim and param_key = 'DB_REGION' LOOP END LOOP;

    IF(loc_key ISNULL) THEN
            loc_key = 'default';
    END IF;

	--random_seed =par[3];
	random_seed = '-1';
    p_table = schemaName || p_table;
	hh_table = schemaName || hh_table;
	loc_table = schemaName || loc_table;
	temp_hh_table = tempName||'households_' || sim;
	temp_loc_table = tempName||'locations_' || sim;
	trip_table = 'public.' || region || '_trips_' || sim;
	command = 'SELECT core.exist_table(''public'', ''' || region || '_trips_' || sim || ''')';
	FOR exist IN EXECUTE command LOOP END LOOP;
	IF (exist IS FALSE) THEN
		PERFORM core.create_hh_sample(hh_table, temp_hh_table, p_table, hh_key, cast(random_seed as double precision), cast(sample_size as double precision));
		PERFORM core.create_temp_locations(loc_table, temp_loc_table, loc_key, false);

		pkey = split_part(trip_table, '.', 2);

		EXECUTE 'CREATE TABLE ' || trip_table || '(p_id integer, hh_id integer, scheme_id integer, score_combined double precision, 
			score_finance double precision, score_time double precision, taz_id_start integer, taz_has_toll_start boolean, 
			block_id_start integer, loc_id_start integer, lon_start double precision, lat_start double precision, taz_id_end integer, taz_has_toll_end boolean, block_id_end integer, 
			loc_id_end integer, lon_end double precision, lat_end double precision, start_time_min integer, travel_time_sec double precision, mode integer, 
			car_type integer, distance_bl_m double precision, distance_real_m double precision, activity integer, 
			is_home boolean, activity_start_min integer, activity_duration_min integer, car_index integer, is_restricted boolean, p_group integer, taz_bbr_type_start integer, bbr_type_home integer, loc_selection_motive integer, 
			loc_selection_motive_supply integer, CONSTRAINT ' || pkey || '_pkey PRIMARY KEY (p_id, hh_id, start_time_min))'; 
		EXECUTE 'GRANT ALL ON TABLE ' || temp_hh_table || ' TO tapas_user_group';
		EXECUTE 'GRANT ALL ON TABLE ' || temp_loc_table || ' TO tapas_user_group';
		IF (cast(par[5] as boolean)) THEN
			EXECUTE 'GRANT ALL ON TABLE ' || temp_loc_table || '_set TO tapas_user_group';
		END IF;
		EXECUTE 'GRANT ALL ON TABLE ' || trip_table || ' TO tapas_user_group';
	END IF;
 	command = 'UPDATE simulations SET sim_ready = TRUE, sim_started = TRUE, sim_total = (SELECT count(*) FROM ' || temp_hh_table|| ') WHERE sim_key = ''' || sim || '''';
	EXECUTE command;
END IF;
RETURN sim;
END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION core.prepare_simulation_for_start(character varying)
  OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.prepare_simulation_for_start(character varying) TO tapas_user_group;

GRANT EXECUTE ON FUNCTION core.prepare_simulation_for_start(character varying) TO tapas_admin_group;
GRANT EXECUTE ON FUNCTION core.prepare_simulation_for_start(character varying) TO public;
