-- Function: core.has_child(character varying, integer)

-- DROP FUNCTION core.has_child(character varying, integer);

CREATE OR REPLACE FUNCTION core.has_child(tablename character varying, hh_id integer)
  RETURNS boolean AS
$BODY$DECLARE has_child BOOLEAN;
BEGIN
FOR has_child IN EXECUTE 'SELECT count(*)>0 FROM ' || tablename ||' ips, core.personcodes pc 
	WHERE ips.p_hh_id=' || hh_id || ' AND ips.p_group = pc.code_tapas AND pc.pers_type=''CHILD''' LOOP END LOOP;
RETURN has_child;
END;$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.has_child(character varying, integer) OWNER TO %DBUSER%;
