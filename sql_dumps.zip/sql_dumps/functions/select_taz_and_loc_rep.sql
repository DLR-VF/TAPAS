-- Function: core.select_taz_and_loc_rep(character varying, character varying, integer, integer, double precision, double precision, integer, double precision)

-- DROP FUNCTION core.select_taz_and_loc_rep(character varying, character varying, integer, integer, double precision, double precision, integer, double precision);

CREATE OR REPLACE FUNCTION core.select_taz_and_loc_rep(taz_table character varying, temp_loc_table character varying, loc_id_src integer, loc_id_dst integer, dist_from_src double precision, dist_to_dst double precision, act_code integer, random double precision)
  RETURNS SETOF core.taz_and_loc_rep_and_sum_weight AS
$BODY$DECLARE command character varying;
DECLARE rec core.taz_and_loc_rep_and_sum_weight;
BEGIN
/*
 * Opportunity A:
 * command = 'SELECT c1.taz_id, 
 * 		core.generate_location_rep(''' || temp_loc_table || ''', c1.taz_id, ' || loc_code || ', ' || random || ' )
 *	   FROM ' || taz_table || ' c1, ' || loc_table || ' c2, ' || loc_table || ' c3 
 *	   WHERE distance_spheroid(c1.coordinate, c2.coordinate,''SPHEROID[\"WGS 84\",6378137,298.257223563]'') < ' || dist_from_src ||
 *	   ' AND c2.loc_id=' || loc_id_src || 
 *	   ' AND distance_spheroid(c1.coordinate, c3.coordinate,''SPHEROID[\"WGS 84\",6378137,298.257223563]'') < ' || dist_to_dst || 
 *	   ' AND c3.loc_id=' || loc_id_dst;
 */
/*
 *Opportunity B:
 *command = 'SELECT tl.taz_id, tl.loc_id
 * 	     FROM ' || temp_loc_table || ' tl, 
 *	    (SELECT tl.taz_id, min(tl.incr_sum) AS m
 *	    	FROM ' || temp_loc_table || ' tl, ' || loc_table || ' bl1, ' || loc_table || ' bl2, ' || taz_table || ' bt
 *		WHERE tl.loc_code=' || act_code || ' 
 *		AND bt.taz_id = tl.taz_id
 *		AND tl.incr_sum >= ' || random || '*(
 *			SELECT sum FROM ' || temp_loc_table || '_set tls
 *			WHERE tl.taz_id=tls.taz_id AND loc_code=' || act_code || ')
 *			AND distance_spheroid(bt.coordinate, bl1.coordinate,''SPHEROID[\"WGS 84\",6378137,298.257223563]'') < ' || dist_from_src || '
 *			AND bl1.loc_id=' || loc_id_src || '
 *			AND distance_spheroid(bt.coordinate, bl2.coordinate,''SPHEROID[\"WGS 84\",6378137,298.257223563]'') < ' || dist_to_dst || '
 *			AND bl2.loc_id=' || loc_id_dst || '
 *			GROUP BY tl.taz_id) AS internal
 *		WHERE internal.m = tl.incr_sum AND loc_code=' || act_code || ' AND internal.taz_id = tl.taz_id
 *		GROUP BY tl.loc_id, tl.taz_id
 *		ORDER BY tl.taz_id';
*/
/*
 * Opportunity C:
 * command = '
 * SELECT DISTINCT ON (A.taz_id) A.taz_id, A.loc_id, E.max_incr_sum
 * FROM ' || temp_loc_table || ' A, ' || temp_loc_table || ' B, ' || temp_loc_table || ' C, ' || taz_table || ' D,
 *      (SELECT DISTINCT ON (AA.taz_id) AA.taz_id, AA.loc_code, AA.sum, BB.max_incr_sum
 *       FROM ' || temp_loc_table || '_set AA, 
 *            (SELECT AAA.taz_id, AAA.act_code, max(AAA.incr_sum) AS max_incr_sum
 * 	    FROM ' || temp_loc_table || '_set AAA 
 * 	    GROUP BY AAA.taz_id, AAA.act_code) AS BB
 *      WHERE AA.incr_sum >= ' || random || ' * BB.max_incr_sum 
 *       AND AA.act_code = ' || act_code || ' 
 *       AND BB.act_code = AA.act_code 
 *       AND BB.taz_id = AA.taz_id 
 *       ORDER BY AA.taz_id, AA.incr_sum) AS E 
 * WHERE A.loc_code = E.loc_code
 *       AND A.taz_id = E.taz_id
 *       AND A.taz_id = D.taz_id
 *       AND B.loc_id=' || loc_id_src || ' 
 *       AND C.loc_id=' || loc_id_dst ||  
 * --      ' AND distance_spheroid(D.coordinate, B.coordinate,''SPHEROID[\"WGS 84\",6378137,298.257223563]'') < ' || dist_from_src || 
 * --      ' AND distance_spheroid(D.coordinate, C.coordinate,''SPHEROID[\"WGS 84\",6378137,298.257223563]'') < ' || dist_to_dst || 
 * --      ' AND B.coordinate && Expand(D.coordinate, ' || dist_from_src || ')' ||
 * --      ' AND C.coordinate && Expand(D.coordinate, ' || dist_to_dst || ') ' ||
 *       ' AND distance_sphere(D.coordinate, B.coordinate) < ' || dist_from_src || 
 *       ' AND distance_sphere(D.coordinate, C.coordinate) < ' || dist_to_dst || 
 *       ' AND A.incr_sum-E.sum*' || random || ' >= 0
 * ORDER BY A.taz_id, A.incr_sum-E.sum*' || random;
 */

/*
 * Best opportunity:
 * Here are also three nested statements. The inner statement select all traffic analysis zones which are in the specific area arount
 * the start and end of the trip. Also there is the activity code and the maximum weight corresponding to this taz and act_code returned.
 * The middle statement then selects one location code corresponding to the activity code via the incremental weights. The outer statement 
 * then selects one location representant and returns al results.
 */
command = '
SELECT DISTINCT ON (A.loc_taz_id) A.loc_taz_id, A.loc_id, E.max_incr_weight
FROM ' || temp_loc_table || ' A, 
     (SELECT DISTINCT ON (AA.set_taz_id) AA.set_taz_id, AA.loc_code, AA.set_loc_sum_weight, BB.max_incr_weight
      FROM ' || temp_loc_table || '_set AA, 
           (SELECT AAA.set_taz_id, AAA.act_code, max(AAA.set_incr_weight) AS max_incr_weight
	    FROM ' || temp_loc_table || '_set AAA, ' || temp_loc_table || ' B, ' || temp_loc_table || ' C, ' || taz_table || ' D
	    WHERE B.loc_id=' || loc_id_src || ' AND C.loc_id=' || loc_id_dst || ' AND AAA.set_taz_id = D.taz_id ' ||
		' AND distance_sphere(D.taz_coordinate, B.loc_coordinate) < ' || dist_from_src || 
		' AND distance_sphere(D.taz_coordinate, C.loc_coordinate) < ' || dist_to_dst || 
	    ' GROUP BY AAA.set_taz_id, AAA.act_code) AS BB
      WHERE AA.set_incr_weight >= ' || random || ' * BB.max_incr_weight 
      AND AA.act_code = ' || act_code || ' 
      AND BB.act_code = AA.act_code 
      AND BB.set_taz_id = AA.set_taz_id 
      ORDER BY AA.set_taz_id, AA.set_incr_weight) AS E 
WHERE A.loc_code = E.loc_code
      AND A.loc_taz_id = E.set_taz_id
      AND A.loc_incr_weight-E.set_loc_sum_weight*' || random || ' >= 0
ORDER BY A.loc_taz_id, A.loc_incr_weight-E.set_loc_sum_weight*' || random;
FOR rec IN EXECUTE command LOOP
	RETURN NEXT rec;
END LOOP;
RETURN;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  ROWS 1000
  COST 100;
ALTER FUNCTION core.select_taz_and_loc_rep(character varying, character varying, integer, integer, double precision, double precision, integer, double precision) OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.select_taz_and_loc_rep(character varying, character varying, integer, integer, double precision, double precision, integer, double precision) TO public;
GRANT EXECUTE ON FUNCTION core.select_taz_and_loc_rep(character varying, character varying, integer, integer, double precision, double precision, integer, double precision) TO tapas_user_group;

COMMENT ON FUNCTION core.select_taz_and_loc_rep(character varying, character varying, integer, integer, double precision, double precision, integer, double precision) IS 'This method returns all reachable traffic analysis zones and one location representant for this zone. If there exsist no location to the corresponding activity code the zone is skipped.';





-- Function: core.select_taz_and_loc_rep(character varying, character varying, integer, double precision)

-- DROP FUNCTION core.select_taz_and_loc_rep(character varying, character varying, integer, double precision);

CREATE OR REPLACE FUNCTION core.select_taz_and_loc_rep(temp_loc_table character varying, taz_id_array character varying, act_code integer, random double precision)
  RETURNS SETOF core.taz_and_loc_rep_and_sum_weight AS
$BODY$DECLARE command character varying;
DECLARE rec core.taz_and_loc_rep_and_sum_weight;
BEGIN
/*
 * Best opportunity:
 * Here are also three nested statements. The inner statement select all traffic analysis zones which are in the specific area arount
 * the start and end of the trip. Also there is the activity code and the maximum weight corresponding to this taz and act_code returned.
 * The middle statement then selects one location code corresponding to the activity code via the incremental weights. The outer statement 
 * then selects one location representant and returns al results.
 */
command = '
SELECT DISTINCT ON (A.loc_taz_id) A.loc_taz_id, A.loc_id, E.max_incr_weight
FROM ' || temp_loc_table || ' A, 
     (SELECT DISTINCT ON (AA.set_taz_id) AA.set_taz_id, AA.loc_code, AA.set_loc_sum_weight, BB.max_incr_weight
      FROM ' || temp_loc_table || '_set AA, 
           (SELECT AAA.set_taz_id, AAA.act_code, max(AAA.set_incr_weight) AS max_incr_weight
	    FROM ' || temp_loc_table || '_set AAA 
	    WHERE AAA.set_taz_id = ANY(' || taz_id_array || ') 
	    GROUP BY AAA.set_taz_id, AAA.act_code) AS BB
      WHERE AA.set_incr_weight >= ' || random || ' * BB.max_incr_weight 
      AND AA.act_code = ' || act_code || ' 
      AND BB.act_code = AA.act_code 
      AND BB.set_taz_id = AA.set_taz_id 
      ORDER BY AA.set_taz_id, AA.set_incr_weight) AS E 
WHERE A.loc_code = E.loc_code
      AND A.loc_taz_id = E.set_taz_id
      AND A.loc_incr_weight-E.set_loc_sum_weight*' || random || ' >= 0
ORDER BY A.loc_taz_id, A.loc_incr_weight-E.set_loc_sum_weight*' || random;
FOR rec IN EXECUTE command LOOP
	RETURN NEXT rec;
END LOOP;
RETURN;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  ROWS 1000
  COST 100;
ALTER FUNCTION core.select_taz_and_loc_rep(character varying, character varying, integer, double precision) OWNER TO %DBUSER%;
