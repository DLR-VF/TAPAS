-- Function: core.incr_occupancy(character varying, character varying, integer, boolean)

-- DROP FUNCTION core.incr_occupancy(character varying, character varying, integer, boolean);

CREATE OR REPLACE FUNCTION core.incr_occupancy(temp_location_table character varying, loc_id character varying, incr integer, has_incremental_sum boolean)
  RETURNS boolean AS
$BODY$DECLARE command TEXT;
DECLARE command2 TEXT;
DECLARE rec RECORD;
DECLARE id INTEGER;
BEGIN
--	Locks the whole table against concurring writes, reading is still permitted, this is (due to allowed reads) even faster than row-whise locking. 
--  Outdated values for other threads are no issue, due to the capacity check during their call of this function. This might have happened anyway.
	command = 'LOCK TABLE ' || temp_location_table || ' IN EXCLUSIVE MODE';
  EXECUTE command;
--	command = 'SELECT loc_id FROM ' || temp_location_table || ' 
--		   WHERE loc_id = ANY(' || loc_id || ') ORDER BY loc_id';
--	FOR id in EXECUTE command LOOP
--		command = 'SELECT loc_id FROM ' || temp_location_table || ' 
--		   WHERE loc_id = '|| id || ' FOR UPDATE';
--		EXECUTE command;
--	END LOOP;
	

--	check for constraint violation in fix capacities
	command = 'SELECT * FROM ' || temp_location_table || ' 
		   WHERE loc_id = ANY(' || loc_id || ') AND loc_has_fix_capacity AND loc_occupancy+' || incr || '> loc_capacity';
	FOR rec IN EXECUTE command LOOP
		RETURN false;
	END LOOP;


--	Update the location weight for all zero capacities
command = 'UPDATE ' || temp_location_table || ' 
	   SET 
	       loc_weight = loc_capacity,
	       loc_occupancy = 0 
	   WHERE loc_id = ANY(' || loc_id || ') AND (loc_occupancy + ' || incr || ') <= 0';
EXECUTE command;

IF has_incremental_sum THEN
	--	Update the location weight for fixed capacities
	command = 'UPDATE ' || temp_location_table || ' 
		   SET loc_occupancy = loc_occupancy + ' || incr || ', 
	  	     loc_weight = loc_capacity - (loc_occupancy + ' || incr || ') 
	   	WHERE loc_id = ANY(' || loc_id || ') AND loc_has_fix_capacity AND (loc_occupancy + ' || incr || ') > 0';
	EXECUTE command;

	--	Update the location weight for free capacities with a overload factor of less than 10!
	command = 'UPDATE ' || temp_location_table || ' 
		   SET loc_occupancy = loc_occupancy + ' || incr || ', 
	  	     loc_weight = (loc_capacity * exp(-2*(loc_occupancy + ' || incr || ')/loc_capacity))
		   WHERE loc_id = ANY(' || loc_id || ') AND NOT loc_has_fix_capacity and (loc_occupancy+ ' || incr || ')<(10*loc_capacity)  AND (loc_occupancy + ' || incr || ') > 0';
	EXECUTE command;
	
	--	Set the location weight for free capacities with a overload factor of more than 10 to 0!
	command = 'UPDATE ' || temp_location_table || ' 
		   SET loc_occupancy = loc_occupancy + ' || incr || ', 
	  	     loc_weight = 0 
	   	WHERE loc_id = ANY(' || loc_id || ') AND NOT loc_has_fix_capacity and NOT (loc_occupancy+ ' || incr || ')<(10*loc_capacity) AND (loc_occupancy + ' || incr || ') > 0';
	EXECUTE command;

	--	Update incremental weights
	command = 'SELECT DISTINCT loc_taz_id, loc_code FROM ' || temp_location_table || ' WHERE loc_id = ANY(' || loc_id || ')';
	FOR rec IN EXECUTE command LOOP
		--raise notice '%, %', rec.taz_id, rec.loc_code;
		PERFORM core.calculate_incr_sum(temp_location_table, rec.loc_taz_id, rec.loc_code);
	END LOOP;
ELSE
  -- with no incremental sum the weight is calculated in the main program and must not be set here
	command = 'UPDATE ' || temp_location_table || ' 
		   SET loc_occupancy = loc_occupancy + ' || incr || '
	   	WHERE loc_id = ANY(' || loc_id || ') AND (loc_occupancy + ' || incr || ') >= 0';
	EXECUTE command;

END IF;

RETURN true;
END
$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.incr_occupancy(character varying, character varying, integer, boolean) OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.incr_occupancy(character varying, character varying, integer, boolean) TO public;
GRANT EXECUTE ON FUNCTION core.incr_occupancy(character varying, character varying, integer, boolean) TO tapas_user_group;






-- Function: core.incr_occupancy(character varying, character varying, integer)

-- DROP FUNCTION core.incr_occupancy(character varying, character varying, integer);

CREATE OR REPLACE FUNCTION core.incr_occupancy(temp_location_table character varying, loc_id character varying, incr integer)
  RETURNS boolean AS
$BODY$DECLARE command TEXT;
DECLARE bool boolean;
BEGIN
FOR bool IN SELECT core.incr_occupancy(temp_location_table, loc_id, incr, true) LOOP END LOOP; 
RETURN bool;
END
$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.incr_occupancy(character varying, character varying, integer) OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.incr_occupancy(character varying, character varying, integer) TO public;
GRANT EXECUTE ON FUNCTION core.incr_occupancy(character varying, character varying, integer) TO tapas_user_group;

COMMENT ON FUNCTION core.incr_occupancy(character varying, character varying, integer) IS 'This method increments the occupancy of the specific location and updates all depending incremental weights of locations and location sets if possible. It returns true if it was successfull.';
