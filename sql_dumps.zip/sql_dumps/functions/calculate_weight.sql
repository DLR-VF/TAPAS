-- Function: core.calculate_weight(integer, integer, boolean, double precision)

-- DROP FUNCTION core.calculate_weight(integer, integer, boolean, double precision);

CREATE OR REPLACE FUNCTION core.calculate_weight(capacity integer, occupancy integer, fixcapacity boolean, factor double precision)
  RETURNS double precision AS
$BODY$BEGIN
IF fixcapacity THEN
	RETURN (capacity - occupancy);
ELSE
	RETURN (capacity * exp(-factor*occupancy/capacity));
END IF;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.calculate_weight(integer, integer, boolean, double precision) OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.calculate_weight(integer, integer, boolean, double precision) TO public;
GRANT EXECUTE ON FUNCTION core.calculate_weight(integer, integer, boolean, double precision) TO tapas_user_group;

COMMENT ON FUNCTION core.calculate_weight(integer, integer, boolean, double precision) IS 'This method calculates the current weight of a location. There are two different equations. When the capacity is fix a linear equation is used with values between [0:capacity]. Otherwise an exponential function is used which allows to overfill a location. It returns values between ]0:capacity].';
