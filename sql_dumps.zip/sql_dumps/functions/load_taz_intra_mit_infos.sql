-- Function: core.load_taz_intra_mit_infos(character varying, character varying, character varying)

-- DROP FUNCTION core.load_taz_intra_mit_infos(character varying, character varying, character varying);

CREATE OR REPLACE FUNCTION core.load_taz_intra_mit_infos(taz_info_file character varying, taz_info_name character varying, taz_info_table character varying)
  RETURNS boolean AS
$BODY$BEGIN
EXECUTE 'SELECT core.delete_rows(''' || taz_info_table || ''',''info_name'',''' || taz_info_name || ''',0)';
CREATE TEMPORARY TABLE taz_info_temp(taz_id integer, bl double precision, sp double precision, PRIMARY KEY (taz_id));
EXECUTE 'COPY taz_info_temp FROM ''' || taz_info_file || ''' WITH CSV HEADER'; 
EXECUTE 'INSERT INTO ' || taz_info_table || ' (SELECT taz_id, bl, sp, ''' || taz_info_name || ''' FROM taz_info_temp)';
DROP TABLE taz_info_temp;
RETURN TRUE;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.load_taz_intra_mit_infos(character varying, character varying, character varying) OWNER TO %DBUSER%;
