-- Function: core.get_and_update_next_hh(text, text, integer)

-- DROP FUNCTION core.get_and_update_next_hh(text, text, integer);

CREATE OR REPLACE FUNCTION core.get_and_update_next_hh(tablename text, ip text, count integer)
  RETURNS SETOF integer AS
$BODY$DECLARE command TEXT;
DECLARE rec RECORD;
DECLARE rowsUpdated integer;
DECLARE acualCount integer;
DECLARE columnorder TEXT;
DECLARE schemaName TEXT;
DECLARE tableNameShort TEXT;
DECLARE hasPrio boolean;
BEGIN

EXECUTE 'LOCK TABLE ' || tablename || ' IN EXCLUSIVE MODE;';

schemaName = split_part(tablename, '.', 1);
tableNameShort = split_part(tablename, '.', 2);

command = 'SELECT EXISTS (SELECT 1 
FROM information_schema.columns 
WHERE table_schema=''' || schemaName || ''' AND table_name=''' || tableNameShort || ''' AND column_name=''prio'')';
EXECUTE command into hasPrio;
IF hasPrio THEN
	columnorder = 'prio';
ELSE
	columnorder = 'RANDOM()';
END IF;
acualCount = count;
-- first fetch unfinished hh for this server
command = 'SELECT hh_id FROM ' || tablename || ' WHERE hh_started = true AND hh_finished = false AND server_ip = ' || ip || ' ORDER BY '||columnorder;
FOR rec IN EXECUTE command LOOP
	return NEXT rec.hh_id;
	acualCount = acualCount -1;
END LOOP;



command = 'SELECT hh_id FROM ' || tablename || ' WHERE hh_started = false ORDER BY '||columnorder||' LIMIT ' || acualCount;
FOR rec IN EXECUTE command LOOP
	command = 'UPDATE ' || tablename || ' SET hh_started = true, server_ip = ' || ip || ' WHERE hh_started = false AND hh_id = ' || rec.hh_id;
	EXECUTE command;
	GET DIAGNOSTICS rowsUpdated = ROW_COUNT;
	IF rowsUpdated = 1 THEN --return only successful updates. A update might fail, if a entry was fetched by another worker and updated AFTER the 'hh_started = false'-check but before the lock
		return NEXT rec.hh_id;
	END if;
END LOOP;
RETURN;

--command = 'UPDATE ' || tablename || ' SET hh_started = true, server_ip = ' || ip || ' 
--WHERE hh_id = ANY(SELECT hh_id FROM ' || tablename || ' 
--	       WHERE hh_started = false LIMIT ' || count || ')
--RETURNING hh_id';

--raise notice '%', command;

-- This is possible with postgres 8.4
-- RETURN QUERY EXECUTE command;

--FOR rec IN EXECUTE command LOOP
--    RETURN NEXT rec.hh_id;
--END LOOP;
--RETURN;

END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  ROWS 1000
  COST 100;
ALTER FUNCTION core.get_and_update_next_hh(text, text, integer) OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.get_and_update_next_hh(text, text, integer) TO public;
GRANT EXECUTE ON FUNCTION core.get_and_update_next_hh(text, text, integer) TO tapas_user_group;
COMMENT ON FUNCTION core.get_and_update_next_hh(text, text, integer) IS 'This method returns a special amount of undone households. Each household only is returned once. When there are not enough or no household is present fewer or no household is returned.';
