-- Function: core.tf_delete_simulation()

-- DROP FUNCTION core.tf_delete_simulation();

CREATE OR REPLACE FUNCTION core.tf_delete_simulation()
  RETURNS trigger AS
$BODY$DECLARE tablename character varying;
DECLARE command character varying;
BEGIN
--delete temporary household and location tables
command = 'SELECT core.drop_temp_tables('''||OLD.sim_key||''');';
EXECUTE command;
--delete iteration instances in matrices
command = 'DELETE FROM core.'||OLD.sim_par[1]||'_matrices WHERE matrix_name LIKE ''%'||OLD.sim_key||'%''';
EXECUTE command;
--delete iteration instances in matrixmaps
command = 'DELETE FROM core.'||OLD.sim_par[1]||'_matrixmap WHERE "matrixMap_name" LIKE ''%'||OLD.sim_key||'%''';
EXECUTE command;
--delete iteration instances in intra-infos-mit
command = 'DELETE FROM core.'||OLD.sim_par[1]||'_taz_intra_mit_infos WHERE info_name LIKE ''%'||OLD.sim_key||'%''';
EXECUTE command;
--delete iteration instances in intra-infos-mit
command = 'DELETE FROM core.'||OLD.sim_par[1]||'_taz_intra_pt_infos WHERE info_name LIKE ''%'||OLD.sim_key||'%''';
EXECUTE command;
-- delete trip table
tablename = OLD.sim_par[1] || '_trips_' || OLD.sim_key;
raise notice '%', tablename;
IF core.exist_table('public', tablename) THEN
	EXECUTE 'DROP TABLE public.' || tablename;
END IF;
tablename = 'trips_' || OLD.sim_key;
raise notice '%', tablename;
IF core.exist_table('public', tablename) THEN
	EXECUTE 'DROP TABLE public.' || tablename;
END IF;
-- delete simparameters
DELETE FROM public.simulation_parameters WHERE sim_key = OLD.sim_key;
RETURN OLD;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.tf_delete_simulation() OWNER TO %DBUSER%;
