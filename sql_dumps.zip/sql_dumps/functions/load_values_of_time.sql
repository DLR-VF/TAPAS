-- Function: core.load_values_of_time(character varying, character varying)

-- DROP FUNCTION core.load_values_of_time(character varying, character varying);

CREATE OR REPLACE FUNCTION core.load_values_of_time(filename character varying, "name" character varying)
  RETURNS boolean AS
$BODY$BEGIN
CREATE TEMPORARY TABLE values_of_time_temp(v1 integer, v2 integer, v3 integer, v4 integer, value double precision, PRIMARY KEY (v1, v2, v3, v4));
EXECUTE 'COPY values_of_time_temp FROM ''' || filename || ''' WITH CSV HEADER';
EXECUTE 'SELECT core.delete_rows(''core.values_of_time'',''name'',''' || name|| ''',0)';
EXECUTE 'INSERT INTO core.values_of_time (SELECT '''||name||''', v1, v2, v3, v4, value FROM values_of_time_temp)';
DROP TABLE values_of_time_temp;
RETURN TRUE;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.load_values_of_time(character varying, character varying) OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.load_values_of_time(character varying, character varying) TO public;
