-- Function: core.load_scheme_class_time_usage(character varying)

-- DROP FUNCTION core.load_scheme_class_time_usage(character varying);

CREATE OR REPLACE FUNCTION core.load_scheme_class_time_usage(file_scheme_class_time_usage character varying)
  RETURNS boolean AS
$BODY$BEGIN

CREATE TEMPORARY TABLE sctu_temp (id integer, mean double precision, dev double precision, PRIMARY KEY (id));

EXECUTE 'COPY sctu_temp FROM ''' || file_scheme_class_time_usage || ''' WITH CSV HEADER';

DELETE FROM core.global_scheme_classes USING sctu_temp WHERE scheme_class_id = id;
INSERT INTO core.global_scheme_classes (SELECT id, mean, dev FROM sctu_temp);

DROP TABLE sctu_temp;
RETURN TRUE;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.load_scheme_class_time_usage(character varying) OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.load_scheme_class_time_usage(character varying) TO public;

