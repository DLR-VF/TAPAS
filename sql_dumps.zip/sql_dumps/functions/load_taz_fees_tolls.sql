-- Function: core.load_taz_fees_tolls(character varying, character varying, character varying)

-- DROP FUNCTION core.load_taz_fees_tolls(character varying, character varying, character varying);

CREATE OR REPLACE FUNCTION core.load_taz_fees_tolls(file_fees_tolls character varying, name_fees_tolls character varying, table_fees_tolls character varying)
  RETURNS boolean AS
$BODY$BEGIN
CREATE TEMPORARY TABLE fees_tolls_temp (
	taz_id integer, b_has_toll integer, b_toll_type integer, b_has_parking_fee integer, b_parking_type integer, s_has_toll integer, 
	s_toll_type integer, s_has_parking_fee integer, s_parking_type integer, PRIMARY KEY(taz_id));
EXECUTE 'COPY fees_tolls_temp FROM ''' || file_fees_tolls || ''' WITH CSV HEADER';
EXECUTE 'SELECT core.delete_rows(''' || table_fees_tolls || ''',''ft_name'',''' || name_fees_tolls || ''',0)';
EXECUTE 'INSERT INTO ' || table_fees_tolls || ' (
	SELECT ''' || name_fees_tolls || ''', taz_id, b_has_toll = 1, b_toll_type, b_has_parking_fee = 1, b_parking_type, 
		s_has_toll = 1, s_toll_type, s_has_parking_fee = 1, s_parking_type FROM fees_tolls_temp)';
DROP TABLE fees_tolls_temp;
RETURN true;
END;$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.load_taz_fees_tolls(character varying, character varying, character varying) OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.load_taz_fees_tolls(character varying, character varying, character varying) TO public;

