-- Function: core.tf_server_timestamp()

-- DROP FUNCTION core.tf_server_timestamp();

CREATE OR REPLACE FUNCTION core.tf_server_timestamp()
  RETURNS trigger AS
$BODY$BEGIN
NEW.server_timestamp = NOW();
RETURN NEW;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.tf_server_timestamp() OWNER TO %DBUSER%;
