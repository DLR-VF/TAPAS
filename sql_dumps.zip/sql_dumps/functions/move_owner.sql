-- Function: core.move_owner(character varying, character varying)

-- DROP FUNCTION core.move_owner(character varying, character varying);

CREATE OR REPLACE FUNCTION core.move_owner(schemaname character varying, "owner" character varying)
  RETURNS boolean AS
$BODY$DECLARE command TEXT;
DECLARE rec TEXT;

BEGIN

command = 'SELECT 
	  ''ALTER TABLE "'' || schemaname || ''"."'' || tablename || ''" OWNER TO ' || owner || ';''
	  FROM pg_tables WHERE schemaname = ''' || schemaname || '''';

FOR rec IN EXECUTE command LOOP
	EXECUTE rec;
END LOOP;

RETURN TRUE;

END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.move_owner(character varying, character varying) OWNER TO %DBUSER%;
