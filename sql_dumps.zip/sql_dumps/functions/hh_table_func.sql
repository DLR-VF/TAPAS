-- Function: core.hh_table_func()

-- DROP FUNCTION core.hh_table_func();

CREATE OR REPLACE FUNCTION core.hh_table_func()
  RETURNS trigger AS
$BODY$DECLARE sim text;
DECLARE finished boolean;
BEGIN
--raise notice '%', sim;
--IF (TG_OP = 'UPDATE' AND OLD.hh_finished = FALSE AND NEW.hh_finished) THEN
--	sim = substr(TG_RELNAME, 12, length(TG_RELNAME)-11);
--	UPDATE simulations SET sim_progress = sim_progress + 1 WHERE sim_key = sim;
--	FOR finished IN SELECT sim_progress = sim_total FROM simulations WHERE sim_key = sim LOOP END LOOP;
--	IF (finished = TRUE) THEN
--		UPDATE simulations SET sim_finished = true, timestamp_finished = now() WHERE sim_key = sim;
--	END IF;
--END IF;
--raise notice '%', sim;
IF (TG_OP = 'DELETE' AND OLD.hh_started = TRUE) THEN
	sim = substr(TG_RELNAME, 12, length(TG_RELNAME)-11);
	UPDATE simulations SET sim_progress = sim_progress + 1 WHERE sim_key = sim;
	FOR finished IN SELECT sim_progress = sim_total FROM simulations WHERE sim_key = sim LOOP END LOOP;
	IF (finished = TRUE) THEN
		UPDATE simulations SET sim_finished = true, timestamp_finished = now() WHERE sim_key = sim;
	END IF;
END IF;
RETURN NEW;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.hh_table_func() OWNER TO %DBUSER%;
