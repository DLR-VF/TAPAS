-- Function: core.load_blocks(character varying, character varying)

-- DROP FUNCTION core.load_blocks(character varying, character varying);

CREATE OR REPLACE FUNCTION core.load_blocks(filename character varying, tablename character varying)
  RETURNS boolean AS
$BODY$BEGIN
CREATE TEMPORARY TABLE blocks_temp(
	block_id integer, taz_id integer, coord_x double precision, coord_y double precision, PRIMARY KEY (block_id));
EXECUTE 'COPY blocks_temp FROM ''' || filename || ''' WITH CSV HEADER';
EXECUTE 'SELECT core.delete_rows(''' || tablename || ''','''','''',-1)';
EXECUTE 'INSERT INTO ' || tablename || ' (
		SELECT block_id, taz_id, NULL, NULL, NULL, GeometryFromText(''POINT(''||coord_x||'' ''||coord_y||'')'', 4326) FROM blocks_temp)';
DROP TABLE blocks_temp;
RETURN TRUE;
END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.load_blocks(character varying, character varying) OWNER TO %DBUSER%;
GRANT EXECUTE ON FUNCTION core.load_blocks(character varying, character varying) TO public;

