-- Function: core.load_scores(character varying, character varying, character varying)

-- DROP FUNCTION core.load_scores(character varying, character varying, character varying);

CREATE OR REPLACE FUNCTION core.load_scores(filename character varying, score_name character varying, tablename character varying)
  RETURNS boolean AS
$BODY$DECLARE pk TEXT;
DECLARE sn TEXT;
DECLARE tn TEXT;

BEGIN

sn = split_part(tablename, '.', 1);
tn = split_part(tablename, '.', 2);

FOR pk IN EXECUTE 'SELECT a.attname
	FROM pg_namespace s, pg_class t, pg_attribute a
	WHERE s.nspname = ''' || sn || '''
	AND s.oid = t.relnamespace
	AND t.relkind = ''r''::"char"
	AND t.relname = ''' || tn || '''
	AND a.attnum = 1
	AND a.attrelid = t.oid' LOOP END LOOP;

CREATE TEMPORARY TABLE score_temp(
	id integer,
	score double precision,
	score_cat double precision,
	PRIMARY KEY (id));

EXECUTE 'COPY score_temp FROM ''' || filename || ''' WITH CSV HEADER';
EXECUTE 'SELECT core.delete_rows(''' || tablename || ''',''score_name'',''' || score_name || ''',0)';
EXECUTE 'INSERT INTO ' || tablename || ' (SELECT id, score, score_cat, ''' || score_name || ''' FROM score_temp)';

DROP TABLE score_temp;

RETURN TRUE;

END$BODY$
  LANGUAGE 'plpgsql' VOLATILE
  COST 100;
ALTER FUNCTION core.load_scores(character varying, character varying, character varying) OWNER TO %DBUSER%;
