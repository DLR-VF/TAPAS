create table public.simulation_parameters
(
    sim_key     varchar not null,
    param_key   varchar not null,
    param_value varchar not null,
    constraint simulation_parameters_pkey
        primary key (sim_key, param_key)
);

alter table public.simulation_parameters OWNER TO %DBUSER%;

grant insert, select, update, delete, truncate, references, trigger on public.simulation_parameters to tapas_user_group;
grant insert, select, update, delete, truncate, references, trigger on public.simulation_parameters to tapas_admin_group;

create index simulation_parameter_param_key
    on public.simulation_parameters (param_key);

