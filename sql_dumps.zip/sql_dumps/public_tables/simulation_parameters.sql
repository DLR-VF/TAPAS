create table public.simulation_parameters
(
    sim_key     varchar not null,
    param_key   varchar not null,
    param_value varchar not null,
    constraint simulation_parameters_pkey
        primary key (sim_key, param_key)
);

alter table public.simulation_parameters
    owner to postgres;

create index simulation_parameter_param_key
    on public.simulation_parameters (param_key);

