/*
 * Copyright (c) 2020 DLR Institute of Transport Research
 * All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

create table public.global_sumo_status
(
    sim_key     text      not null,
    iteration   integer,
    status_time timestamp not null,
    status      text,
    msg_type    sumo_status,
    constraint global_sumo_status_pkey
        primary key (sim_key, status_time)
);

alter table public.global_sumo_status
    owner to %DBUSER%;

grant insert, select, update, delete, truncate, references, trigger on public.global_sumo_status to tapas_user_group with grant option;
grant insert, select, update, delete, truncate, references, trigger on public.global_sumo_status to tapas_admin_group;

