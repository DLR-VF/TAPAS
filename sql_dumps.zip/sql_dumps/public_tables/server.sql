-- auto-generated definition
create table public.servers
(
    server_name        varchar,
    server_description text,
    server_online      boolean                  default false not null,
    server_cores       integer                  default 1     not null,
    server_usage       double precision         default 0     not null,
    server_timestamp   timestamp with time zone default now() not null,
    server_ip          inet                                   not null
        constraint servers_pkey
            primary key,
    server_boot_flag   boolean,
    remote_boot        boolean
);

comment on column public.servers.server_boot_flag is 'Will be set when a server should be started remotely.';

comment on column public.servers.remote_boot is 'Indicates whether this server can be restarted remotely';

alter table public.servers
    OWNER TO %DBUSER%;

create index servers_server_ip
    on public.servers (server_ip);
