create table public.simulations
(
    sim_key            varchar                                not null
        constraint simulations_pkey
            primary key,
    sim_ready          boolean                  default false not null,
    sim_started        boolean                  default false not null,
    sim_finished       boolean                  default false not null,
    sim_progress       integer                  default 0     not null,
    sim_total          integer                  default 1     not null,
    timestamp_insert   timestamp with time zone default now() not null,
    timestamp_started  timestamp with time zone,
    timestamp_finished timestamp with time zone,
    sim_file           varchar                                not null,
    sim_description    text,
    simulation_server  varchar
);

alter table public.simulations
    OWNER TO %DBUSER%;

grant insert, select, update, delete, truncate, references, trigger on public.simulations to tapas_user_group;
grant insert, select, update, delete, truncate, references, trigger on public.simulations to tapas_admin_group;

create index "simulations_ sim_finished"
    on public.simulations (sim_finished);

create index simulations_timestamp_insert
    on public.simulations (timestamp_insert);

create trigger delete_simulation_trigger
    before delete
    on public.simulations
    for each row
execute procedure core.tf_delete_simulation();