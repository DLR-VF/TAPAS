-- auto-generated definition
create table public.server_processes
(
    identifier    varchar not null,
    server_ip     inet    not null,
    p_id          integer not null,
    start_time    varchar,
    host          varchar,
    sim_key       varchar,
    shutdown      boolean default false,
    sha512        text,
    sha512_status integer default '-1'::integer,
    startup       boolean default false,
    end_time      varchar,
    tapas_exit_ok boolean
);

comment on column public.server_processes.identifier is 'Holds a unique JVM process identifier of form PID@HOSTNAME';

comment on column public.server_processes.server_ip is 'The actual IP adress of a running server';

comment on column public.server_processes.p_id is 'process ID';

comment on column public.server_processes.start_time is 'This field holds the date- and timestamp of a SimulationServer process start. The String format is a Java8 LocalDateTime representation';

comment on column public.server_processes.host is 'The unique hostname';

comment on column public.server_processes.tapas_exit_ok is 'if the shutdown of the server was unable to let TPS_Main finish';

alter table public.server_processes
    OWNER TO %DBUSER%;

grant insert, select, update, delete, truncate, references, trigger on public.server_processes to tapas_user_group;
grant insert, select, update, delete, truncate, references, trigger on public.server_processes to tapas_admin_group;

create trigger hash_status_updater
    after insert or update
    on server_processes
    for each row
    execute procedure checksum_flag_setter();

create trigger reset_unfinished_households_trigger
    after delete
    on server_processes
    for each row
    execute procedure core.tf_reset_unfinished_households();

create trigger reset_unfinished_households_triggerv2
    after update or delete
on server_processes
    for each row
    when (old.sim_key::text <> 'IDLE'::text OR old.sim_key::text <> 'SUSPENDED'::text)
execute procedure core.tf_reset_unfinished_households();

create trigger server_offline_trigger
    after update
    on server_processes
    for each row
    execute procedure set_server_offline();

comment on trigger server_offline_trigger on server_processes is 'An update statement on the ''public.server_processes'' table will trigger this.';