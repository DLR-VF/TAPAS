
-- add extensions
CREATE EXTENSION postgis;
CREATE EXTENSION postgis_topology;
CREATE EXTENSION dblink;

--create schema
CREATE SCHEMA core;
CREATE SCHEMA temp;

-- CREATE GROUP IF NOT EXISTS tapas_user_group;
-- CREATE GROUP IF NOT EXISTS tapas_admin_group;
