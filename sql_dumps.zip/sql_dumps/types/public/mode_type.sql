-- Type: mode_type

-- DROP TYPE public.mode_type;

CREATE TYPE public.mode_type AS ENUM
    ('walk', 'bike', 'car', 'passenger', 'public transport', 'taxi', 'train', 'car sharing', 'bike sharing', 'ride sharing');

ALTER TYPE public.mode_type
    OWNER TO %DBUSER%;
