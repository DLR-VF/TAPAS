-- Type: trip

-- DROP TYPE public.trip;

CREATE TYPE public.trip AS
(
    p_id integer,
    p_group integer,
    p_age_category integer,
    p_age integer,
    p_sex integer,
    p_has_season_ticket text,
    p_has_licence text,
    hh_id integer,
    hh_members integer,
    hh_has_child text,
    hh_cars integer,
    hh_income double precision,
    scheme_id integer,
    score_combined double precision,
    score_finance double precision,
    score_time double precision,
    taz_id_start integer,
    block_id_start integer,
    loc_id_start integer,
    loc_coord_x_start double precision,
    loc_coord_y_start double precision,
    taz_bbr_type_start integer,
    taz_has_toll_start text,
    taz_id_end integer,
    block_id_end integer,
    loc_id_end integer,
    loc_coord_x_end double precision,
    loc_coord_y_end double precision,
    taz_bbr_type_end integer,
    taz_has_toll_end text,
    start_time_min integer,
    travel_time_sec double precision,
    mode integer,
    car_type integer,
    distance_bl_m double precision,
    distance_real_m double precision,
    activity integer,
    is_home text,
    activity_start_min integer,
    activity_duration_min integer,
    emmision_type integer,
    is_restricted text
);

ALTER TYPE public.trip
    OWNER TO %DBUSER%;
