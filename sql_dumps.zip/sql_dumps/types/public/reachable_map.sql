-- Type: reachable_map

-- DROP TYPE public.reachable_map;

CREATE TYPE public.reachable_map AS
(
    id integer,
    reachable boolean[]
);

ALTER TYPE public.reachable_map
    OWNER TO %DBUSER%;
