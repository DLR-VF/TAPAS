-- Type: pgis_nn

-- DROP TYPE public.pgis_nn;

CREATE TYPE public.pgis_nn AS
(
    nn_gid integer,
    nn_dist numeric(16,5)
);

ALTER TYPE public.pgis_nn
    OWNER TO %DBUSER%;
