-- Type: vbz_result

-- DROP TYPE public.vbz_result;

CREATE TYPE public.vbz_result AS
(
    vbz_no integer,
    num integer,
    cappacity integer
);

ALTER TYPE public.vbz_result
    OWNER TO %DBUSER%;
