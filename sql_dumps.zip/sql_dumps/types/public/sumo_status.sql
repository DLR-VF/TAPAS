-- Type: sumo_status

-- DROP TYPE public.sumo_status;

CREATE TYPE public.sumo_status AS ENUM
    ('message', 'warning', 'error', 'fatal', 'finished', 'started', 'pending');

ALTER TYPE public.sumo_status
    OWNER TO %DBUSER%;
