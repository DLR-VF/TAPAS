-- Type: scheme_class_distribution

-- DROP TYPE public.scheme_class_distribution;

CREATE TYPE public.scheme_class_distribution AS
(
    sc_probability double precision,
    diaries_in_sc integer
);

ALTER TYPE public.scheme_class_distribution
    OWNER TO %DBUSER%;
