-- Type: traffic_source

-- DROP TYPE public.traffic_source;

CREATE TYPE public.traffic_source AS ENUM
    ('tapas', 'passenger', 'goods', 'business');

ALTER TYPE public.traffic_source
    OWNER TO %DBUSER%;
