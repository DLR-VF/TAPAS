-- Type: person_group_data

-- DROP TYPE public.person_group_data;

CREATE TYPE public.person_group_data AS
(
    mode integer,
    pg_count integer,
    total_count bigint,
    num_trips integer,
    total_length double precision,
    total_duration bigint,
    mid_count bigint
);

ALTER TYPE public.person_group_data
    OWNER TO %DBUSER%;
