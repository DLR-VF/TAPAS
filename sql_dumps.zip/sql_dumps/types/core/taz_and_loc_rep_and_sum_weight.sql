-- Type: taz_and_loc_rep_and_sum_weight

-- DROP TYPE core.taz_and_loc_rep_and_sum_weight;

CREATE TYPE core.taz_and_loc_rep_and_sum_weight AS
(
    taz_id integer,
    loc_id integer,
    max_incr_sum double precision
);

ALTER TYPE core.taz_and_loc_rep_and_sum_weight
    OWNER TO %DBUSER%;
