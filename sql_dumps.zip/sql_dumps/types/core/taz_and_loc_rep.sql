-- Type: taz_and_loc_rep

-- DROP TYPE core.taz_and_loc_rep;

CREATE TYPE core.taz_and_loc_rep AS
(
    taz_id integer,
    loc_id integer
);

ALTER TYPE core.taz_and_loc_rep
    OWNER TO %DBUSER%;
